# AGENTS.md Analysis Summary

## Repository type
- Simple single-project Python repository with duplicated example and src modules.

## Primary technology stack
- Python 3.11+
- MongoDB Atlas Vector Search (Motor / async)
- Pydantic AI, Pydantic Settings
- Docling for ingestion and HybridChunker
- UV for env and execution
- Pytest-based tests in `test_scripts/`

## Major directories for sub-AGENTS.md
- `examples/` — runnable agent, CLI, tools, ingestion pipeline, docling basics
- `src/` — library-style modules mirroring examples for production use
- `test_scripts/` — E2E and integration tests for agent and RAG pipeline
- `docs/` — architecture and reference docs (migrated from `.claude`)

## Build system
- UV for virtualenv, installation, and running tasks (`uv venv`, `uv pip install -e .`, `uv run ...`)

## Testing setup
- Pytest with scenario-based tests in `test_scripts/`:
  - `test_agent_e2e.py`, `comprehensive_e2e_test.py`, `test_rag_pipeline.py`, `test_search.py`

## Key patterns to document
- Code organization:
  - Type-safe Pydantic models across data structures
  - Async I/O for MongoDB and API calls
  - Two-collection MongoDB pattern with `$vectorSearch` and `$rankFusion`
- Conventions:
  - Google-style docstrings
  - No `Any` without justification
  - KISS and YAGNI
- Critical example files:
  - `examples/ingestion/ingest.py` — ingestion pipeline
  - `examples/tools.py` — semantic and hybrid search tools
  - `examples/cli.py` — conversational CLI driver
  - `src/tools.py` — production tools
  - `test_scripts/test_agent_e2e.py` — end-to-end agent test
- Anti-patterns:
  - Creating vector indexes via Motor (must be configured in Atlas)
  - Passing raw text to HybridChunker without DoclingDocument
  - Missing `$lookup` for document metadata in search results
