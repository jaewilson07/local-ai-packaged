#!/usr/bin/env bash
set -eu

echo "Initializing app database and user..."
mongosh --quiet -u "$MONGO_INITDB_ROOT_USERNAME" -p "$MONGO_INITDB_ROOT_PASSWORD" --authenticationDatabase admin <<'EOF'
const dbName = process.env.MONGO_APP_DATABASE || "app";
const user = process.env.MONGO_APP_USERNAME || "appuser";
const pwd  = process.env.MONGO_APP_PASSWORD || "appsecret";

print(`Creating user '${user}' on db '${dbName}' if not exists...`);
db = db.getSiblingDB(dbName);

const existing = db.getUser(user);
if (!existing) {
  db.createUser({
    user: user,
    pwd: pwd,
    roles: [{ role: "readWrite", db: dbName }]
  });
  print("User created.");
} else {
  print("User already exists; skipping.");
}
EOF
echo "Init complete."