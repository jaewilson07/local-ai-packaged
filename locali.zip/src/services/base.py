"""Abstract base class for all service domain objects.

This module provides the BaseApi ABC that all service domain objects
(JiraTicket, JiraEpic, ConfluencePage, GoogleDriveFile, etc.) must inherit from.
Ensures consistent interface for serialization, deserialization, and raw API response access.
"""

from abc import ABC, abstractmethod
from typing import Any, Self


class BaseApi(ABC):
    """
    Abstract base class for service domain objects.
    
    All domain objects interacting with external APIs (Jira, Confluence, Google Drive, etc.)
    must inherit from this class and implement the required methods.
    
    This ensures:
    - Consistent deserialization from API responses via from_dict()
    - Serialization to dict via to_dict()
    - Access to raw API response object via .raw property
    """
    
    @classmethod
    @abstractmethod
    def from_dict(cls, obj: dict[str, Any], **kwargs) -> Self:
        """
        Create an instance from a dictionary (API response).
        
        Args:
            obj: Dictionary containing the API response data
            **kwargs: Additional context (e.g., client, base_url, project_key)
        
        Returns:
            Instance of the domain object
        
        Example:
            >>> ticket = JiraTicket.from_dict(
            ...     obj={"key": "PROJ-123", "fields": {...}},
            ...     client=jira_client
            ... )
        """
        pass
    
    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        """
        Convert instance to dictionary representation.
        
        Returns:
            Dictionary containing the object's data (excluding .raw)
        
        Example:
            >>> ticket_dict = ticket.to_dict()
            >>> assert "key" in ticket_dict
        """
        pass
    
    @property
    @abstractmethod
    def raw(self) -> Any:
        """
        Get the raw API response object.
        
        Stores the original response from the API for accessing extended attributes
        not mapped to dataclass fields.
        
        Returns:
            Raw API response object (e.g., jira.Issue, dict, httpx.Response)
        
        Example:
            >>> issue = ticket.raw  # Returns jira.Issue object
            >>> custom_field = issue.fields.customfield_10014
        """
        pass


__all__ = ["BaseApi"]
