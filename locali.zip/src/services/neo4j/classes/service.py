"""Neo4j graph service wrapper built atop Neo4jClient."""

from __future__ import annotations

from typing import List, Dict
from dataclasses import dataclass
from .neo4j_client import Neo4jClient, Neo4jConfig, GraphEntity
from ....workflows.ingest.graph.models import Entity, Relationship


@dataclass
class Neo4jServiceConfig:
    """Configuration for the Neo4j service."""

    uri: str
    username: str
    password: str


class Neo4jService:
    """High-level service that wraps Neo4jClient for common operations."""

    def __init__(self, config: Neo4jServiceConfig) -> None:
        self._client = Neo4jClient(
            Neo4jConfig(uri=config.uri, username=config.username, password=config.password)
        )

    async def initialize(self) -> None:
        """Initialize the underlying client connection."""
        await self._client.connect()

    async def close(self) -> None:
        """Close the underlying connection."""
        await self._client.close()

    async def upsert_entities(self, entities: List[Entity], chunk_id: str) -> None:
        """Create or merge entities and link them to a chunk."""
        for ent in entities:
            eid = await self._client.create_entity(
                name=ent.name,
                entity_type=ent.type.value,
                properties=ent.properties,
                confidence=ent.confidence,
            )
            await self._client.link_entity_to_chunk(eid, chunk_id)

    async def upsert_relationships(self, relationships: List[Relationship]) -> None:
        """Persist relationships between existing entities.

        Note: Current implementation assumes entities already exist; resolution
        by name/ID should be added when relationship data is richer.
        """
        # Placeholder: relationship resolution to elementIds can be added here.
        for _ in relationships:
            # Future: implement relationship creation when entity IDs are resolvable.
            pass

    async def find_related(self, name: str, depth: int = 1) -> List[GraphEntity]:
        """Find related entities via traversal."""
        return await self._client.find_related_entities(name, depth)

    async def get_timeline(self, name: str) -> List[Dict[str, str]]:
        """Get temporal relationship summaries for an entity."""
        return await self._client.get_entity_timeline(name)


__all__ = ["Neo4jService", "Neo4jServiceConfig"]
