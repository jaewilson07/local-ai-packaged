---
Package: `src/services/neo4j`
---

## Identity
- Thin service wrapper over `Neo4jClient` for graph persistence and traversal.

## Key components
- `Neo4jServiceConfig` → URI, username, password.
- `Neo4jService` → init/close, `upsert_entities`, `upsert_relationships` (placeholder), `find_related`, `get_timeline`.
- Backed by `Neo4jClient` (async driver) in `src/services/neo4j/classes/neo4j_client.py`.

## Patterns
- Always `await initialize()` before use and `await close()` after.
- Entity upsert links entities to Chunk nodes via `MENTIONED_IN` edges (chunk_id stored on chunk node).
- Keep async boundaries; no synchronous calls to the driver.

## Gotchas
- Relationship creation is placeholder—add elementId resolution before using in production.
- Ensure Neo4j credentials are present in settings; handle connection errors gracefully.
