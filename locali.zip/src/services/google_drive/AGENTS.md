# Google Drive Service

**Last Updated:** January 7, 2026

## Overview

The Google Drive service provides search, document export, and per-tab document splitting functionality for Google Drive integration. It follows a consolidated architecture with functionality integrated into core classes.

## Architecture

### Project Structure

```
google_drive/
├── classes/                       # Individual class files
│   ├── google_drive_authenticator.py  # OAuth credential management
│   ├── google_drive_api.py            # Drive API with search, export, folder resolution
│   ├── google_docs_api.py             # Docs API (inherits GoogleDrive) with tab export
│   └── __init__.py                    # Class exports
├── service.py                     # GoogleDriveService facade (workflow)
├── models.py                      # Pydantic models
├── __init__.py                    # Main exports
└── AGENTS.md                      # This file
```

### Core Components

**GoogleAuth** (Single Responsibility: OAuth Management)
- Manages OAuth credential loading and refresh
- Reads from `GDOC_CLIENT` and `GDOC_TOKEN` environment variables
- Handles token expiration and automatic refresh

**GoogleDrive** (Consolidated: API Operations, Search, Export, Folder Resolution)
- Low-level wrapper around Google Drive API v3
- Handles all API communication through `googleapiclient` library
- **Core API methods**: `execute_query()`, `get_file_metadata()`, `export_as_media()`, `get_file_media()`
- **Search methods**: `search()`, `search_ids()` - search with keyword or Drive query syntax
- **Export methods**: `export_as_markdown()` - exports documents with optional YAML frontmatter
- **Folder resolution**: `resolve_folder()` - resolves folder names to IDs with duplicate handling

**GoogleDoc** (Inherits GoogleDrive + Tab Export)
- Inherits all GoogleDrive functionality (search, export, folder resolution)
- Adds Google Docs API v1 wrapper for document structure access
- **Tab export methods**: `export_tabs()` - splits multi-tab docs into per-section markdown
- **Docs API methods**: `get_by_id()`, `get_tabs_metadata()` - fetch document and tab metadata
- Strategy: Export HTML → split on `<p class="title"` → extract titles/ids → convert to markdown

**GoogleDriveService** (Facade: High-Level Interface)
- Combines all components into a single, easy-to-use interface
- Delegates to GoogleDrive and GoogleDoc methods
- Recommended entry point for most use cases

**GoogleDocumentTab** (Model: Tab Metadata + Content)
- Pydantic model representing one tab/section from a Google Doc export
- Fields: `tab_id`, `title`, `index`, `parent_tab_id`, `markdown_content`, `tab_url`

## Usage

### Document Export with Tab Splitting

```python
from services.google_drive import GoogleDriveService

service = GoogleDriveService()

# Export a multi-tab document into per-tab sections
tabs = service.export_tabs(document_id="abc123xyz")

# Each tab is a GoogleDocumentTab with metadata
for tab in tabs:
    print(f"Tab {tab.index}: {tab.title}")
    print(f"Content length: {len(tab.markdown_content)} characters")
    if tab.tab_url:
        print(f"Deep link: {tab.tab_url}")
    
    # Save individual tab as markdown file
    with open(f"tab_{tab.index}_{tab.tab_id}.md", "w") as f:
        f.write(f"# {tab.title}\n\n{tab.markdown_content}")
```

### Using Individual Tab Components

```python
from src.services.google_drive.classes import GoogleAuth, GoogleDoc

auth = GoogleAuth()
docs_api = GoogleDoc(auth)

# Advanced: direct control over tab export process
tabs = docs_api.export_tabs("abc123xyz")

# GoogleDoc inherits GoogleDrive, so you can also search and export
results = docs_api.search("quarterly report", top_n=5)
markdown = docs_api.export_as_markdown("doc_id", include_metadata=True)
```

### Basic Search

```python
from services.google_drive import GoogleDriveService

service = GoogleDriveService()

# Search by keywords
results = service.search_files(query="quarterly report", top_n=5)

# Get just the IDs
ids = service.search_document_ids(query="code review", top_n=10)

# Search within a folder
docs = service.search_documents(
    query="project proposal",
    folder_name="Active Projects",
    top_n=3
)
```

### Document Export

```python
service = GoogleDriveService()

# Export with metadata
markdown = service.export_as_markdown(
    document_id="abc123xyz",
    include_metadata=True,
    output_path="exported/doc.md"
)

# Export without metadata
content = service.export_as_markdown(
    document_id="abc123xyz",
    include_metadata=False
)
```

### Advanced: Using GoogleDrive Directly

```python
from src.services.google_drive.classes import GoogleAuth, GoogleDrive

# Manual initialization for advanced use cases
auth = GoogleAuth()
api = GoogleDrive(auth)

# All operations available on single object
results = api.search("meeting notes", folder_name="2025")
markdown = api.export_as_markdown("doc_id")
folder_id = api.resolve_folder("Active Projects", on_duplicates="newest")
```

## Configuration

### Environment Variables

```bash
# OAuth client configuration from Google Cloud Console
GDOC_CLIENT='{"installed": {"client_id": "...", ...}}'

# Serialized OAuth token with access_token, refresh_token, etc.
GDOC_TOKEN='{"access_token": "...", "refresh_token": "...", ...}'
```

## Design Principles Applied

✅ **Consolidated Architecture**: Related functionality grouped in cohesive classes
- GoogleDrive handles all Drive API operations (search, export, folder resolution)
- GoogleDoc inherits GoogleDrive and adds Docs-specific operations (tab export)

✅ **Single Inheritance**: GoogleDoc extends GoogleDrive to reuse Drive API operations
- Eliminates duplication of API client management
- Natural hierarchy: Docs API is a specialized extension of Drive API

✅ **Dependency Injection**: All dependencies passed via constructor, no singletons

✅ **Facade Pattern**: GoogleDriveService provides simplified interface for common workflows

✅ **Relative Imports**: Within `src/` package, use relative imports only:

```python
# src/services/google_drive/service.py
from .classes import GoogleAuth, GoogleDrive, GoogleDoc
from .models import GoogleDriveFile, SearchResult, GoogleDocumentTab

# src/services/google_drive/classes/google_docs_api.py
from .google_drive_api import GoogleDrive
from .google_drive_authenticator import GoogleAuth
from ..models import GoogleDocumentTab
```

## Error Handling

All methods raise `ValueError` with descriptive messages:
- Missing credentials
- File not found
- Invalid MIME types
- Duplicate folders
- API failures
- Tab metadata fetch failures (gracefully fallback if unavailable)

## Implementation Details: Tab Splitting Strategy

The GoogleDoc `export_tabs()` method follows the strategy from `gdrive_sync` for splitting Google Docs:

1. **Export HTML**: Downloads the full document as `text/html`
2. **Identify Delimiters**: Splits on `<p class="title"` to find section boundaries
3. **Extract Metadata**: Parses title from the first `<p class="title">` element in each chunk
4. **Get Tab IDs**: Uses heading `id` attribute or derives from Docs API metadata
5. **Map Hierarchy**: Uses `parentTabId` when Docs API tabs metadata available
6. **Convert to Markdown**: Uses `markdownify` to convert HTML chunks to markdown
7. **Build URLs**: Constructs deep links to tabs using `#heading_id` anchors

### Graceful Degradation
- If Docs API tabs metadata unavailable, falls back to HTML-only extraction
- Missing heading IDs are replaced with sequential indices
- Parent tab references are optional (flat structure is default)

## Related Files

- Models: `models.py` - Pydantic models for `GoogleDriveFile`, `SearchResult`, `GoogleDocumentTab`
- Tests: Check `/tests/services/google_drive/` for test patterns
