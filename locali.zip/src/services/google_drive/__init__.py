"""Google Drive integration for searching and exporting documents.

This service provides a unified interface for:
- Searching files in Google Drive
- Exporting documents as markdown with optional metadata
- Resolving folder names to IDs

Architecture:
- GoogleAuth: OAuth credential management
- GoogleDrive: Drive API operations (search, export, folder resolution)
- GoogleDoc: Docs API operations (inherits GoogleDrive, adds tab export)
- GoogleDriveService: Unified high-level facade
"""

from .classes import (
    GoogleDoc,
    GoogleDrive,
    GoogleAuth,
    DEFAULT_FOLDER_ID,
)
from .models import GoogleDocumentTab, GoogleDriveFile, SearchResult
from .service import GoogleDriveService

__all__ = [
    "GoogleDriveService",
    "GoogleDrive",
    "GoogleAuth",
    "GoogleDoc",
    "GoogleDriveFile",
    "SearchResult",
    "GoogleDocumentTab",
    "DEFAULT_FOLDER_ID",
]

# Note: upsert_folder utility is available at src.utils.upsert_folder
