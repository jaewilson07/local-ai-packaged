"""Google Drive OAuth authenticator."""

import json
import os

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials


class GoogleAuth:
    """Manages OAuth credentials for Google Drive API access."""

    def __init__(
        self,
        credentials_json: str | None = None,
        token_json: str | None = None,
    ):
        """
        Initialize authenticator with OAuth credentials.

        Args:
            credentials_json: OAuth client configuration JSON (from GDOC_CLIENT env var)
            token_json: Serialized token JSON (from GDOC_TOKEN env var)

        Raises:
            ValueError: If credentials are missing or invalid
        """
        self.credentials_json = credentials_json or os.getenv("GDOC_CLIENT")
        self.token_json = token_json or os.getenv("GDOC_TOKEN")

        if not self.credentials_json or not self.token_json:
            raise ValueError(
                "Missing Google Drive credentials. Set GDOC_CLIENT and GDOC_TOKEN in .env"
            )

        self.creds = self._load_credentials()

    def _load_credentials(self) -> Credentials:
        """Load and refresh OAuth credentials from JSON strings."""
        try:
            token_data = json.loads(self.token_json)
            creds = Credentials(
                token=token_data.get("access_token"),
                refresh_token=token_data.get("refresh_token"),
                token_uri=token_data.get("token_uri"),
                client_id=token_data.get("client_id"),
                client_secret=token_data.get("client_secret"),
                scopes=token_data.get("scopes", []),
            )

            if creds.expired and creds.refresh_token:
                creds.refresh(Request())

            return creds
        except Exception as e:
            raise ValueError(f"Failed to load Google Drive credentials: {e}")

    def get_credentials(self) -> Credentials:
        """Return the loaded OAuth credentials."""
        return self.creds

    def refresh_if_needed(self) -> None:
        """Refresh credentials if they have expired."""
        if self.creds.expired and self.creds.refresh_token:
            self.creds.refresh(Request())


__all__ = ["GoogleAuth"]
