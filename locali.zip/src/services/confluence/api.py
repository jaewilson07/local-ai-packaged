"""Low-level Confluence Cloud API client (minimal)."""

from __future__ import annotations

from typing import List, Optional
import httpx
from bs4 import BeautifulSoup
from src.services.confluence.models import ConfluencePage


class ConfluenceAPI:
    """Minimal async client to fetch pages from Confluence."""

    def __init__(self, base_url: str, token: str) -> None:
        if not base_url:
            raise ValueError("Confluence base_url is required")
        if not token:
            raise ValueError("Confluence token is required")
        self.base_url = base_url.rstrip("/")
        self.token = token
        self._headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }

    async def get_pages(self, cql: str, limit: int = 20) -> List[ConfluencePage]:
        """Query pages using Confluence CQL."""
        url = f"{self.base_url}/wiki/rest/api/content"
        params = {"cql": cql, "expand": "body.storage,version", "limit": limit}
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, params=params, headers=self._headers)
            resp.raise_for_status()
            data = resp.json()
        pages: List[ConfluencePage] = []
        for item in data.get("results", []):
            body = ((item.get("body") or {}).get("storage") or {}).get("value")
            pages.append(
                ConfluencePage(
                    id=item.get("id", ""),
                    title=item.get("title", ""),
                    body_markdown=self._html_to_markdown(body) if body else None,
                    url=f"{self.base_url}/wiki{(item.get('_links') or {}).get('webui', '')}",
                    updated=self._parse_datetime(((item.get("version") or {}).get("when"))),
                    space_key=((item.get("space") or {}).get("key")),
                )
            )
        return pages

    def _parse_datetime(self, value: Optional[str]):
        if not value:
            return None
        try:
            from datetime import datetime

            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except Exception:
            return None

    def _html_to_markdown(self, html: str) -> str:
        # Very lightweight HTML-to-markdown using BeautifulSoup text extraction
        # to avoid heavy dependencies. This strips formatting but preserves text.
        soup = BeautifulSoup(html, "html.parser")
        return soup.get_text("\n")


__all__ = ["ConfluenceAPI"]
