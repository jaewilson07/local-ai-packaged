"""FastAPI router for Confluence service endpoints."""

from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, Field
from fastapi import HTTPException

from src.api.router_registry import create_service_router
from src.services.confluence.service import ConfluenceService, ConfluenceServiceConfig
from src.services.confluence.models import ConfluencePage


# === Request/Response Models ===

class ConfluenceSearchRequest(BaseModel):
    """Request model for Confluence page search."""
    
    base_url: str = Field(..., description="Confluence instance base URL")
    token: str = Field(..., description="Confluence API token or PAT")
    cql: str = Field(default="order by lastmodified desc", description="CQL query string")
    limit: int = Field(default=20, ge=1, le=100, description="Maximum number of results")


class ConfluencePageResponse(BaseModel):
    """Response model for a single Confluence page."""
    
    id: str
    title: str
    space_key: Optional[str] = None
    space_name: Optional[str] = None
    url: Optional[str] = None
    body_storage: Optional[str] = None
    body_markdown: Optional[str] = None
    updated: Optional[str] = None
    version: Optional[int] = None
    
    @classmethod
    def from_confluence_page(cls, page: ConfluencePage) -> "ConfluencePageResponse":
        """Convert ConfluencePage to response model."""
        return cls(
            id=page.id,
            title=page.title,
            space_key=page.space_key,
            space_name=page.space_name,
            url=page.url,
            body_storage=page.body_storage,
            body_markdown=page.body_markdown,
            updated=page.updated.isoformat() if page.updated else None,
            version=page.version,
        )


class ConfluenceSearchResponse(BaseModel):
    """Response model for Confluence search results."""
    
    pages: List[ConfluencePageResponse]
    total: int


class ConfluenceMarkdownRequest(BaseModel):
    """Request model for converting a Confluence page to markdown."""
    
    base_url: str = Field(..., description="Confluence instance base URL")
    token: str = Field(..., description="Confluence API token or PAT")
    page_id: str = Field(..., description="Confluence page ID")


class ConfluenceMarkdownResponse(BaseModel):
    """Response model for Confluence page markdown."""
    
    page_id: str
    title: str
    markdown: str


# === Router Setup ===

router = create_service_router(
    "confluence",
    tags=["confluence", "pages"],
)


# === Endpoints ===

@router.post("/search", response_model=ConfluenceSearchResponse)
async def search_confluence_pages(request: ConfluenceSearchRequest) -> ConfluenceSearchResponse:
    """
    Search Confluence pages using CQL.
    
    This endpoint allows querying Confluence pages with CQL (Confluence Query Language).
    Useful for retrieving pages for ingestion or analysis.
    
    Example CQL queries:
    - `space = SPACE AND type = page`
    - `label = documentation`
    - `created >= now("-30d") order by lastmodified desc`
    """
    try:
        config = ConfluenceServiceConfig(
            base_url=request.base_url,
            token=request.token,
            cql=request.cql,
            limit=request.limit,
        )
        
        service = ConfluenceService(config)
        pages = await service.get_pages()
        
        return ConfluenceSearchResponse(
            pages=[ConfluencePageResponse.from_confluence_page(page) for page in pages],
            total=len(pages),
        )
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to search Confluence pages: {str(e)}")


@router.post("/markdown", response_model=ConfluenceMarkdownResponse)
async def get_page_markdown(request: ConfluenceMarkdownRequest) -> ConfluenceMarkdownResponse:
    """
    Retrieve a Confluence page and convert it to markdown.
    
    This endpoint fetches a single Confluence page by ID and returns
    it in markdown format, suitable for ingestion or processing.
    """
    try:
        config = ConfluenceServiceConfig(
            base_url=request.base_url,
            token=request.token,
            cql=f"id = {request.page_id}",
            limit=1,
        )
        
        service = ConfluenceService(config)
        pages = await service.get_pages()
        
        if not pages:
            raise HTTPException(status_code=404, detail=f"Page not found: {request.page_id}")
        
        page = pages[0]
        markdown = ConfluenceService.to_markdown(page)
        
        return ConfluenceMarkdownResponse(
            page_id=page.id,
            title=page.title,
            markdown=markdown,
        )
        
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to convert page to markdown: {str(e)}")


@router.get("/health")
async def confluence_health() -> dict:
    """Health check endpoint for Confluence service."""
    return {"status": "ok", "service": "confluence"}


__all__ = ["router"]
