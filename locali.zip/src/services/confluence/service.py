"""High-level Confluence service for ingestion-ready pages."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List
from textwrap import dedent
from src.services.confluence.api import ConfluenceAPI
from src.services.confluence.models import ConfluencePage


@dataclass
class ConfluenceServiceConfig:
    """Configuration for Confluence service."""

    base_url: str
    token: str
    cql: str = "order by lastmodified desc"
    limit: int = 20


class ConfluenceService:
    """Service that fetches Confluence pages and renders markdown."""

    def __init__(self, config: ConfluenceServiceConfig) -> None:
        self._config = config
        self._api = ConfluenceAPI(base_url=config.base_url, token=config.token)

    async def get_pages(self) -> List[ConfluencePage]:
        """Fetch pages via CQL."""
        return await self._api.get_pages(self._config.cql, self._config.limit)

    @staticmethod
    def to_markdown(page: ConfluencePage) -> str:
        """Render a Confluence page to markdown/plain text."""
        lines = [
            f"# {page.title}",
            "",
            f"*Space:* {page.space_key or 'Unknown'}",
            f"*Updated:* {page.updated.isoformat() if page.updated else 'Unknown'}",
            f"*URL:* {page.url or 'N/A'}",
            "",
            page.body_markdown or "(No content)",
        ]
        return "\n".join(lines)


__all__ = ["ConfluenceService", "ConfluenceServiceConfig"]
