"""Dataclass models for Confluence integration."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

from src.services.base import BaseApi


@dataclass
class ConfluencePage(BaseApi):
    """Representation of a Confluence page."""

    id: str
    title: str
    body_markdown: Optional[str] = None
    url: Optional[str] = None
    updated: Optional[datetime] = None
    space_key: Optional[str] = None
    _raw: Any = field(default=None, repr=False)
    
    @property
    def raw(self) -> Any:
        """Get the raw API response dict for accessing extended attributes."""
        return self._raw
    
    @classmethod
    def from_dict(cls, obj: dict[str, Any], **kwargs) -> ConfluencePage:
        """
        Create ConfluencePage from API response dictionary.
        
        Args:
            obj: Dictionary containing the API response data
            **kwargs: Additional context (e.g., base_url)
        
        Returns:
            ConfluencePage instance
        """
        # Parse ISO datetime if present
        updated = None
        if obj.get("updated"):
            updated = datetime.fromisoformat(obj["updated"].replace("Z", "+00:00"))
        
        return cls(
            id=obj.get("id", ""),
            title=obj.get("title", ""),
            body_markdown=obj.get("body_markdown"),
            url=obj.get("url"),
            updated=updated,
            space_key=obj.get("space_key"),
            _raw=obj,
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert page to dictionary (excludes raw)."""
        return {
            "id": self.id,
            "title": self.title,
            "body_markdown": self.body_markdown,
            "url": self.url,
            "updated": self.updated.isoformat() if self.updated else None,
            "space_key": self.space_key,
        }


__all__ = ["ConfluencePage"]
