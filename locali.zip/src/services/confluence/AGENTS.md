---
Package: `src/services/confluence`
---

## Identity
- Async Confluence integration (fetch pages via CQL, render markdown/plain text for ingestion).

## Setup
- Requires Confluence base URL and token (bearer) in service config.
- Dependencies: `httpx`, `beautifulsoup4` (for HTML-to-text conversion).

## Key components
- `ConfluenceAPI` → low-level CQL fetch (`/wiki/rest/api/content` with `body.storage` expansion).
- `ConfluenceService` → high-level fetch + `to_markdown(page)` helper.
- `ConfluencePage` → Pydantic model with `title`, `body_markdown`, `updated`, `url`.
- `router.py` → FastAPI router exposing Confluence endpoints at `/services/confluence`:
  - `POST /search` → Search pages via CQL
  - `POST /markdown` → Convert page to markdown by ID
  - `GET /health` → Service health check

## Patterns
- Keep calls async; no globals.
- For ingestion, set `source_id=page.id`, `source_url=page.url`, `source_last_modified=page.updated` in metadata.
- HTML is converted to text via BeautifulSoup; if richer markdown is needed, swap converter but keep it lightweight.
- **Import Pattern**: Use relative imports within `src/` package:
  ```python
  # src/services/confluence/router.py
  from ..base import BaseApi
  from .models import ConfluencePage
  from .service import ConfluenceService
  
  # src/services/confluence/service.py
  from .models import ConfluencePage
  from .api import ConfluenceAPI
  ```

## Gotchas
- Confluence timestamps are ISO strings with Z; parsed in API; verify tz handling when comparing for refresh.
- Large pages: consider truncation or chunking upstream if needed.
