"""High-level Jira service for ingestion-ready data."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List
from src.services.jira.api import JiraAPI
from services.jira.classes.issue import JiraIssue


@dataclass
class JiraServiceConfig:
    """Configuration for Jira service."""

    base_url: str
    token: str
    jql: str = "order by updated DESC"
    limit: int = 20


class JiraService:
    """Service that fetches Jira issues and formats them for ingestion."""

    def __init__(self, config: JiraServiceConfig) -> None:
        self._config = config
        self._api = JiraAPI(base_url=config.base_url, token=config.token)

    async def get_issues(self) -> List[JiraIssue]:
        """Fetch issues via JQL."""
        return await self._api.search(self._config.jql, self._config.limit)


__all__ = ["JiraService", "JiraServiceConfig"]
