"""Low-level Jira API client (minimal stub)."""

from __future__ import annotations

from typing import List, Optional
from datetime import datetime
import httpx
from httpx import HTTPStatusError, RequestError
from src.services.jira.classes.issue import JiraIssue


class JiraAPI:
    """Thin async wrapper over Jira REST API (search issues)."""

    def __init__(self, base_url: str, token: str) -> None:
        """
        Initialize Jira API client.
        
        Args:
            base_url: Jira instance base URL (Cloud or Server)
            token: API token (PAT for Cloud, basic auth for Server)
            
        Raises:
            ValueError: If base_url or token is empty
        """
        if not base_url:
            raise ValueError("Jira base_url is required")
        if not token:
            raise ValueError("Jira token (PAT or basic auth) is required")
        self.base_url = base_url.rstrip("/")
        self.token = token
        self._headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }

    async def search(self, jql: str, limit: int = 20) -> List[JiraIssue]:
        """
        Search Jira issues using JQL and return parsed models.
        
        Args:
            jql: JQL query string
            limit: Maximum number of results to return (default: 20)
            
        Returns:
            List of JiraIssue instances
            
        Raises:
            ValueError: If JQL query is invalid (400) or credentials are invalid (401)
            ConnectionError: If Jira server is unreachable
            HTTPStatusError: If Jira API returns other error codes
        """
        url = f"{self.base_url}/rest/api/3/search"
        params = {"jql": jql, "maxResults": limit}
        
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.get(url, params=params, headers=self._headers)
                resp.raise_for_status()
                data = resp.json()
        except HTTPStatusError as e:
            if e.response.status_code == 400:
                raise ValueError(f"Invalid JQL query: {jql}") from e
            elif e.response.status_code == 401:
                raise ValueError("Invalid Jira credentials") from e
            elif e.response.status_code == 403:
                raise ValueError("Insufficient permissions to access Jira") from e
            elif e.response.status_code == 404:
                raise ValueError(f"Jira endpoint not found: {url}") from e
            raise
        except RequestError as e:
            raise ConnectionError(f"Failed to connect to Jira: {self.base_url}") from e
        
        issues = []
        for raw in data.get("issues", []):
            fields = raw.get("fields", {})
            issues.append(
                JiraIssue(
                    id=raw.get("id", ""),
                    key=raw.get("key", ""),
                    summary=fields.get("summary", ""),
                    description=fields.get("description"),
                    url=f"{self.base_url}/browse/{raw.get('key', '')}",
                    updated=self._parse_datetime(fields.get("updated")),
                    project=fields.get("project", {}).get("key"),
                    issue_type=(fields.get("issuetype") or {}).get("name"),
                )
            )
        return issues

    def _parse_datetime(self, value: Optional[str]) -> Optional[datetime]:
        """
        Parse ISO datetime string from Jira API.
        
        Args:
            value: ISO datetime string (e.g., '2024-01-01T12:00:00.000Z')
            
        Returns:
            datetime object or None if parsing fails
        """
        if not value:
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except Exception:
            return None


__all__ = ["JiraAPI"]
