"""FastAPI router for Jira service endpoints."""

from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, Field
from fastapi import HTTPException

from src.api.router_registry import create_service_router
from src.services.jira.service import JiraService, JiraServiceConfig
from services.jira.classes.issue import JiraIssue


# === Request/Response Models ===

class JiraSearchRequest(BaseModel):
    """Request model for Jira issue search."""
    
    base_url: str = Field(..., description="Jira instance base URL")
    token: str = Field(..., description="Jira API token or PAT")
    jql: str = Field(default="order by updated DESC", description="JQL query string")
    limit: int = Field(default=20, ge=1, le=100, description="Maximum number of results")


class JiraIssueResponse(BaseModel):
    """Response model for a single Jira issue."""
    
    id: str
    key: str
    summary: str
    description: Optional[str] = None
    url: str
    updated: Optional[str] = None
    project: Optional[str] = None
    issue_type: Optional[str] = None
    
    @classmethod
    def from_jira_issue(cls, issue: JiraIssue) -> "JiraIssueResponse":
        """Convert JiraIssue to response model."""
        return cls(
            id=issue.id,
            key=issue.key,
            summary=issue.summary,
            description=issue.description,
            url=issue.url,
            updated=issue.updated.isoformat() if issue.updated else None,
            project=issue.project,
            issue_type=issue.issue_type,
        )


class JiraSearchResponse(BaseModel):
    """Response model for Jira search results."""
    
    issues: List[JiraIssueResponse]
    total: int


# === Router Setup ===

router = create_service_router(
    "jira",
    tags=["jira", "issues"],
)


# === Endpoints ===

@router.post("/search", response_model=JiraSearchResponse)
async def search_jira_issues(request: JiraSearchRequest) -> JiraSearchResponse:
    """
    Search Jira issues using JQL.
    
    This endpoint allows querying Jira issues with JQL (Jira Query Language).
    Useful for retrieving issues for ingestion or analysis.
    
    Example JQL queries:
    - `project = PROJ AND status = Open`
    - `assignee = currentUser() AND resolution = Unresolved`
    - `created >= -30d order by updated DESC`
    """
    try:
        config = JiraServiceConfig(
            base_url=request.base_url,
            token=request.token,
            jql=request.jql,
            limit=request.limit,
        )
        
        service = JiraService(config)
        issues = await service.get_issues()
        
        return JiraSearchResponse(
            issues=[JiraIssueResponse.from_jira_issue(issue) for issue in issues],
            total=len(issues),
        )
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to search Jira issues: {str(e)}")


@router.get("/health")
async def jira_health() -> dict:
    """Health check endpoint for Jira service."""
    return {"status": "ok", "service": "jira"}


__all__ = ["router"]
