"""Jira ticket domain object with CRUD operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from jira.exceptions import JIRAError

from ...base import BaseApi
from .auth import JiraAuth


@dataclass
class JiraTicket(BaseApi):
    """
    Represents a Jira ticket (Story, Task, Bug, etc.) with operations.
    
    Use class methods to fetch or create tickets:
        ticket = JiraTicket.get_by_id(client, "PROJ-123")
        ticket = JiraTicket.create(client, project_key="PROJ", summary="...", ...)
        
    Use instance methods to perform operations:
        ticket.add_comment(client, "Status update")
        ticket.update(client, summary="New title")
    """
    
    key: str
    summary: str
    description: str
    url: str
    project_key: str
    issue_type: str
    labels: list[str] = field(default_factory=list)
    _raw: Any = field(default=None, repr=False)
    
    @property
    def raw(self) -> Any:
        """Get the raw jira.Issue object for accessing extended attributes."""
        return self._raw
    
    @classmethod
    def from_dict(cls, obj: dict[str, Any], **kwargs) -> JiraTicket:
        """
        Create JiraTicket from API response dict or jira.Issue object.
        
        Args:
            obj: Dictionary with ticket data or jira.Issue object
            **kwargs: Additional context (e.g., client, server)
        
        Returns:
            JiraTicket instance
        """
        # Handle jira.Issue object (has .key and .fields attributes)
        if hasattr(obj, "key") and hasattr(obj, "fields"):
            issue = obj
            server = kwargs.get("server") or getattr(kwargs.get("client"), "server", None) or "https://jira.example.com"
            return cls(
                key=issue.key,
                summary=issue.fields.summary,
                description=getattr(issue.fields, "description", "") or "",
                url=f"{server}/browse/{issue.key}",
                project_key=issue.fields.project.key,
                issue_type=issue.fields.issuetype.name,
                labels=getattr(issue.fields, "labels", []),
                _raw=issue,
            )
        
        # Handle dict response
        return cls(
            key=obj.get("key", ""),
            summary=obj.get("summary", ""),
            description=obj.get("description", ""),
            url=obj.get("url", ""),
            project_key=obj.get("project_key", ""),
            issue_type=obj.get("issue_type", ""),
            labels=obj.get("labels", []),
            _raw=obj.get("raw"),
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert ticket to dictionary (excludes raw)."""
        return {
            "key": self.key,
            "summary": self.summary,
            "description": self.description,
            "url": self.url,
            "project_key": self.project_key,
            "issue_type": self.issue_type,
            "labels": self.labels,
        }
    
    @classmethod
    def get_by_id(cls, client: "JiraAuth", ticket_id: str) -> Optional[JiraTicket]:
        """
        Fetch a ticket by its ID/key.
        
        Args:
            client: JiraAuth instance
            ticket_id: Jira ticket key (e.g., 'PROJ-123')
        
        Returns:
            JiraTicket instance or None if not found
        """
        try:
            issue = client.jira.issue(ticket_id)
            return cls.from_dict(issue, server=client.server)
        except JIRAError:
            return None
    
    @classmethod
    def search(cls, client: "JiraAuth", jql: str, max_results: int = 50) -> list[JiraTicket]:
        """
        Search for tickets using JQL.
        
        Args:
            client: JiraAuth instance
            jql: JQL query string
            max_results: Maximum number of results
        
        Returns:
            List of JiraTicket instances
        """
        try:
            issues = client.jira.search_issues(jql, maxResults=max_results)
            return [cls.from_dict(issue, server=client.server) for issue in issues]
        except JIRAError:
            return []
    
    @classmethod
    def create(
        cls,
        client: "JiraAuth",
        project_key: str,
        summary: str,
        description: str,
        issue_type: str = "Story",
        labels: Optional[list[str]] = None,
        **extra_fields,
    ) -> JiraTicket:
        """
        Create a new Jira ticket.
        
        Args:
            client: JiraAuth instance
            project_key: Jira project key (e.g., 'PROJ')
            summary: Ticket title
            description: Ticket description
            issue_type: Issue type name (default: 'Story')
            labels: List of labels
            **extra_fields: Additional Jira fields (e.g., assignee, priority)
        
        Returns:
            Created JiraTicket instance
        
        Raises:
            JIRAError: If ticket creation fails
        """
        labels = labels or []
        
        fields = {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": issue_type},
            "labels": labels,
        }
        fields.update(extra_fields)
        
        new_issue = client.jira.create_issue(fields=fields)
        return cls.from_dict(new_issue, server=client.server)
    
    @classmethod
    def upsert(
        cls,
        client: "JiraAuth",
        project_key: str,
        summary: str,
        description: str,
        issue_type: str = "Story",
        labels: Optional[list[str]] = None,
        search_labels: Optional[list[str]] = None,
        **extra_fields,
    ) -> tuple[JiraTicket, bool]:
        """
        Create or update a ticket. Searches for existing ticket by labels.
        
        Args:
            client: JiraAuth instance
            project_key: Jira project key
            summary: Ticket title
            description: Ticket description
            issue_type: Issue type name
            labels: Labels to apply
            search_labels: Labels to search for existing ticket (defaults to labels)
            **extra_fields: Additional Jira fields
        
        Returns:
            Tuple of (JiraTicket, created) where created is True if new ticket
        """
        labels = labels or []
        search_labels = search_labels or labels
        
        # Search for existing ticket by labels
        existing = cls._find_by_labels(client, project_key, search_labels)
        
        if existing:
            # Update existing
            existing.update(client, summary=summary, description=description, labels=labels, **extra_fields)
            return existing, False
        else:
            # Create new
            ticket = cls.create(
                client,
                project_key=project_key,
                summary=summary,
                description=description,
                issue_type=issue_type,
                labels=labels,
                **extra_fields,
            )
            return ticket, True
    
    @classmethod
    def _find_by_labels(
        cls, client: "JiraAuth", project_key: str, labels: list[str]
    ) -> Optional[JiraTicket]:
        """Find ticket by labels (internal helper)."""
        if not labels:
            return None
        
        label_conditions = " AND ".join([f'labels = "{label}"' for label in labels])
        jql = f"project = {project_key} AND {label_conditions} ORDER BY created DESC"
        
        results = cls.search(client, jql, max_results=1)
        return results[0] if results else None
    
    def add_comment(self, client: "JiraAuth", comment: str) -> bool:
        """
        Add a comment to this ticket.
        
        Args:
            client: JiraAuth instance
            comment: Comment text
        
        Returns:
            True if successful, False otherwise
        """
        try:
            client.jira.add_comment(self.key, comment)
            return True
        except JIRAError:
            return False
    
    def update(self, client: "JiraAuth", **fields) -> None:
        """
        Update ticket fields.
        
        Args:
            client: JiraAuth instance
            **fields: Fields to update (e.g., summary="New title", labels=["tag"])
        
        Raises:
            JIRAError: If update fails
        """
        if self._raw:
            self._raw.update(fields=fields)
            
            # Update local fields
            if "summary" in fields:
                self.summary = fields["summary"]
            if "description" in fields:
                self.description = fields["description"]
            if "labels" in fields:
                self.labels = fields["labels"]
        else:
            # Fetch issue first if we don't have raw
            issue = client.jira.issue(self.key)
            issue.update(fields=fields)
            self._raw = issue
    
    def create_subtask(
        self,
        client: "JiraAuth",
        summary: str,
        description: str,
        labels: Optional[list[str]] = None,
        **extra_fields,
    ) -> JiraTicket:
        """
        Create a subtask under this ticket.
        
        Args:
            client: JiraAuth instance
            summary: Subtask title
            description: Subtask description
            labels: List of labels
            **extra_fields: Additional Jira fields
        
        Returns:
            Created JiraTicket (subtask) instance
        """
        labels = labels or []
        
        fields = {
            "project": {"key": self.project_key},
            "parent": {"key": self.key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": "Sub-task"},
            "labels": labels,
        }
        fields.update(extra_fields)
        
        subtask = client.jira.create_issue(fields=fields)
        return JiraTicket.from_dict(subtask, server=client.server)


__all__ = ["JiraTicket"]
