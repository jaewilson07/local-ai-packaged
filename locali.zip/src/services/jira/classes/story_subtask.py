"""Jira subtask dataclass model."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class JiraSubtask:
    """Represents a Jira subtask to be created under a parent Story."""

    summary: str
    description: str
    additional_labels: List[str] = field(default_factory=list)

    def get_full_labels(self, parent_labels: List[str]) -> List[str]:
        """
        Get merged labels from parent and additional labels.

        Args:
            parent_labels: Labels from parent Story

        Returns:
            Combined list of unique labels (parent + additional)
        """
        return sorted(set(parent_labels + self.additional_labels))
