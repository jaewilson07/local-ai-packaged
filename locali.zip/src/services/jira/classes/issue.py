"""Jira issue domain object - base class for all Jira issue types."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

from jira.exceptions import JIRAError

from ...base import BaseApi

from .auth import JiraAuth


@dataclass
class JiraIssue(BaseApi):
    """
    Base class for all Jira issue types (Story, Task, Bug, Epic, etc.).
    
    Provides common CRUD operations that all issue types inherit.
    Use class methods to fetch or create:
        issue = JiraIssue.get_by_id(client, "PROJ-123")
        issue = JiraIssue.create(client, project_key="PROJ", summary="...", ...)
        
    Use instance methods to perform operations:
        issue.add_comment(client, "Status update")
        issue.update(client, summary="New title")
    """

    key: str
    summary: str
    description: str
    url: str
    project_key: str
    issue_type: str
    labels: list[str] = field(default_factory=list)
    id: Optional[str] = None
    updated: Optional[datetime] = None
    _raw: Any = field(default=None, repr=False)
    
    @property
    def raw(self) -> Any:
        """Get the raw jira.Issue object for accessing extended attributes."""
        return self._raw
    
    @classmethod
    def from_dict(cls, obj: dict[str, Any], **kwargs) -> JiraIssue:
        """
        Create JiraIssue from API response dict or jira.Issue object.
        
        Args:
            obj: Dictionary with issue data or jira.Issue object
            **kwargs: Additional context (e.g., server)
        
        Returns:
            JiraIssue instance
        """
        # Handle jira.Issue object (has .key and .fields attributes)
        if hasattr(obj, "key") and hasattr(obj, "fields"):
            issue = obj
                # Prefer server from kwargs (when called from tests), otherwise use client.server if provided
                server = kwargs.get("server") or getattr(kwargs.get("client"), "server", None) or "https://jira.example.com"
            return cls(
                key=issue.key,
                summary=issue.fields.summary,
                description=getattr(issue.fields, "description", "") or "",
                url=f"{server}/browse/{issue.key}",
                project_key=issue.fields.project.key,
                issue_type=issue.fields.issuetype.name,
                labels=getattr(issue.fields, "labels", []),
                id=getattr(issue, "id", None),
                updated=datetime.fromisoformat(issue.fields.updated.replace("Z", "+00:00")) if hasattr(issue.fields, "updated") else None,
                _raw=issue,
            )
        
        # Handle dict response
        return cls(
            key=obj.get("key", ""),
            summary=obj.get("summary", ""),
            description=obj.get("description", ""),
            url=obj.get("url", ""),
            project_key=obj.get("project_key", obj.get("project", "")),
            issue_type=obj.get("issue_type", ""),
            labels=obj.get("labels", []),
            id=obj.get("id"),
            updated=obj.get("updated"),
            _raw=obj.get("raw"),
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert issue to dictionary (excludes raw)."""
        return {
            "id": self.id,
            "key": self.key,
            "summary": self.summary,
            "description": self.description,
            "url": self.url,
            "project_key": self.project_key,
            "issue_type": self.issue_type,
            "labels": self.labels,
            "updated": self.updated.isoformat() if self.updated else None,
        }
    
    @classmethod
    def get_by_id(cls, client: "JiraAuth", issue_id: str) -> Optional[JiraIssue]:
        """
        Fetch an issue by its ID/key.
        
        Args:
            client: JiraAuth instance
            issue_id: Jira issue key (e.g., 'PROJ-123')
        
        Returns:
            JiraIssue instance or None if not found
        """
        try:
            issue = client.jira.issue(issue_id)
            return cls.from_dict(issue, server=client.server)
        except JIRAError:
            return None
    
    @classmethod
    def search(cls, client: "JiraAuth", jql: str, max_results: int = 50) -> list[JiraIssue]:
        """
        Search for issues using JQL.
        
        Args:
            client: JiraAuth instance
            jql: JQL query string
            max_results: Maximum number of results
        
        Returns:
            List of JiraIssue instances
        """
        try:
            issues = client.jira.search_issues(jql, maxResults=max_results)
            return [cls.from_dict(issue, server=client.server) for issue in issues]
        except JIRAError:
            return []
    
    @classmethod
    def create(
        cls,
        client: "JiraAuth",
        project_key: str,
        summary: str,
        description: str,
        issue_type: str = "Story",
        labels: Optional[list[str]] = None,
        **extra_fields,
    ) -> JiraIssue:
        """
        Create a new Jira issue.
        
        Args:
            client: JiraAuth instance
            project_key: Jira project key (e.g., 'PROJ')
            summary: Issue title
            description: Issue description
            issue_type: Issue type name (default: 'Story')
            labels: List of labels
            **extra_fields: Additional Jira fields (e.g., assignee, priority)
        
        Returns:
            Created JiraIssue instance
        
        Raises:
            JIRAError: If issue creation fails
        """
        labels = labels or []
        
        fields = {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": issue_type},
            "labels": labels,
        }
        fields.update(extra_fields)
        
        new_issue = client.jira.create_issue(fields=fields)
        return cls.from_dict(new_issue, server=client.server)
    
    @classmethod
    def upsert(
        cls,
        client: "JiraAuth",
        project_key: str,
        summary: str,
        description: str,
        issue_type: str = "Story",
        labels: Optional[list[str]] = None,
        search_labels: Optional[list[str]] = None,
        **extra_fields,
    ) -> tuple[JiraIssue, bool]:
        """
        Create or update an issue. Searches for existing issue by labels.
        
        Args:
            client: JiraAuth instance
            project_key: Jira project key
            summary: Issue title
            description: Issue description
            issue_type: Issue type name
            labels: Labels to apply
            search_labels: Labels to search for existing issue (defaults to labels)
            **extra_fields: Additional Jira fields
        
        Returns:
            Tuple of (JiraIssue, created) where created is True if new issue
        """
        labels = labels or []
        search_labels = search_labels or labels
        
        # Search for existing issue by labels
        existing = cls._find_by_labels(client, project_key, search_labels)
        
        if existing:
            # Update existing
            existing.update(client, summary=summary, description=description, labels=labels, **extra_fields)
            return existing, False
        else:
            # Create new
            issue = cls.create(
                client,
                project_key=project_key,
                summary=summary,
                description=description,
                issue_type=issue_type,
                labels=labels,
                **extra_fields,
            )
            return issue, True
    
    @classmethod
    def _find_by_labels(
        cls, client: "JiraAuth", project_key: str, labels: list[str]
    ) -> Optional[JiraIssue]:
        """Find issue by labels (internal helper)."""
        if not labels:
            return None
        
        label_conditions = " AND ".join([f'labels = "{label}"' for label in labels])
        jql = f"project = {project_key} AND {label_conditions} ORDER BY created DESC"
        
        results = cls.search(client, jql, max_results=1)
        return results[0] if results else None
    
    def add_comment(self, client: "JiraAuth", comment: str) -> bool:
        """
        Add a comment to this issue.
        
        Args:
            client: JiraAuth instance
            comment: Comment text
        
        Returns:
            True if successful, False otherwise
        """
        try:
            client.jira.add_comment(self.key, comment)
            return True
        except JIRAError:
            return False
    
    def update(self, client: "JiraAuth", **fields) -> None:
        """
        Update issue fields.
        
        Args:
            client: JiraAuth instance
            **fields: Fields to update (e.g., summary="New title", labels=["tag"])
        
        Raises:
            JIRAError: If update fails
        """
        if self._raw:
            self._raw.update(fields=fields)
            
            # Update local fields
            if "summary" in fields:
                self.summary = fields["summary"]
            if "description" in fields:
                self.description = fields["description"]
            if "labels" in fields:
                self.labels = fields["labels"]
        else:
            # Fetch issue first if we don't have raw
            issue = client.jira.issue(self.key)
            issue.update(fields=fields)
            self._raw = issue
    
    def create_subtask(
        self,
        client: "JiraAuth",
        summary: str,
        description: str,
        labels: Optional[list[str]] = None,
        **extra_fields,
    ) -> JiraIssue:
        """
        Create a subtask under this issue.
        
        Args:
            client: JiraAuth instance
            summary: Subtask title
            description: Subtask description
            labels: List of labels
            **extra_fields: Additional Jira fields
        
        Returns:
            Created JiraIssue (subtask) instance
        """
        labels = labels or []
        
        fields = {
            "project": {"key": self.project_key},
            "parent": {"key": self.key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": "Sub-task"},
            "labels": labels,
        }
        fields.update(extra_fields)
        
        subtask = client.jira.create_issue(fields=fields)
        return JiraIssue.from_dict(subtask, server=client.server)

    def to_markdown(self) -> str:
        """Render this Jira issue to markdown for ingestion."""
        lines = [
            f"# {self.key} - {self.summary}",
            "",
            f"*Project:* {self.project_key or 'Unknown'}",
            f"*Type:* {self.issue_type or 'Unknown'}",
            f"*Updated:* {self.updated.isoformat() if self.updated else 'Unknown'}",
            f"*URL:* {self.url or 'N/A'}",
            "",
            self.description or "(No description)",
        ]
        return "\n".join(lines)


__all__ = ["JiraIssue"]
