"""
Jira client for authentication and connection management.

Handles only authentication concerns. All ticket operations are delegated
to domain objects (JiraTicket, JiraEpic, JiraStory).
"""

import base64
import os
from dotenv import load_dotenv
from typing import Optional

from jira import JIRA
from ...settings import load_settings


class JiraAuth:
    """
    Authentication-only client for Jira API.
    
    Handles credentials and connection management. All CRUD operations
    are implemented on domain objects (JiraIssue, JiraEpic, JiraStory)
    via class methods and instance methods that accept this client.
    
    Example:
        >>> client = JiraAuth(server="https://jira.company.com")
        >>> issue = JiraIssue.get_by_id(client, "PROJ-123")
        >>> issue.add_comment(client, "Updated status")
    """

    def __init__(self, server: Optional[str] = None):
        """
        Initialize Jira client with credentials from environment.

        Args:
            server: Jira server URL (e.g., 'https://jira.company.com')
            
        Raises:
            ValueError: If JIRA_TOKEN not found in environment or server is empty
        """
        # Prefer explicit parameter, then environment, then settings, then fallback to example
        load_dotenv()
        server = server or os.getenv("JIRA_SERVER")
        if not server:
            try:
                settings = load_settings()
                server = settings.jira_server
            except Exception:
                server = None

        if not server:
            # No production or corporate URL should be hardcoded here; use a neutral example
            server = "https://jira.example.com"

        # Decode JIRA_TOKEN from base64 (format: email:api_token)
        encoded_token: str | None = os.getenv("JIRA_TOKEN")
        if not encoded_token:
            raise ValueError("JIRA_TOKEN not found in .env file")

        decoded_token: str = base64.b64decode(encoded_token).decode("utf-8")
        email: str
        api_token: str
        email, api_token = decoded_token.split(":", 1)

        self.server: str = server
        self.email: str = email
        self.jira: JIRA = JIRA(server=server, basic_auth=(email, api_token))
