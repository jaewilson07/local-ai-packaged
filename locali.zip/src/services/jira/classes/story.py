"""Jira story dataclass model with Epic linking and subtask creation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .auth import JiraAuth
from .issue import JiraIssue
from .story_subtask import JiraSubtask


@dataclass
class JiraStory(JiraIssue):
    """
    Jira Story - extends JiraIssue with Epic linking and subtask creation.
    
    Inherits all CRUD operations from JiraIssue.
    
    Story-specific:
        - Epic linking via link_to_epic()
        - Bulk subtask creation via create_subtasks()
    """

    epic_key: Optional[str] = None
    subtasks: list[JiraSubtask] = field(default_factory=list)
    
    @classmethod
    def create_with_subtasks(
        cls,
        client: "JiraAuth",
        project_key: str,
        summary: str,
        description: str,
        epic_key: Optional[str] = None,
        subtasks: Optional[list[JiraSubtask]] = None,
        labels: Optional[list[str]] = None,
        **extra_fields,
    ) -> JiraStory:
        """
        Create a Story and optionally link to epic and create subtasks.
        
        Args:
            client: JiraAuth instance
            project_key: Jira project key
            summary: Story title
            description: Story description
            epic_key: Epic key to link to (optional)
            subtasks: List of JiraSubtask to create (optional)
            labels: List of labels
            **extra_fields: Additional Jira fields
        
        Returns:
            Created JiraStory instance
        """
        # Create base issue using inherited create()
        issue = super(JiraStory, cls).create(
            client,
            project_key=project_key,
            summary=summary,
            description=description,
            issue_type="Story",
            labels=labels or [],
            **extra_fields,
        )
        
        # Convert to JiraStory
        story = cls(
            key=issue.key,
            summary=issue.summary,
            description=issue.description,
            url=issue.url,
            project_key=issue.project_key,
            issue_type=issue.issue_type,
            labels=issue.labels,
            epic_key=epic_key,
            subtasks=subtasks or [],
            id=issue.id,
            updated=issue.updated,
            _raw=issue.raw,
        )
        
        return story
    
    def link_to_epic(self, client: "JiraAuth", epic_key: Optional[str] = None) -> bool:
        """
        Link this story to an Epic.
        
        Args:
            client: JiraAuth instance
            epic_key: Epic key to link to (uses self.epic_key if not provided)
        
        Returns:
            True if successful
            
        Raises:
            ValueError: If no epic_key provided and self.epic_key is None
            JIRAError: If linking fails
        """
        # Import here to avoid circular dependency
        from .epic import JiraEpic
        
        if not self.key:
            raise ValueError("Story must be created before linking to epic")
        
        target_epic_key = epic_key or self.epic_key
        if not target_epic_key:
            raise ValueError("epic_key must be provided or set on JiraStory")
        
        epic = JiraEpic.get_by_id(client, target_epic_key)
        if not epic:
            raise ValueError(f"Epic {target_epic_key} not found")
        
        return epic.link_issue(client, self.key)
    
    def create_subtasks(self, client: "JiraAuth") -> list[JiraIssue]:
        """
        Create all subtasks under this story.
        
        Args:
            client: JiraAuth instance
        
        Returns:
            List of created JiraIssue (subtask) instances
            
        Raises:
            ValueError: If story not created yet
            JIRAError: If subtask creation fails
        """
        if not self.key:
            raise ValueError("Story must be created before creating subtasks")
        
        created_subtasks = []
        for subtask in self.subtasks:
            # Merge parent and additional labels
            full_labels = subtask.get_full_labels(self.labels)
            
            # Use inherited create_subtask method
            issue = self.create_subtask(
                client,
                summary=subtask.summary,
                description=subtask.description,
                labels=full_labels,
            )
            created_subtasks.append(issue)
        
        return created_subtasks


__all__ = ["JiraStory"]
