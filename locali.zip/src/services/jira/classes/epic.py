"""Jira epic domain object with epic-specific operations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from jira.exceptions import JIRAError

from .auth import JiraAuth
from .issue import JiraIssue




@dataclass
class JiraEpic(JiraIssue):
    """
    Jira Epic - extends JiraIssue with epic-specific operations.
    
    Inherits all CRUD operations from JiraIssue.
    
    Epic-specific methods:
        epics = JiraEpic.search(client, "PROJ", "migration")
        field_id = JiraEpic.get_custom_field_id(client)
        epic.link_issue(client, "PROJ-123")
    """
    
    @classmethod
    def search(cls, client: "JiraAuth", project_key: str, query: str) -> list[JiraEpic]:
        """
        Search for Epics in a project.
        
        Args:
            client: JiraAuth instance
            project_key: Jira project key (e.g., 'PROJ')
            query: Search query (matches summary or key)
        
        Returns:
            List of JiraEpic instances
        """
        jql = f'project = {project_key} AND issuetype = Epic AND (summary ~ "{query}" OR key = "{query}")'
        
        try:
            issues = client.jira.search_issues(jql)
            return [cls.from_dict(issue, server=client.server) for issue in issues]
        except JIRAError:
            return []
    
    @classmethod
    def get_by_id(cls, client: "JiraAuth", epic_key: str) -> Optional[JiraEpic]:
        """
        Fetch an epic by its key.
        
        Args:
            client: JiraAuth instance
            epic_key: Epic key (e.g., 'PROJ-100')
        
        Returns:
            JiraEpic instance or None if not found or not an epic
        """
        try:
            issue = client.jira.issue(epic_key)
            if issue.fields.issuetype.name != "Epic":
                return None
            return cls.from_dict(issue, server=client.server)
        except JIRAError:
            return None
    
    @classmethod
    def get_custom_field_id(cls, client: "JiraAuth") -> str:
        """
        Discover the Epic Link custom field ID.
        
        Args:
            client: JiraAuth instance
        
        Returns:
            Field ID string (e.g., 'customfield_10014')
        
        Raises:
            ValueError: If Epic Link field cannot be found
        """
        fields = client.jira.fields()
        
        for field in fields:
            field_name = field.get("name", "").lower()
            field_schema = field.get("schema", {})
            custom = field_schema.get("custom", "")
            
            # Check if this is the Epic Link field
            if "epic link" in field_name or "epiclink" in custom.lower():
                return field["id"]
        
        raise ValueError("Epic Link field not found in Jira instance")
    
    def link_issue(self, client: "JiraAuth", issue_key: str) -> bool:
        """
        Link an issue to this epic.
        
        Args:
            client: JiraAuth instance
            issue_key: Issue key to link (e.g., 'PROJ-123')
        
        Returns:
            True if successful
        
        Raises:
            ValueError: If Epic Link field cannot be found
            JIRAError: If the API request fails
        """
        epic_field = self.get_custom_field_id(client)
        
        issue = client.jira.issue(issue_key)
        issue.update(fields={epic_field: self.key})
        
        return True


__all__ = ["JiraEpic"]
