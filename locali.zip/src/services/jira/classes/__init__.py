"""Jira service classes.

Hierarchy:
- JiraIssue: Base class for all issue types (Story, Task, Bug, Epic, etc.)
  - JiraEpic: Epic-specific operations (link_issue, search epics)
  - JiraStory: Story-specific operations (link_to_epic, create_subtasks)

Note: JiraTicket is deprecated - use JiraIssue as the base class.
"""

from .auth import JiraAuth
from .epic import JiraEpic
from .issue import JiraIssue
from .story import JiraStory
from .story_subtask import JiraSubtask
from .ticket import JiraTicket

__all__ = [
    "JiraAuth",
    "JiraEpic",
    "JiraIssue",
    "JiraStory",
    "JiraSubtask",
    "JiraTicket",
]
