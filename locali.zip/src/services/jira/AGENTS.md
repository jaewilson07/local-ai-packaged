---
Package: `src/services/jira`
---

## Identity
- Async Jira integration (search issues via JQL, render markdown for ingestion).
- Provides FastAPI router and MCP tools for Jira operations.

## Setup
- Environment: Provide Jira base URL and token (PAT or OAuth bearer) when initializing services.
- Dependencies: `httpx`, `jira` (python-jira library).
- Authentication: `JiraAuth` class handles credential management via JIRA_TOKEN env var (base64-encoded email:token).

## Key Components

### API Layer
- **`JiraAPI`** - Low-level REST wrapper for `/rest/api/3/search` endpoint
  - Comprehensive error handling (400, 401, 403, 404 errors)
  - Timeout configuration (30s default)
  - Type-safe with full docstrings

### Service Layer
- **`JiraService`** - High-level operations with `JiraServiceConfig`
  - Async issue fetching via JQL
  - Configurable result limits and query strings

### Domain Models (all inherit from `BaseApi`)
- **`JiraIssue`** - Base class for all issue types
  - CRUD operations: `get_by_id()`, `search()`, `create()`, `upsert()`
  - Instance methods: `add_comment()`, `update()`, `create_subtask()`
  - Markdown rendering via `to_markdown()`
- **`JiraEpic`** - Epic-specific operations (epic search and linking)
- **`JiraStory`** - Story-specific operations (epic linking, bulk subtask creation)
- **`JiraAuth`** - Authentication-only client (credentials from environment)
  - **Required parameter**: `server` URL (no hardcoded defaults)

### Router Layer
- **`router.py`** - FastAPI endpoints at `/services/jira`:
  - `POST /search` - Search issues via JQL
  - `GET /health` - Service health check
  - Auto-registered via `router_registry.discover_service_routers()`

### MCP Tools Layer
- **`mcp_tools.py`** - MCP-compatible tool wrappers:
  - `mcp_search_jira_issues()` - Search via JQL, returns JSON
  - `mcp_get_jira_issue_markdown()` - Get issue as markdown
  - Registered in `src/mcp/server.py` as `@server.tool()` decorators

## Patterns

### Type Safety
- All functions have complete type annotations
- No `TYPE_CHECKING` imports - uses string annotations: `client: "JiraAuth"`
- All domain models use `@dataclass` (not Pydantic BaseModel)

### Error Handling
```python
try:
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(url, params=params, headers=self._headers)
        resp.raise_for_status()
except HTTPStatusError as e:
    if e.response.status_code == 400:
        raise ValueError(f"Invalid JQL query: {jql}") from e
    elif e.response.status_code == 401:
        raise ValueError("Invalid Jira credentials") from e
except RequestError as e:
    raise ConnectionError(f"Failed to connect to Jira: {self.base_url}") from e
```

### Import Pattern
Use absolute imports with `src.` prefix:
```python
# CORRECT
from src.services.jira.classes.issue import JiraIssue
from src.services.jira.service import JiraService
from src.services.base import BaseApi

# WRONG
from services.jira.classes.issue import JiraIssue  # Missing src.
```

### Domain Object Pattern
Client classes handle ONLY authentication. Domain objects own their operations:
```python
# Fetch or create
issue = JiraIssue.get_by_id(client, "PROJ-123")
issue = JiraIssue.create(client, project_key="PROJ", summary="...")

# Perform operations
issue.add_comment(client, "Status update")
issue.update(client, summary="New title")
```

## Gotchas
- **Server URL Required**: `JiraAuth` requires explicit `server` parameter (no defaults)
- **Import Paths**: Always use `from src.services.jira...` (not `from services.jira...`)
- **Timestamps**: Parsed to datetime objects, timezone aware (UTC)
- **Rate Limits**: Respect Jira API rate limits; consider pagination for large queries
- **Authentication**: JIRA_TOKEN must be base64-encoded `email:api_token` format
- **Error Types**: Catch `ValueError` for validation, `ConnectionError` for network issues
- **Deprecated Classes**: `JiraTicket` is deprecated - use `JiraIssue` instead
