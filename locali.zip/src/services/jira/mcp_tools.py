"""MCP tool wrappers for Jira service."""

from __future__ import annotations

from typing import Optional
import json
import logging

logger = logging.getLogger(__name__)


async def mcp_search_jira_issues(
    base_url: str,
    token: str,
    jql: str = "order by updated DESC",
    limit: int = 20
) -> str:
    """
    Search Jira issues via MCP.
    
    Args:
        base_url: Jira instance URL (e.g., 'https://jira.company.com')
        token: API token (PAT for Cloud, basic auth for Server)
        jql: JQL query string (default: 'order by updated DESC')
        limit: Maximum number of results (default: 20, max: 100)
        
    Returns:
        JSON string with search results
        
    Example:
        >>> result = await mcp_search_jira_issues(
        ...     base_url="https://jira.company.com",
        ...     token="api_token_here",
        ...     jql="project = PROJ AND status = Open",
        ...     limit=10
        ... )
    """
    from src.services.jira.service import JiraService, JiraServiceConfig
    
    try:
        config = JiraServiceConfig(
            base_url=base_url,
            token=token,
            jql=jql,
            limit=min(limit, 100)  # Cap at 100
        )
        
        service = JiraService(config)
        issues = await service.get_issues()
        
        results = [
            {
                "key": issue.key,
                "summary": issue.summary,
                "description": issue.description,
                "url": issue.url,
                "updated": issue.updated.isoformat() if issue.updated else None,
                "project": issue.project,
                "issue_type": issue.issue_type
            }
            for issue in issues
        ]
        
        return json.dumps({"issues": results, "total": len(results)}, indent=2)
        
    except ValueError as e:
        logger.error("jira_search_validation_error", error=str(e))
        return json.dumps({"error": f"Validation error: {str(e)}"})
    except ConnectionError as e:
        logger.error("jira_search_connection_error", error=str(e))
        return json.dumps({"error": f"Connection error: {str(e)}"})
    except Exception as e:
        logger.exception("jira_search_failed", error=str(e))
        return json.dumps({"error": f"Failed to search Jira issues: {str(e)}"})


async def mcp_get_jira_issue_markdown(
    base_url: str,
    token: str,
    issue_key: str
) -> str:
    """
    Get a Jira issue formatted as markdown via MCP.
    
    Args:
        base_url: Jira instance URL
        token: API token
        issue_key: Jira issue key (e.g., 'PROJ-123')
        
    Returns:
        JSON string with markdown content
        
    Example:
        >>> result = await mcp_get_jira_issue_markdown(
        ...     base_url="https://jira.company.com",
        ...     token="api_token_here",
        ...     issue_key="PROJ-123"
        ... )
    """
    from src.services.jira.service import JiraService, JiraServiceConfig
    
    try:
        config = JiraServiceConfig(
            base_url=base_url,
            token=token,
            jql=f"key = {issue_key}",
            limit=1
        )
        
        service = JiraService(config)
        issues = await service.get_issues()
        
        if not issues:
            return json.dumps({"error": f"Issue not found: {issue_key}"})
        
        issue = issues[0]
        markdown = issue.to_markdown()
        
        return json.dumps({
            "issue_key": issue.key,
            "title": issue.summary,
            "markdown": markdown
        }, indent=2)
        
    except ValueError as e:
        logger.error("jira_markdown_validation_error", issue_key=issue_key, error=str(e))
        return json.dumps({"error": f"Validation error: {str(e)}"})
    except ConnectionError as e:
        logger.error("jira_markdown_connection_error", issue_key=issue_key, error=str(e))
        return json.dumps({"error": f"Connection error: {str(e)}"})
    except Exception as e:
        logger.exception("jira_markdown_failed", issue_key=issue_key, error=str(e))
        return json.dumps({"error": f"Failed to get issue markdown: {str(e)}"})


__all__ = [
    "mcp_search_jira_issues",
    "mcp_get_jira_issue_markdown",
]
