"""MongoDB RAG Agent - Intelligent Knowledge Base Search."""
