"""Filesystem utility functions."""

from pathlib import Path


def upsert_folder(folder_path: str | Path) -> Path:
    """
    Ensure a folder exists, creating it if necessary.

    This is a convenience function that creates a directory and all parent
    directories if they don't exist (similar to mkdir -p).

    Args:
        folder_path: Path to the folder to create

    Returns:
        Path object for the created/existing folder

    Example:
        >>> output_dir = upsert_folder("./output/data")
        >>> print(output_dir.exists())
        True
    """
    path = Path(folder_path)
    path.mkdir(parents=True, exist_ok=True)
    return path


__all__ = ["upsert_folder"]
