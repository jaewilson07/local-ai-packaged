"""Differential refresh utilities for document re-ingestion.

Compares stored document metadata with current source state and triggers
re-ingestion when the source has changed. Supports local files by comparing
filesystem mtime, and allows callers to provide custom fetchers for remote
sources (e.g., Jira, Confluence).
"""

from __future__ import annotations

import os
from datetime import datetime
from typing import Awaitable, Callable, Dict, Optional, Any, List
from pymongo.collection import Collection
from bson import ObjectId

from src.workflows.ingestion.ingest import DocumentIngestionPipeline, IngestionResult

RemoteMetadataFetcher = Callable[[Dict[str, Any]], Awaitable[Optional[Dict[str, Any]]]]


async def refresh_outdated_documents(
    pipeline: DocumentIngestionPipeline,
    documents_collection: Collection,
    remote_metadata_fetcher: Optional[RemoteMetadataFetcher] = None,
) -> list[IngestionResult]:
    """Refresh documents whose sources have changed.

    Args:
        pipeline: Initialized ingestion pipeline
        documents_collection: Mongo collection for documents
        remote_metadata_fetcher: Optional async callable to fetch fresh metadata
            for non-file sources. It receives the stored document dict and should
            return a dict containing updated fields (at least `source_last_modified`
            and optionally `content`, `source_url`, `source_id`). Return None to
            skip refresh for that document.

    Returns:
        List of IngestionResult for refreshed documents.
    """

    results: List[IngestionResult] = []
    cursor = documents_collection.find({})
    docs = await cursor.to_list(length=None)

    for doc in docs:
        doc_id = doc.get("_id")
        source = doc.get("source")
        source_last_modified = doc.get("source_last_modified")
        last_ingested_at = doc.get("last_ingested_at")

        if not source:
            continue

        needs_refresh = False

        # First, attempt remote metadata fetcher if provided
        if remote_metadata_fetcher:
            fresh_meta = await remote_metadata_fetcher(doc)
            if fresh_meta and fresh_meta.get("source_last_modified"):
                fresh_time = fresh_meta["source_last_modified"]
                if isinstance(fresh_time, str):
                    try:
                        fresh_time = datetime.fromisoformat(fresh_time)
                    except ValueError:
                        fresh_time = None
                if fresh_time and (not source_last_modified or fresh_time > source_last_modified):
                    needs_refresh = True
            if needs_refresh:
                # If remote fetcher also provides content, we could bypass filesystem
                # ingestion; for simplicity we re-run pipeline ingestion below.
                pass

        # Fallback: check local filesystem mtime when source maps to documents folder
        if not needs_refresh:
            local_path = os.path.join(pipeline.documents_folder, source)
            if os.path.exists(local_path):
                mtime = datetime.fromtimestamp(os.path.getmtime(local_path))
                if source_last_modified is None or mtime > source_last_modified:
                    needs_refresh = True

        if not needs_refresh:
            continue

        # Re-ingest the single document
        try:
            ingest_result = await pipeline.ingest_file(os.path.join(pipeline.documents_folder, source))
            # Update last_ingested_at in collection
            await documents_collection.update_one(
                {"_id": ObjectId(doc_id)},
                {"$set": {"last_ingested_at": datetime.now()}}
            )
            results.append(ingest_result)
        except Exception:
            continue

    return results


__all__ = ["refresh_outdated_documents", "RemoteMetadataFetcher"]
