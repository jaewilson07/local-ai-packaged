---
Package: `src/`
---

## Package identity
- Library code mirroring `examples/`, intended for production use and import by applications.
- Primary tech: Python, Pydantic AI, Motor, Docling.
 - Also hosts FastAPI (`src/api`), MCP (`src/mcp`), graph services (`src/graph`, `src/services/neo4j`), and external connectors (Google Drive, Jira, Confluence).

## Setup & run

```powershell
uv venv
.venv\Scripts\activate
uv pip install -e .

# Run CLI (src variant if needed)
uv run python -m src.cli
```

## Patterns & conventions
- Organization:
  - Agent and CLI: `src/agent.py`, `src/cli.py`
  - Tools: `src/tools.py`
  - Ingestion: `src/ingestion/ingest.py`
- Naming & types:
  - Strong typing across module boundaries; Pydantic models for documents/chunks/results
  - Async I/O and robust error handling for Motor operations- **Import Pattern**: Use relative imports within `src/` package:
  ```python
  # src/workflows/rag/agent.py
  from .dependencies import AgentDependencies
  from .tools import semantic_search, hybrid_search
  from ...settings import load_settings
  
  # src/workflows/rag/tools.py
  from .dependencies import AgentDependencies
  from ...settings import load_settings
  
  # src/workflows/ingestion/ingest.py
  from .chunker import create_chunker, ChunkingConfig
  from .embedder import create_embedder
  from ...settings import load_settings
  ```- Preferred patterns:
  - ✅ DO: Keep public APIs stable; document changes in PRs.
  - ✅ DO: Centralize settings in `src/settings.py` (Pydantic Settings).
  - ✅ DO: Use `$rankFusion` rather than manual score mixing.
  - ❌ DON’T: Duplicate logic between `examples/` and `src/` — refactor shared code into `src/` and import in `examples/`.

## Touch points / key files
- CLI: `src/cli.py`
- Agent: `src/agent.py`
- Tools: `src/tools.py`
- Ingestion: `src/ingestion/ingest.py`
- Refresh helper: `src/ingestion/refresh.py`
- Chunking: `src/ingestion/chunker.py`
- Embedding: `src/ingestion/embedder.py`
- Settings: `src/settings.py`
- Providers: `src/providers.py`
- API: `src/api/main.py`
- MCP: `src/mcp/server.py`
- Graph: `src/graph/*`, `src/services/neo4j/*`
- Services: `src/services/google_drive`, `src/services/jira`, `src/services/confluence`

## JIT index hints
```bash
rg -n "def (semantic_search|hybrid_search)" src/tools.py
rg -n "OperationFailure|ConnectionFailure" src
rg -n "BaseSettings|Field|ConfigDict" src/settings.py
rg -n "Docling|HybridChunker" src/ingestion
```

## Common gotchas
- Keep async boundaries consistent; avoid mixing sync calls in async code.
- Handle Atlas index errors gracefully and instruct users to configure indexes.
- Validate `.env` via `src/test_config.py` before running E2E tests.
- spaCy model required when `enable_entity_extraction` is true; spaCy currently targets Python 3.11–3.12 (Pydantic v1 dep breaks on 3.14).


## Pre-PR checks
```powershell
uv run pytest test_scripts -v
uv run python -m src.cli --help
```
