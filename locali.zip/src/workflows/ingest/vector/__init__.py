"""Document ingestion pipeline for MongoDB RAG Agent."""
