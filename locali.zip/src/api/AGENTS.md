---
Package: `src/api`
---

## Package identity
- FastAPI HTTP layer for the MongoDB RAG Agent (search, ingest, refresh, documents listing, document processing, entity search, conversational chat).
- Async-only; authentication is deferred for now.

## Setup & run
- Start dev server: `uv run uvicorn src.api.main:app --reload`
- Health check: `GET /health`
- API docs: `http://localhost:8000/docs`

## Endpoints (current)

### Core RAG Endpoints
- `POST /search` → `{query, match_count?, search_type=semantic|text|hybrid}`; delegates to `semantic_search`, `text_search`, `hybrid_search` in `src.tools`.
- `POST /ingest` → `{documents_path?, clean_before_ingest?, chunk_size?, chunk_overlap?, max_tokens?, enable_entities?}`; runs `DocumentIngestionPipeline`.
- `POST /refresh` → `{documents_path?}`; calls `refresh_outdated_documents`.
- `GET /documents?limit=` → lists documents with `source_id`, `source_url`, `source_last_modified`, `last_ingested_at`.
- `GET /health` → `{status:"ok"}`.

### Document Processing Endpoints (NEW)
- `POST /convert` → `{file_path}`; converts documents (PDF, DOCX, PPTX, HTML, etc.) to markdown using Docling. Returns `{markdown, title, file_type}`.
- `POST /chunk` → `{file_path, chunk_size?, chunk_overlap?, max_tokens?}`; previews document chunking before ingestion. Returns `{chunks, total_chunks, avg_tokens, title}`.
- `POST /transcribe` → `{file_path}`; transcribes audio files (MP3, WAV, M4A, FLAC) using Whisper ASR. Requires FFmpeg. Returns `{transcript, title}`.

### Knowledge Graph Endpoints (NEW)
- `GET /entities/{name}?depth=2` → searches entities in Neo4j knowledge graph. Returns `{entities, relationships, depth}`. Requires Neo4j configured.

### Conversational Endpoint (NEW)
- `POST /chat` → `{message, history?, stream=true}`; conversational interface with Pydantic AI agent.
  - When `stream=true`: Returns Server-Sent Events (SSE) with event types: `start`, `text`, `tool_call`, `tool_result`, `done`, `error`.
  - When `stream=false`: Returns `{response, tool_calls}` after completion.
  - Media type for streaming: `text/event-stream`

## Patterns & conventions
- Keep handlers thin: validate input, delegate to pipelines/tools, return Pydantic models from `src/api/models.py`.
- Always await cleanup for resource-heavy operations (ingestion initializes Mongo/Neo4j when enabled).
- No auth yet—leave hooks for future middleware/dependencies.
- Map search results to `SearchResultModel` (chunk_id, document_id, title, source, similarity, metadata).
- Streaming uses SSE (Server-Sent Events) for broad client compatibility; events are JSON-encoded with `type` and `data` fields.
- File paths in requests should be absolute or relative to server working directory; validate existence before processing.
- **Import Pattern**: Use relative imports within `src/` package:
  ```python
  # src/api/main.py
  from ..workflows.rag.tools import semantic_search, hybrid_search
  from ..workflows.ingestion.ingest import DocumentIngestionPipeline
  from .models import SearchRequest, SearchResponse
  from .router_registry import register_routers
  
  # src/api/router_registry.py
  from ..services.jira.router import router as jira_router
  from ..services.confluence.router import router as confluence_router
  ```

## Router registration pattern

### Creating a new service router

1. Create `src/services/{service_name}/router.py`
2. Use the `create_service_router()` wrapper:

```python
from src.api.router_registry import create_service_router

router = create_service_router("my_service", tags=["my_service"])

@router.get("/endpoint")
async def my_endpoint():
    return {"status": "ok"}
```

3. Export the router: `__all__ = ["router"]`
4. Router will be auto-discovered and registered at `/services/{service_name}`

### Auto-registration

- Routers are discovered from `src/services/*/router.py` files
- Each router must export a `router` variable (APIRouter instance)
- Registered at startup with prefix `/services/{service_name}`
- Tags default to service name if not specified

### Manual registration (advanced)

```python
from src.api.router_registry import RouterConfig, register_routers

custom_routers = [
    RouterConfig(
        name="custom",
        router=my_router,
        prefix="/custom/path",
        tags=["custom"],
    )
]

register_routers(app, custom_routers)
```

### Service routers

Current services with routers:
- **Jira** (`/services/jira`): Search issues via JQL, health check
- **Confluence** (`/services/confluence`): Search pages via CQL, convert to markdown, health check

## Gotchas
- Ingestion can be long-running; avoid CPU-bound work in handlers.
- spaCy model required when `enable_entity_extraction` is true; use Python 3.11–3.12 due to spaCy/Pydantic v1.
- Atlas indexes must exist; surface friendly messages on `OperationFailure` code 291.
- Audio transcription requires FFmpeg in PATH; returns 500 if FFmpeg missing or file corrupted.
- Docling conversion may fail for unsupported/corrupted files; catch exceptions and return 404/500.
- Entity search returns empty results if Neo4j not configured (no error raised).
- Streaming chat requires client support for Server-Sent Events; test with `curl` or browser EventSource API.
- Large documents may timeout on conversion/chunking; consider async task queue for production.

## Pre-PR checks (API)
- Manual smoke: run server and hit `/health`, `/search`, `/chat`.
- Test streaming with: `curl -N http://localhost:8000/chat -H "Content-Type: application/json" -d '{"message":"test","stream":true}'`
- Test service routers: `/services/jira/health`, `/services/confluence/health`
