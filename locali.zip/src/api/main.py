"""FastAPI application exposing search, ingest, refresh, and health endpoints."""

from __future__ import annotations

import logging
import os
import json
import asyncio
from typing import List, AsyncGenerator
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic_ai import Agent
from pydantic_ai.messages import PartDeltaEvent, PartStartEvent, TextPartDelta

from src.api.router_registry import register_routers
from src.api.models import (
    HealthResponse,
    SearchRequest,
    SearchResponse,
    SearchResultModel,
    IngestRequest,
    IngestResponse,
    RefreshRequest,
    RefreshResponse,
    DocumentsResponse,
    DocumentRecord,
    ConvertRequest,
    ConvertResponse,
    ChunkPreviewRequest,
    ChunkPreviewResponse,
    ChunkData,
    TranscribeRequest,
    TranscribeResponse,
    EntitySearchRequest,
    EntitySearchResponse,
    EntityData,
    RelationshipData,
    ChatRequest,
    ChatResponse,
)
from src.workflows.rag.dependencies import AgentDependencies
from src.workflows.rag.tools import semantic_search, text_search, hybrid_search
from src.workflows.ingestion.ingest import DocumentIngestionPipeline, IngestionConfig
from src.workflows.ingest.vector.chunker import ChunkingConfig, create_chunker
from src.workflows.ingestion.refresh import refresh_outdated_documents
from src.settings import load_settings
from src.workflows.rag.agent import rag_agent, RAGState
from pydantic_ai.ag_ui import StateDeps

logger = logging.getLogger(__name__)

app = FastAPI(title="MongoDB RAG Agent API", version="0.1.0")

# Auto-register all service routers
register_routers(app)


async def get_agent_deps() -> AgentDependencies:
    """Dependency that initializes AgentDependencies per request."""
    deps = AgentDependencies()
    await deps.initialize()
    return deps


@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    """Simple health check endpoint."""
    return HealthResponse()


@app.post("/search", response_model=SearchResponse)
async def search(request: SearchRequest, deps: AgentDependencies = Depends(get_agent_deps)) -> SearchResponse:
    """Search the knowledge base using semantic, text, or hybrid search."""
    class DepsWrapper:
        def __init__(self, inner):
            self.deps = inner

    wrapper = DepsWrapper(deps)

    if request.search_type == "semantic":
        results = await semantic_search(wrapper, request.query, request.match_count)
    elif request.search_type == "text":
        results = await text_search(wrapper, request.query, request.match_count)
    else:
        results = await hybrid_search(wrapper, request.query, request.match_count)

    await deps.cleanup()

    result_models = [
        SearchResultModel(
            chunk_id=r.chunk_id,
            document_id=r.document_id,
            document_title=r.document_title,
            document_source=r.document_source,
            content=r.content,
            similarity=r.similarity,
            metadata=r.metadata,
        )
        for r in results
    ]
    return SearchResponse(results=result_models)


@app.post("/ingest", response_model=IngestResponse)
async def ingest(request: IngestRequest) -> IngestResponse:
    """Ingest documents from a folder path into MongoDB (with optional entity extraction)."""
    config = IngestionConfig(
        chunk_size=request.chunk_size,
        chunk_overlap=request.chunk_overlap,
        max_chunk_size=request.chunk_size * 2,
        max_tokens=request.max_tokens,
    )
    pipeline = DocumentIngestionPipeline(
        config=config,
        documents_folder=request.documents_path,
        clean_before_ingest=request.clean_before_ingest,
    )

    # Optional override for entity extraction flag
    if request.enable_entities is not None:
        pipeline.enable_entity_extraction = request.enable_entities

    await pipeline.initialize()
    results = await pipeline.ingest_documents()
    await pipeline.close()

    return IngestResponse(
        documents_processed=len(results),
        total_chunks=sum(r.chunks_created for r in results),
        errors=sum(len(r.errors) for r in results),
    )


@app.post("/refresh", response_model=RefreshResponse)
async def refresh(request: RefreshRequest) -> RefreshResponse:
    """Refresh documents whose source has changed (local mtime or remote fetcher)."""
    settings = load_settings()
    # Reuse ingestion pipeline without cleaning
    config = IngestionConfig()
    pipeline = DocumentIngestionPipeline(
        config=config,
        documents_folder=request.documents_path,
        clean_before_ingest=False,
    )
    await pipeline.initialize()
    docs_collection = pipeline.db[settings.mongodb_collection_documents]
    results = await refresh_outdated_documents(pipeline, docs_collection)
    await pipeline.close()
    return RefreshResponse(refreshed=len(results))


@app.get("/documents", response_model=DocumentsResponse)
async def list_documents(limit: int = 100) -> DocumentsResponse:
    """List ingested documents with basic metadata."""
    deps = AgentDependencies()
    await deps.initialize()
    settings = deps.settings
    docs_collection = deps.db[settings.mongodb_collection_documents]
    cursor = docs_collection.find({}).limit(limit)
    docs = await cursor.to_list(length=limit)
    await deps.cleanup()

    records: List[DocumentRecord] = []
    for doc in docs:
        records.append(
            DocumentRecord(
                id=str(doc.get("_id")),
                title=doc.get("title", ""),
                source=doc.get("source", ""),
                source_id=doc.get("source_id"),
                source_url=doc.get("source_url"),
                source_last_modified=(
                    doc.get("source_last_modified").isoformat()
                    if doc.get("source_last_modified")
                    else None
                ),
                last_ingested_at=(
                    doc.get("last_ingested_at").isoformat()
                    if doc.get("last_ingested_at")
                    else None
                ),
            )
        )

    return DocumentsResponse(documents=records)


@app.post("/convert", response_model=ConvertResponse)
async def convert_document(request: ConvertRequest) -> ConvertResponse:
    """Convert a document to markdown format using Docling.
    
    Supports PDF, DOCX, PPTX, HTML, and other formats.
    """
    try:
        if not os.path.exists(request.file_path):
            raise HTTPException(status_code=404, detail=f"File not found: {request.file_path}")
        
        config = IngestionConfig()
        pipeline = DocumentIngestionPipeline(
            config=config,
            documents_folder=".",
            clean_before_ingest=False,
        )
        
        # Use the pipeline's _read_document method
        markdown_content, _ = pipeline._read_document(request.file_path)
        
        # Extract title
        title = pipeline._extract_title(markdown_content, request.file_path)
        
        # Get file type
        file_type = os.path.splitext(request.file_path)[1].lstrip('.')
        
        return ConvertResponse(
            markdown=markdown_content,
            title=title,
            file_type=file_type
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("convert_document_failed", file_path=request.file_path)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/chunk", response_model=ChunkPreviewResponse)
async def preview_chunks(request: ChunkPreviewRequest) -> ChunkPreviewResponse:
    """Preview how a document will be chunked before ingestion.
    
    Useful for tuning chunk_size and overlap parameters.
    """
    try:
        if not os.path.exists(request.file_path):
            raise HTTPException(status_code=404, detail=f"File not found: {request.file_path}")
        
        # Create pipeline and read document
        config = IngestionConfig(
            chunk_size=request.chunk_size,
            chunk_overlap=request.chunk_overlap,
            max_chunk_size=request.chunk_size * 2,
            max_tokens=request.max_tokens
        )
        pipeline = DocumentIngestionPipeline(
            config=config,
            documents_folder=".",
            clean_before_ingest=False,
        )
        
        markdown_content, docling_doc = pipeline._read_document(request.file_path)
        title = pipeline._extract_title(markdown_content, request.file_path)
        
        # Create chunker and chunk the document
        chunker_config = ChunkingConfig(
            chunk_size=request.chunk_size,
            chunk_overlap=request.chunk_overlap,
            max_chunk_size=request.chunk_size * 2,
            max_tokens=request.max_tokens
        )
        chunker = create_chunker(chunker_config)
        chunks = chunker.chunk_document(markdown_content, docling_doc)
        
        # Format chunk data
        chunk_data = [
            ChunkData(
                index=chunk.index,
                content=chunk.content,
                token_count=chunk.token_count,
                context=chunk.metadata.get("context", "")
            )
            for chunk in chunks
        ]
        
        avg_tokens = sum(c.token_count for c in chunks) / len(chunks) if chunks else 0
        
        return ChunkPreviewResponse(
            chunks=chunk_data,
            total_chunks=len(chunks),
            avg_tokens=round(avg_tokens, 2),
            title=title
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("preview_chunks_failed", file_path=request.file_path)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/transcribe", response_model=TranscribeResponse)
async def transcribe_audio(request: TranscribeRequest) -> TranscribeResponse:
    """Transcribe an audio file using Whisper ASR via Docling.
    
    Supports MP3, WAV, M4A, FLAC formats. Requires FFmpeg installed.
    """
    try:
        if not os.path.exists(request.file_path):
            raise HTTPException(status_code=404, detail=f"File not found: {request.file_path}")
        
        config = IngestionConfig()
        pipeline = DocumentIngestionPipeline(
            config=config,
            documents_folder=".",
            clean_before_ingest=False,
        )
        
        # Use the pipeline's _transcribe_audio method
        transcript, _ = pipeline._transcribe_audio(request.file_path)
        
        # Extract title from filename
        title = os.path.splitext(os.path.basename(request.file_path))[0]
        
        return TranscribeResponse(
            transcript=transcript,
            title=title
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("transcribe_audio_failed", file_path=request.file_path)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/entities/{name}", response_model=EntitySearchResponse)
async def search_entities(name: str, depth: int = 2) -> EntitySearchResponse:
    """Search for entities in the Neo4j knowledge graph.
    
    Returns entities and their relationships up to the specified depth.
    Requires Neo4j to be configured and enabled.
    """
    try:
        from src.workflows.rag.agent import search_related_entities
        
        # Call the agent's graph search tool (bypassing ctx)
        result_str = await search_related_entities(ctx=None, entity_name=name, depth=depth)
        
        # Parse the result string (it's formatted as JSON)
        try:
            result_data = json.loads(result_str)
        except json.JSONDecodeError:
            # Fallback if result is not JSON
            return EntitySearchResponse(
                entities=[],
                relationships=[],
                depth=depth
            )
        
        # Convert to response model
        entities = [
            EntityData(
                name=e.get("name", ""),
                type=e.get("type", ""),
                properties=e.get("properties", {})
            )
            for e in result_data.get("entities", [])
        ]
        
        relationships = [
            RelationshipData(
                from_entity=r.get("from_entity", ""),
                to_entity=r.get("to_entity", ""),
                relationship_type=r.get("relationship_type", ""),
                properties=r.get("properties", {})
            )
            for r in result_data.get("relationships", [])
        ]
        
        return EntitySearchResponse(
            entities=entities,
            relationships=relationships,
            depth=depth
        )
        
    except Exception as e:
        logger.exception("search_entities_failed", name=name)
        raise HTTPException(status_code=500, detail=str(e))


async def stream_agent_response(
    message: str,
    history: List,
) -> AsyncGenerator[str, None]:
    """Stream agent responses as Server-Sent Events.
    
    Yields JSON events with type and data fields.
    """
    try:
        # Create agent state
        state = RAGState()
        deps = StateDeps[RAGState](state=state)
        
        # Stream the agent execution
        async with rag_agent.iter(
            message,
            deps=deps,
            message_history=history
        ) as run:
            
            async for node in run:
                
                # Handle user prompt node
                if Agent.is_user_prompt_node(node):
                    pass  # Clean start
                
                # Handle model request node - stream the thinking process
                elif Agent.is_model_request_node(node):
                    # Send start event
                    yield f"data: {json.dumps({'type': 'start', 'data': {}})}\n\n"
                    
                    # Stream model request events
                    async with node.stream(run.ctx) as request_stream:
                        async for event in request_stream:
                            # Handle text part start events
                            if isinstance(event, PartStartEvent) and event.part.part_kind == 'text':
                                initial_text = event.part.content
                                if initial_text:
                                    yield f"data: {json.dumps({'type': 'text', 'data': initial_text})}\n\n"
                            
                            # Handle text delta events for streaming
                            elif isinstance(event, PartDeltaEvent) and isinstance(event.delta, TextPartDelta):
                                delta_text = event.delta.content_delta
                                if delta_text:
                                    yield f"data: {json.dumps({'type': 'text', 'data': delta_text})}\n\n"
                
                # Handle tool calls
                elif Agent.is_call_tools_node(node):
                    async with node.stream(run.ctx) as tool_stream:
                        async for event in tool_stream:
                            event_type = type(event).__name__
                            
                            if event_type == "FunctionToolCallEvent":
                                # Extract tool information
                                tool_name = "Unknown Tool"
                                args = None
                                
                                if hasattr(event, 'part'):
                                    part = event.part
                                    
                                    if hasattr(part, 'tool_name'):
                                        tool_name = part.tool_name
                                    elif hasattr(part, 'function_name'):
                                        tool_name = part.function_name
                                    elif hasattr(part, 'name'):
                                        tool_name = part.name
                                    
                                    if hasattr(part, 'args'):
                                        args = part.args
                                    elif hasattr(part, 'arguments'):
                                        args = part.arguments
                                
                                # Send tool call event
                                yield f"data: {json.dumps({'type': 'tool_call', 'data': {'tool': tool_name, 'args': args}})}\n\n"
                            
                            elif event_type == "FunctionToolResultEvent":
                                # Send tool result event
                                yield f"data: {json.dumps({'type': 'tool_result', 'data': {'status': 'completed'}})}\n\n"
                
                # Handle end node
                elif Agent.is_end_node(node):
                    pass
        
        # Send completion event
        yield f"data: {json.dumps({'type': 'done', 'data': {}})}\n\n"
        
    except Exception as e:
        logger.exception("stream_agent_error", message=message)
        yield f"data: {json.dumps({'type': 'error', 'data': str(e)})}\n\n"


@app.post("/chat")
async def chat(request: ChatRequest):
    """Conversational endpoint with streaming support.
    
    When stream=True, returns Server-Sent Events with incremental responses.
    When stream=False, returns complete response after processing.
    """
    try:
        # Convert chat history to pydantic_ai message format
        # For now, we'll use an empty history as the conversion is complex
        # Future improvement: properly convert ChatMessage to pydantic_ai messages
        message_history = []
        
        if request.stream:
            # Return SSE stream
            return StreamingResponse(
                stream_agent_response(request.message, message_history),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no"  # Disable nginx buffering
                }
            )
        else:
            # Non-streaming response
            state = RAGState()
            deps = StateDeps[RAGState](state=state)
            
            result = await rag_agent.run(
                request.message,
                deps=deps,
                message_history=message_history
            )
            
            # Extract tool calls (simplified)
            tool_calls = []
            
            return ChatResponse(
                response=result.output,
                tool_calls=tool_calls
            )
        
    except Exception as e:
        logger.exception("chat_failed", message=request.message)
        raise HTTPException(status_code=500, detail=str(e))


@app.exception_handler(Exception)
async def handle_exceptions(exc: Exception):
    logger.exception("api_error", exc_info=exc)
    return JSONResponse(status_code=500, content={"error": str(exc)})


__all__ = ["app"]
