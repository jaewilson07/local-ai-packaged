"""API package for FastAPI endpoints."""
