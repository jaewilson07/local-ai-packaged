"""Pydantic models for FastAPI endpoints."""

from __future__ import annotations

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = Field(default="ok")


class SearchRequest(BaseModel):
    """Request body for search endpoint."""

    query: str = Field(..., description="Search query text")
    match_count: int = Field(default=5, description="Number of results to return")
    search_type: str = Field(default="hybrid", description="semantic|text|hybrid")


class SearchResultModel(BaseModel):
    """Search result entry."""

    chunk_id: str
    document_id: str
    document_title: str
    document_source: str
    content: str
    similarity: float
    metadata: dict


class SearchResponse(BaseModel):
    """Response body for search endpoint."""

    results: List[SearchResultModel]


class IngestRequest(BaseModel):
    """Request to ingest documents from a folder."""

    documents_path: str = Field(default="documents", description="Path to documents folder")
    clean_before_ingest: bool = Field(default=False, description="Whether to clear collections before ingest")
    chunk_size: int = Field(default=1000)
    chunk_overlap: int = Field(default=200)
    max_tokens: int = Field(default=512)
    enable_entities: bool = Field(default=None, description="Override settings.enable_entity_extraction")


class IngestResponse(BaseModel):
    """Response for ingestion endpoint."""

    documents_processed: int
    total_chunks: int
    errors: int


class RefreshRequest(BaseModel):
    """Request to refresh outdated documents."""

    documents_path: str = Field(default="documents")


class RefreshResponse(BaseModel):
    """Response for refresh endpoint."""

    refreshed: int


class DocumentRecord(BaseModel):
    """Minimal document info from MongoDB."""

    id: str
    title: str
    source: str
    source_id: Optional[str] = None
    source_url: Optional[str] = None
    source_last_modified: Optional[str] = None
    last_ingested_at: Optional[str] = None


class DocumentsResponse(BaseModel):
    """Response listing documents."""

    documents: List[DocumentRecord]


class ConvertRequest(BaseModel):
    """Request to convert a document to markdown."""

    file_path: str = Field(..., description="Path to the document file")


class ConvertResponse(BaseModel):
    """Response for document conversion."""

    markdown: str = Field(..., description="Converted markdown content")
    title: str = Field(..., description="Extracted document title")
    file_type: str = Field(..., description="Original file type")


class ChunkPreviewRequest(BaseModel):
    """Request to preview document chunking."""

    file_path: str = Field(..., description="Path to the document file")
    chunk_size: int = Field(default=1000, description="Target chunk size in characters")
    chunk_overlap: int = Field(default=200, description="Overlap between chunks")
    max_tokens: int = Field(default=512, description="Maximum tokens per chunk")


class ChunkData(BaseModel):
    """Individual chunk data for preview."""

    index: int
    content: str
    token_count: int
    context: Optional[str] = None


class ChunkPreviewResponse(BaseModel):
    """Response for chunk preview."""

    chunks: List[ChunkData]
    total_chunks: int
    avg_tokens: float
    title: str


class TranscribeRequest(BaseModel):
    """Request to transcribe audio file."""

    file_path: str = Field(..., description="Path to the audio file")


class TranscribeResponse(BaseModel):
    """Response for audio transcription."""

    transcript: str = Field(..., description="Transcribed text in markdown format")
    title: str = Field(..., description="Audio file name")


class EntitySearchRequest(BaseModel):
    """Request to search entities in knowledge graph."""

    name: str = Field(..., description="Entity name to search for")
    depth: int = Field(default=2, description="Graph traversal depth")


class EntityData(BaseModel):
    """Entity information."""

    name: str
    type: str
    properties: Dict[str, Any] = Field(default_factory=dict)


class RelationshipData(BaseModel):
    """Relationship between entities."""

    from_entity: str
    to_entity: str
    relationship_type: str
    properties: Dict[str, Any] = Field(default_factory=dict)


class EntitySearchResponse(BaseModel):
    """Response for entity search."""

    entities: List[EntityData]
    relationships: List[RelationshipData]
    depth: int


class ChatMessage(BaseModel):
    """Chat message for conversational endpoint."""

    role: str = Field(..., description="Message role: 'user' or 'assistant'")
    content: str = Field(..., description="Message content")


class ChatRequest(BaseModel):
    """Request for chat endpoint."""

    message: str = Field(..., description="User message")
    history: List[ChatMessage] = Field(default_factory=list, description="Conversation history")
    stream: bool = Field(default=True, description="Whether to stream response")


class ChatResponse(BaseModel):
    """Response for non-streaming chat."""

    response: str = Field(..., description="Assistant response")
    tool_calls: List[Dict[str, Any]] = Field(default_factory=list, description="Tools called during response")


__all__ = [
    "HealthResponse",
    "SearchRequest",
    "SearchResponse",
    "SearchResultModel",
    "IngestRequest",
    "IngestResponse",
    "RefreshRequest",
    "RefreshResponse",
    "DocumentRecord",
    "DocumentsResponse",
    "ConvertRequest",
    "ConvertResponse",
    "ChunkPreviewRequest",
    "ChunkData",
    "ChunkPreviewResponse",
    "TranscribeRequest",
    "TranscribeResponse",
    "EntitySearchRequest",
    "EntityData",
    "RelationshipData",
    "EntitySearchResponse",
    "ChatMessage",
    "ChatRequest",
    "ChatResponse",
]
