"""Router registry for auto-discovering and registering service routers."""

from __future__ import annotations

import importlib
import logging
from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass
from fastapi import APIRouter, FastAPI

logger = logging.getLogger(__name__)


@dataclass
class RouterConfig:
    """Configuration metadata for a service router."""
    
    name: str
    router: APIRouter
    prefix: str
    tags: Optional[List[str]] = None
    

def discover_service_routers(services_path: str = "src.services") -> List[RouterConfig]:
    """
    Discover all router.py files in src/services/ and load their APIRouter instances.
    
    Args:
        services_path: Base path for services (default: "src.services")
        
    Returns:
        List of RouterConfig instances with router metadata
        
    Example:
        >>> routers = discover_service_routers()
        >>> for config in routers:
        ...     print(f"Found router: {config.name} at {config.prefix}")
    """
    routers: List[RouterConfig] = []
    
    # Get the services directory path
    src_path = Path(__file__).parent.parent
    services_dir = src_path / "services"
    
    if not services_dir.exists():
        logger.warning(f"Services directory not found: {services_dir}")
        return routers
    
    # Scan each service directory
    for service_dir in services_dir.iterdir():
        if not service_dir.is_dir() or service_dir.name.startswith("_"):
            continue
            
        router_file = service_dir / "router.py"
        if not router_file.exists():
            logger.debug(f"No router.py found in {service_dir.name}")
            continue
        
        service_name = service_dir.name
        module_path = f"{services_path}.{service_name}.router"
        
        try:
            # Import the router module
            module = importlib.import_module(module_path)
            
            # Look for 'router' attribute (standard FastAPI pattern)
            if not hasattr(module, "router"):
                logger.warning(f"No 'router' attribute found in {module_path}")
                continue
            
            router = getattr(module, "router")
            if not isinstance(router, APIRouter):
                logger.warning(f"'router' in {module_path} is not an APIRouter instance")
                continue
            
            # Extract tags from router or use service name
            tags = router.tags if router.tags else [service_name]
            
            # Create router config with /services/{service_name} prefix
            config = RouterConfig(
                name=service_name,
                router=router,
                prefix=f"/services/{service_name}",
                tags=tags,
            )
            
            routers.append(config)
            logger.info(f"Discovered router: {service_name} -> {config.prefix}")
            
        except Exception as e:
            logger.error(f"Failed to load router from {module_path}: {e}")
            continue
    
    return routers


def register_routers(app: FastAPI, routers: Optional[List[RouterConfig]] = None) -> None:
    """
    Register all discovered routers with the FastAPI app.
    
    Args:
        app: FastAPI application instance
        routers: Optional list of RouterConfig instances. If None, will auto-discover.
        
    Example:
        >>> app = FastAPI()
        >>> register_routers(app)
    """
    if routers is None:
        routers = discover_service_routers()
    
    for config in routers:
        app.include_router(
            config.router,
            prefix=config.prefix,
            tags=config.tags,
        )
        logger.info(f"Registered router: {config.name} at {config.prefix}")


def create_service_router(
    service_name: str,
    *,
    tags: Optional[List[str]] = None,
    dependencies: Optional[List] = None,
) -> APIRouter:
    """
    Convenience wrapper to create a service router with consistent configuration.
    
    This function provides a standardized way to create routers for services,
    ensuring consistent tag and dependency patterns across the API.
    
    Args:
        service_name: Name of the service (e.g., "jira", "confluence")
        tags: Optional list of OpenAPI tags (defaults to [service_name])
        dependencies: Optional list of FastAPI dependencies
        
    Returns:
        Configured APIRouter instance
        
    Example:
        >>> # In src/services/jira/router.py
        >>> from src.api.router_registry import create_service_router
        >>> 
        >>> router = create_service_router("jira", tags=["jira", "issues"])
        >>> 
        >>> @router.get("/search")
        >>> async def search_issues():
        ...     return {"results": []}
    """
    if tags is None:
        tags = [service_name]
    
    router = APIRouter(
        tags=tags,
        dependencies=dependencies or [],
    )
    
    return router


__all__ = [
    "RouterConfig",
    "discover_service_routers",
    "register_routers",
    "create_service_router",
]
