"""MCP integration package."""
