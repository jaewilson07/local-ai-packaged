---
Package: `src/mcp`
---

## Package identity
- MCP server scaffolding to expose RAG tools (search, ingest, refresh, document processing, entity search) to MCP clients (e.g., Claude Desktop, Cline).
- Optional dependency: `mcp` package must be installed by the host.

## Setup & run
- Install MCP package if needed: `uv pip install mcp`
- Run server: `uv run python -c "import asyncio; from src.mcp.server import run_server; asyncio.run(run_server())"`

## Tools exposed

### Core RAG Tools
- `search(query, match_count=5, search_type="hybrid")` → delegates to `search_knowledge_base`.
- `ingest(documents_path="documents", clean_before_ingest=False)` → runs ingestion pipeline.
- `refresh(documents_path="documents")` → runs differential refresh via `refresh_outdated_documents`.

### Document Processing Tools (NEW)
- `convert_document(file_path)` → Converts documents (PDF, DOCX, PPTX, HTML, etc.) to markdown using Docling. Returns JSON with markdown content, title, and file type.
- `preview_chunks(file_path, chunk_size=1000, chunk_overlap=200, max_tokens=512)` → Previews how a document will be chunked before ingestion. Useful for tuning chunk parameters. Returns JSON with chunk data, token counts, and statistics.
- `transcribe_audio(file_path)` → Transcribes audio files (MP3, WAV, M4A, FLAC) using Whisper ASR via Docling. Requires FFmpeg. Returns JSON with transcript and title.

### Knowledge Graph Tools (NEW)
- `search_entities(name, depth=2)` → Searches for entities in the Neo4j knowledge graph and returns related entities and relationships up to the specified depth. Requires Neo4j to be configured.

## Patterns & conventions
- Keep MCP handlers thin; delegate to existing agent/pipeline functions.
- Do not add auth yet; rely on host environment security.
- Ensure ingestion/refresh calls clean up resources (pipelines handle init/close internally).
- New tools return JSON strings for structured data to be easily parsed by MCP clients.
- Error handling: All tools catch exceptions and return JSON with error field rather than raising.
- **Import Pattern**: Use relative imports within `src/` package:
  ```python
  # src/mcp/server.py
  from ..workflows.rag.tools import search_knowledge_base
  from ..workflows.ingestion.ingest import DocumentIngestionPipeline
  from ..workflows.ingestion.refresh import refresh_outdated_documents
  from ..settings import load_settings
  ```

## Gotchas
- Missing `mcp` dependency will raise an ImportError; keep the message user-friendly.
- spaCy model required if entity extraction is enabled during ingestion (Python 3.11–3.12 recommended).
- Audio transcription requires FFmpeg installed and accessible in PATH.
- Document conversion supports formats via Docling: PDF, DOCX, PPTX, XLSX, HTML, MD.
- Entity search requires Neo4j to be running and configured in settings.
- Chunk preview uses the same chunker as ingestion, so preview results match actual ingestion behavior.
