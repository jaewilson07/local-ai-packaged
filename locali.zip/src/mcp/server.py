"""MCP server scaffolding exposing search and ingest tools.

This module avoids hard dependency on the MCP package; `run_server` will raise
an informative error if MCP is not installed. Tools are provided as simple async
functions that can be registered by an MCP host (e.g., Claude Desktop, Cline).
"""

from __future__ import annotations

import os
import logging
from typing import Optional
from src.workflows.rag.agent import search_knowledge_base
from src.workflows.ingestion.ingest import DocumentIngestionPipeline, IngestionConfig
from src.workflows.ingest.vector.chunker import ChunkingConfig, create_chunker
from src.settings import load_settings
from src.services.jira.mcp_tools import mcp_search_jira_issues, mcp_get_jira_issue_markdown

logger = logging.getLogger(__name__)


async def mcp_search_knowledge_base(query: str, match_count: int = 5, search_type: str = "hybrid") -> str:
    """Expose search_knowledge_base as an MCP-compatible tool."""
    # Delegate to existing agent tool
    # We bypass ctx; the agent tool manages its own dependencies internally
    return await search_knowledge_base(ctx=None, query=query, match_count=match_count, search_type=search_type)


async def mcp_ingest_documents(documents_path: str = "documents", clean_before_ingest: bool = False) -> str:
    """Trigger ingestion pipeline as an MCP tool."""
    config = IngestionConfig()
    pipeline = DocumentIngestionPipeline(
        config=config,
        documents_folder=documents_path,
        clean_before_ingest=clean_before_ingest,
    )
    await pipeline.initialize()
    results = await pipeline.ingest_documents()
    await pipeline.close()
    return f"Ingested {len(results)} documents"


async def mcp_refresh_documents(documents_path: str = "documents") -> str:
    """Placeholder for refresh operation via MCP."""
    from src.ingestion.refresh import refresh_outdated_documents

    settings = load_settings()
    config = IngestionConfig()
    pipeline = DocumentIngestionPipeline(
        config=config,
        documents_folder=documents_path,
        clean_before_ingest=False,
    )
    await pipeline.initialize()
    docs_collection = pipeline.db[settings.mongodb_collection_documents]
    results = await refresh_outdated_documents(pipeline, docs_collection)
    await pipeline.close()
    return f"Refreshed {len(results)} documents"


async def mcp_convert_document(file_path: str) -> str:
    """Convert a document to markdown format via MCP.
    
    Args:
        file_path: Path to the document file
        
    Returns:
        JSON string with markdown content, title, and file type
    """
    import json
    
    try:
        config = IngestionConfig()
        pipeline = DocumentIngestionPipeline(
            config=config,
            documents_folder=".",
            clean_before_ingest=False,
        )
        
        # Use the pipeline's _read_document method
        markdown_content, _ = pipeline._read_document(file_path)
        
        # Extract title
        title = pipeline._extract_title(markdown_content, file_path)
        
        # Get file type
        file_type = os.path.splitext(file_path)[1].lstrip('.')
        
        result = {
            "markdown": markdown_content,
            "title": title,
            "file_type": file_type
        }
        
        return json.dumps(result, indent=2)
        
    except Exception as e:
        logger.exception("convert_document_failed", file_path=file_path)
        return json.dumps({"error": str(e)})


async def mcp_preview_chunks(
    file_path: str,
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
    max_tokens: int = 512
) -> str:
    """Preview how a document will be chunked via MCP.
    
    Args:
        file_path: Path to the document file
        chunk_size: Target chunk size in characters
        chunk_overlap: Overlap between chunks
        max_tokens: Maximum tokens per chunk
        
    Returns:
        JSON string with chunk preview data
    """
    import json
    
    try:
        # Create pipeline and read document
        config = IngestionConfig(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            max_chunk_size=chunk_size * 2,
            max_tokens=max_tokens
        )
        pipeline = DocumentIngestionPipeline(
            config=config,
            documents_folder=".",
            clean_before_ingest=False,
        )
        
        markdown_content, docling_doc = pipeline._read_document(file_path)
        title = pipeline._extract_title(markdown_content, file_path)
        
        # Create chunker and chunk the document
        chunker_config = ChunkingConfig(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            max_chunk_size=chunk_size * 2,
            max_tokens=max_tokens
        )
        chunker = create_chunker(chunker_config)
        chunks = chunker.chunk_document(markdown_content, docling_doc)
        
        # Format chunk data
        chunk_data = [
            {
                "index": chunk.index,
                "content": chunk.content[:500] + "..." if len(chunk.content) > 500 else chunk.content,
                "token_count": chunk.token_count,
                "context": chunk.metadata.get("context", "")
            }
            for chunk in chunks
        ]
        
        avg_tokens = sum(c.token_count for c in chunks) / len(chunks) if chunks else 0
        
        result = {
            "chunks": chunk_data,
            "total_chunks": len(chunks),
            "avg_tokens": round(avg_tokens, 2),
            "title": title
        }
        
        return json.dumps(result, indent=2)
        
    except Exception as e:
        logger.exception("preview_chunks_failed", file_path=file_path)
        return json.dumps({"error": str(e)})


async def mcp_transcribe_audio(file_path: str) -> str:
    """Transcribe an audio file using Whisper ASR via MCP.
    
    Args:
        file_path: Path to the audio file
        
    Returns:
        JSON string with transcript and title
    """
    import json
    
    try:
        config = IngestionConfig()
        pipeline = DocumentIngestionPipeline(
            config=config,
            documents_folder=".",
            clean_before_ingest=False,
        )
        
        # Use the pipeline's _transcribe_audio method
        transcript, _ = pipeline._transcribe_audio(file_path)
        
        # Extract title from filename
        title = os.path.splitext(os.path.basename(file_path))[0]
        
        result = {
            "transcript": transcript,
            "title": title
        }
        
        return json.dumps(result, indent=2)
        
    except Exception as e:
        logger.exception("transcribe_audio_failed", file_path=file_path)
        return json.dumps({"error": str(e)})


async def mcp_search_entities(name: str, depth: int = 2) -> str:
    """Search for entities in the knowledge graph via MCP.
    
    Args:
        name: Entity name to search for
        depth: Graph traversal depth
        
    Returns:
        JSON string with entities and relationships
    """
    import json
    
    try:
        from src.workflows.rag.agent import search_related_entities
        
        # Call the agent's graph search tool (bypassing ctx)
        result = await search_related_entities(ctx=None, entity_name=name, depth=depth)
        
        return result  # Already returns formatted string
        
    except Exception as e:
        logger.exception("search_entities_failed", name=name)
        return json.dumps({
            "error": str(e),
            "entities": [],
            "relationships": []
        })


async def run_server(host: str = "0.0.0.0", port: int = 8765) -> None:
    """Start an MCP server if the dependency is available."""
    try:
        from mcp.server import Server
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "mcp package is not installed. Install it to run the MCP server."
        ) from exc

    server = Server("mongodb-rag-agent")

    @server.tool()
    async def search(query: str, match_count: int = 5, search_type: str = "hybrid") -> str:
        """Search the knowledge base for relevant information."""
        return await mcp_search_knowledge_base(query=query, match_count=match_count, search_type=search_type)

    @server.tool()
    async def ingest(documents_path: str = "documents", clean_before_ingest: bool = False) -> str:
        """Ingest documents from a folder into the knowledge base."""
        return await mcp_ingest_documents(documents_path, clean_before_ingest)

    @server.tool()
    async def refresh(documents_path: str = "documents") -> str:
        """Refresh outdated documents in the knowledge base."""
        return await mcp_refresh_documents(documents_path)

    @server.tool()
    async def convert_document(file_path: str) -> str:
        """Convert a document to markdown format."""
        return await mcp_convert_document(file_path)

    @server.tool()
    async def preview_chunks(
        file_path: str,
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        max_tokens: int = 512
    ) -> str:
        """Preview how a document will be chunked."""
        return await mcp_preview_chunks(file_path, chunk_size, chunk_overlap, max_tokens)

    @server.tool()
    async def transcribe_audio(file_path: str) -> str:
        """Transcribe an audio file using Whisper ASR."""
        return await mcp_transcribe_audio(file_path)

    @server.tool()
    async def search_entities(name: str, depth: int = 2) -> str:
        """Search for entities in the knowledge graph."""
        return await mcp_search_entities(name, depth)

    @server.tool()
    async def search_jira(
        base_url: str,
        token: str,
        jql: str = "order by updated DESC",
        limit: int = 20
    ) -> str:
        """Search Jira issues using JQL."""
        return await mcp_search_jira_issues(base_url, token, jql, limit)

    @server.tool()
    async def get_jira_markdown(base_url: str, token: str, issue_key: str) -> str:
        """Get a Jira issue formatted as markdown."""
        return await mcp_get_jira_issue_markdown(base_url, token, issue_key)

    await server.run(host=host, port=port)


__all__ = [
    "mcp_search_knowledge_base",
    "mcp_ingest_documents",
    "mcp_refresh_documents",
    "mcp_convert_document",
    "mcp_preview_chunks",
    "mcp_transcribe_audio",
    "mcp_search_entities",
    "mcp_search_jira_issues",
    "mcp_get_jira_issue_markdown",
    "run_server",
]
