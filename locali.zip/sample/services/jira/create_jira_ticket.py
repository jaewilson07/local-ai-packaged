"""
Test script to verify Jira API connectivity and ticket creation on DSOAE board.
Requires JIRA_TOKEN in .env file (base64-encoded email:api_token format).

Usage:
    python get_jira_ticket.py           # Dry run (no ticket created)
    python get_jira_ticket.py --create  # Actually create ticket
"""

import sys
from pathlib import Path

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "src"))

from services.jira.classes.auth import JiraAuth
from services.jira.classes.ticket import JiraTicket


def main(dry_run: bool = True):
    # Initialize Jira client (handles auth automatically)
    client = JiraAuth()
    print(f"Connecting to Jira as: {client.email}")
    print("✓ Successfully connected to Jira")

    # Verify access to DSOAE project
    project = client.jira.project("DSOAE")
    print(f"✓ Found project: {project.name} ({project.key})")

    # List available issue types
    issue_types = client.jira.issue_types()
    print(f"\nAvailable issue types:")
    for it in issue_types:
        print(f"  - {it.name}")

    # Prepare ticket data
    ticket_data = {
        "project_key": "DSOAE",
        "summary": "Test ticket from Slackbot integration",
        "description": "This is a test ticket created by the Slackbot automation.\n\n*Test Details:*\n- Source: Jira API test script\n- Purpose: Verify DSOAE board access and label requirements",
        "issue_type": "Story",
        "labels": ["DSOAE-Domo", "from-slack", "test-automation"],
    }

    if dry_run:
        print("\n🔍 DRY RUN MODE - No ticket will be created")
        print("\nWould create ticket with:")
        print(f"  Project: {ticket_data['project_key']}")
        print(f"  Type: {ticket_data['issue_type']}")
        print(f"  Summary: {ticket_data['summary']}")
        print(f"  Labels: {ticket_data['labels']}")
        print(f"  Description: {ticket_data['description'][:100]}...")
        print("\n💡 Run with --create flag to actually create the ticket")
        return None
    else:
        # Create a test ticket using JiraTicket class
        print("\n✍️  Creating test ticket...")
        ticket = JiraTicket.create(client, **ticket_data)

        print(f"✓ Successfully created ticket: {ticket.key}")
        print(f"  URL: {ticket.url}")
        print(f"  Labels: {ticket.labels}")

        return ticket.key


if __name__ == "__main__":
    # Check for --create flag
    create_ticket = "--create" in sys.argv
    dry_run = not create_ticket

    try:
        issue_key = main(dry_run=dry_run)
        if issue_key:
            print(f"\n✅ Test completed successfully! Ticket: {issue_key}")
        else:
            print(f"\n✅ Dry run completed successfully!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        raise
