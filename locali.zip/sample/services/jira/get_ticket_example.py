"""
Sample script to retrieve and display a Jira ticket.
Demonstrates read-only operations using JiraTicket class.

Usage:
    python get_ticket_example.py DSOAE-11623
    python get_ticket_example.py PROJ-123
"""

import sys
from pathlib import Path

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "src"))

from services.jira.classes.auth import JiraAuth
from services.jira.classes.ticket import JiraTicket


def display_ticket(ticket: JiraTicket) -> None:
    """Display ticket details in a formatted way."""
    print(f"\n{'='*60}")
    print(f"Ticket: {ticket.key}")
    print(f"{'='*60}")
    print(f"Project:     {ticket.project_key}")
    print(f"Type:        {ticket.issue_type}")
    print(f"Summary:     {ticket.summary}")
    print(f"URL:         {ticket.url}")
    print(f"Labels:      {', '.join(ticket.labels) if ticket.labels else 'None'}")
    print(f"\nDescription:")
    print("-" * 60)
    print(ticket.description or "(No description)")
    print("-" * 60)


def main(ticket_id: str) -> None:
    """
    Fetch and display a Jira ticket.
    
    Args:
        ticket_id: Jira ticket key (e.g., 'DSOAE-11623')
    """
    # Initialize Jira client
    print(f"🔗 Connecting to Jira...")
    client = JiraAuth()
    print(f"✓ Connected as: {client.email}")
    
    # Fetch the ticket
    print(f"\n📋 Fetching ticket: {ticket_id}")
    ticket = JiraTicket.get_by_id(client, ticket_id)
    
    if not ticket:
        print(f"❌ Ticket not found: {ticket_id}")
        sys.exit(1)
    
    # Display ticket details
    display_ticket(ticket)
    
    # Additional examples
    print(f"\n{'='*60}")
    print("Additional Operations:")
    print(f"{'='*60}")
    
    # Search for related tickets by project
    print(f"\n🔍 Searching for recent tickets in {ticket.project_key}...")
    recent_tickets = JiraTicket.search(
        client,
        jql=f"project = {ticket.project_key} ORDER BY updated DESC",
        max_results=5
    )
    
    if recent_tickets:
        print(f"Found {len(recent_tickets)} recent tickets:")
        for t in recent_tickets:
            print(f"  • {t.key}: {t.summary[:60]}...")
    else:
        print("  No tickets found")


if __name__ == "__main__":
    # Default to DSOAE-11623 if no argument provided
    ticket_id = sys.argv[1] if len(sys.argv) > 1 else "DSOAE-11623"
    
    try:
        main(ticket_id)
        print(f"\n✅ Successfully retrieved ticket: {ticket_id}")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        raise
