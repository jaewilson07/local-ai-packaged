# Nexus Announcement Palooza 26

**Tab Index:** 3
**Tab ID:** h.qilcjq4csfji
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.qilcjq4csfji

---

Nexus Announcement Palooza 26

![](images/image8.png)

Announcing SIE’s annual analytics, visualization, and platform community conference and training event: AVP-Palooza 2026 (formerly PlayStation Palooza)!

Join us for a hybrid, multi-day experience where community-driven learning, innovation, and collaboration take center stage. AVP-Palooza brings together our global community to share knowledge, celebrate wins, experiment together, and explore the possibilities across our analytics and platform ecosystem.

This year we place special emphasis on hands-on enablement, innovation, and preparing participants for multi-platform certification across Domo, Tableau, and Adobe.

---

🌍 Event Dates & Locations
-------------------------

### 🇬🇧 London Edition — February 2–6, 2026

Location: 10 Great Marlborough St, London W1F 7LP

### 🇺🇸 San Diego Edition — February 9–13, 2026

Location: 16530 Via Esprillo, San Diego, CA 92127

### 🇯🇵 Tokyo Edition — March 2–6, 2026

Location: Sony City, 1 Chome-7-1 Konan, Minato City, Tokyo 108-0075  
 イベントは日本語で開催されます。

---

✏️ Registration Details
-----------------------

[SharePoint Registration Form](https://www.google.com/url?q=https://forms.office.com/r/e8avCHmk5P&sa=D&source=editors&ust=1767831479344240&usg=AOvVaw3jUeZCGAd05VhsduiDK0-N)

Please register early, especially if you plan to attend in person.  
Registered participants will receive calendar invites with Teams meeting links.

---

📅 Event Schedule – High-Level Overview
--------------------------------------

Below is the unified structure for all AVP-Palooza 2026 editions.

---

### Day 1 — Café Day & Hackathon

Kick off the week with collaborative exploration and rapid prototyping.  
Team up with colleagues across SIE to experiment, innovate, and create something new.  
This is a low-pressure day designed for creativity, cross-team collaboration, and platform exploration.

---

### Day 2 — SIE Enablement & Certification Prep

A full day of instructor-led training designed for both new and experienced users.  
 This year’s certification prep spans Domo, Tableau, and Adobe, each running dedicated tracks.

#### New for 2026

* Domo and Adobe will provide free onsite certifications in all three locations.
* Tableau will provide certification prep and supported certification exams (in-person and/or hybrid depending on region).

Hands-on enablement sessions will build confidence and prepare participants for certification exams.

---

### Day 3 — Café Day / Bring your own project (BYOP), DPT CAB & Council, Certification Exams

Participants may continue innovation work or advance their own projects.

#### Certification (Multi-platform)

Certification exams will be available across:

* Domo — Free onsite certifications : Professional, Data Specialist, MajorDomo
* Adobe — Free onsite certifications
* Tableau — Certification exams supported by vendor

Final modality (onsite vs remote) will be confirmed by each vendor.

---

### Day 4 — DSAE Community Day & AMA

A deep dive into the data, analytics, and platform community at SIE.  
 Featuring:

* Vendor & platform presentations
* AVP Ask Me Anything (AMA)
* Community-led talks
* Hackathon Showcase featuring projects from Day 1 and Day 3

---

### Day 5 — MicroStrategy Migration Day (Optional)

Solutions Consulting teams will work in pods to help “user-generated content” teams map and migrate workflows to Domo and Tableau.  
Bring your dashboards, workstreams, questions, and blockers — experts will help you build actionable migration plans.

---

🎯 Participation Paths
---------------------

AVP-Palooza supports two complementary ways to engage with the week.  
 Choose the path that aligns with your goals — or mix both as needed.

---

### 1️⃣ Innovate & Learn

For participants who want to explore new tools, experiment, collaborate, and grow their skills.  
 This path emphasizes creativity, curiosity, and learning for its own sake.

#### Recommended Schedule

* Day 1 – Hackathon / Café Day
* Day 2 – Enablement & Certification Prep
* Day 3 – Certification Exams + Innovation Work
* Day 4 – Community Day + AMA + Vendor Tent
* Day 5 (Optional) – MicroStrategy Enablement

---

### 2️⃣ Build & Deliver

For participants bringing real business challenges, backlog items, or migration goals they want to drive forward.  
 This path focuses on practical progress, unblockers, and expert support.

#### Recommended Schedule

* Day 1 – Hackathon (Bring Your Own Project)
* Day 3 – BYOP & Solutions Consulting Pods
* Day 4 – AMA Sessions
* Day 5 (Optional) – MicroStrategy Day

Certification is optional for this path — join only if it accelerates your build.

---

📘 Certification Opportunities
-----------------------------

AVP-Palooza 2026 now includes multi-platform training and certification across:

### Domo

* Day 2 — Training & prep
* Day 3 — Professional, Data Specialist, MajorDomo certifications

### Adobe

* Adobe has committed to providing free onsite certification exams in London, San Diego, and Tokyo.
* Prep sessions integrated into Day 2.

### Tableau

* Training & Certification prep sessions
* Discounted or Free Certification Exams

---

✨ Choosing Your Path
--------------------

Whether your goal is to innovate, learn, deliver, or certify, AVP-Palooza provides hands-on support, community energy, and structured opportunities to develop skills and accelerate real work.

Both Innovate & Learn and Build & Deliver paths are equally encouraged and supported.

For inquiries or to get involved, please contact us on [#domo-data\_community\_and\_support](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C03PHRXUFKJ&sa=D&source=editors&ust=1767831479351427&usg=AOvVaw0GW-Xglhx7G5y4JCeDdImD)

![](images/image8.png)

コミュニティ主導の学習、イノベーション、コラボレーションが中心となるハイブリッド形式の複数日イベントです。AVP-Palooza では、グローバルコミュニティが集まり、知識を共有し、成果を称え、共に実験し、アナリティクスおよびプラットフォームエコシステムにおける新たな可能性を探求します。

今年は特に、ハンズオンによるスキル強化、イノベーション推進、そして Domo、Tableau、Adobe のマルチプラットフォーム認定に向けた準備に重点を置いています。

---

🌍 開催日程と会場

### 🇬🇧 ロンドン（London Edition） — 2026年2月2日〜6日

会場: 10 Great Marlborough St, London W1F 7LP

### 🇺🇸 サンディエゴ（San Diego Edition） — 2026年2月9日〜13日

会場: 16530 Via Esprillo, San Diego, CA 92127

### 🇯🇵 東京（Tokyo Edition） — 2026年3月2日〜6日

会場: Sony City, 1 Chome-7-1 Konan, Minato City, Tokyo 108-0075  
 イベントは日本語で開催されます。

---

✏️ Registration Details / 登録について
--------------------------------

[SharePoint 登録フォーム](https://www.google.com/url?q=https://forms.office.com/r/e8avCHmk5P&sa=D&source=editors&ust=1767831479353597&usg=AOvVaw03oG-RCOLMLUBQgJYG6EGC)

できるだけ早めに登録してください。現地参加を希望する場合は特にお早めに。  
 登録完了後、Teams 会議リンク付きのカレンダー招待が送付されます。

---

📅 Event Schedule – High-Level Overview / イベント概要スケジュール

以下は AVP-Palooza 2026 全エディション共通の構成です。

---

### Day 1 — Café Day & Hackathon / カフェデー & ハッカソン

* コラボレーションによる探求と迅速なプロトタイピングで1日をスタート
* SIE 全体の仲間とチームを組み、実験・イノベーション・新しい創造に挑戦
* 創造性、チーム横断の協力、プラットフォーム探索に焦点を当てたリラックスした日

---

### Day 2 — SIE Enablement & Certification Prep / SIE エネーブルメント & 認定準備

新規・経験者向けの講師主導型トレーニングを終日実施。

今年の認定準備は以下の3プラットフォームで実施されます：

* Domo
* Tableau
* Adobe

2026年の新ポイント

* Domo と Adobe は全会場で無料のオンサイト認定を提供
* Tableau は認定準備とサポート付き試験（地域により対面またはハイブリッド）
* ハンズオンセッションで試験への自信を強化

---

### Day 3 — Café Day / BYOP（Bring Your Own Project）・DPT CAB & Council・認定試験

* イノベーションの継続または自身のプロジェクトを推進
* マルチプラットフォーム認定試験あり

提供予定の認定試験：

Domo（無料オンサイト）

* Professional
* Data Specialist
* MajorDomo

Adobe（無料オンサイト）

Tableau（ベンダーによるサポート付き認定試験）

* 最終的な実施形式（対面/リモート）はベンダーが確定

---

### Day 4 — DSAE Community Day & AMA

SIE のデータ・アナリティクス・プラットフォームコミュニティを深掘りする1日。

内容：

* ベンダー & プラットフォーム プレゼンテーション
* AVP AMA（Ask Me Anything）
* コミュニティ主導のトーク
* Day 1 / Day 3 の成果を紹介するハッカソン展示会

---

### Day 5 — MicroStrategy Migration Day（オプション）

Solutions Consulting チームが「ユーザー生成コンテンツ」チームを支援し、  
 Domo と Tableau へのワークフロー移行の計画策定をサポート。

* ダッシュボード、ワークストリーム、質問、課題を持参ください
* 専門家が実践的な移行プラン作成を支援

---

🎯 Participation Paths / 参加パス
----------------------------

AVP-Palooza は、2つの補完的な参加スタイルをサポートします。  
 目的に合ったものを選択、または両方を組み合わせることも可能です。

---

### 1️⃣ Innovate & Learn / イノベート & ラーン

新しいツールを探求し、実験し、スキルを伸ばしたい参加者向け。  
 創造性・好奇心・学習に重点を置いたパスです。

おすすめスケジュール

* Day 1 – ハッカソン / カフェデー
* Day 2 – エネーブルメント & 認定準備
* Day 3 – 認定試験 + イノベーション作業
* Day 4 – コミュニティデー + AMA + ベンダーテント
* Day 5（任意）– MicroStrategy エネーブルメント

---

### 2️⃣ Build & Deliver / ビルド & デリバー

実際のビジネス課題、バックログ、移行目標を進めたい参加者向け。  
 実務成果、問題解消、専門家によるサポートに重点。

おすすめスケジュール

* Day 1 – ハッカソン（BYOP）
* Day 3 – BYOP & ソリューションコンサルティングポッド
* Day 4 – AMA セッション
* Day 5（任意）– MicroStrategy Day

認定は任意。必要な場合のみ参加してください。

📘 Certification Opportunities / 認定機会
------------------------------------

AVP-Palooza 2026 では、以下のプラットフォームでマルチプラットフォーム認定が可能：

### Domo

* Day 2 — トレーニング & 準備
* Day 3 — Professional / Data Specialist / MajorDomo

### Adobe

* ロンドン、サンディエゴ、東京で無料オンサイト認定
* 準備セッションは Day 2 に統合

### Tableau

* トレーニング & 認定準備
* 割引または無料試験あり

---

✨ Choosing Your Path / パスの選び方
-----------------------------

イノベーション、学習、実務推進、認定取得など目的が何であっても、  
 AVP-Palooza はハンズオンのサポート、コミュニティの活力、  
 スキル開発と実務加速のための体系的な機会を提供します。

Innovate & Learn と Build & Deliver の両方が同等に推奨・サポートされています。

---

お問い合わせ

ご質問や参加希望は #domo-data\_community\_and\_support までご連絡ください。