# AMA and Communty

**Tab Index:** 15
**Tab ID:** h.dq1p5veo8dpl
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.dq1p5veo8dpl

---

AMA and Communty

Thursday - AMA + Community Presentations
----------------------------------------

Location : Sony City, SC 15-24

Community members are invited to present their work, lessons learned or projects to the SIE Domo community.  These can also be workshop sessions to explore particular or challenging topics.  See [Call For Presenters](https://www.google.com/url?q=https://docs.google.com/document/d/1hc1SHyF0huLOsIluAwMZRIHTqDap946seUf7X-AP-vU/edit?usp%3Dsharing&sa=D&source=editors&ust=1767831479445894&usg=AOvVaw07XxlXecDI0HLlENSkaepj)

Domo representatives will present workshops around new tooling, special topics or workflows related to trends in the broader Domo community and user base.

Domo Platform team will present workshops relevant to SIE specific projects and initiatives.

### 0910 - 1015 || Metadata and Domo.AI with David Johnson

* How can i get better answers / more accurate answers from my data

### 1045 - 1200 || Connecting and joining diverse SIE data sources [Thomas Murphey](mailto:thomas.murphey@sony.com)

* Walkthrough of some of the different data sources available at SIE and how to connect to them. Some will be Domo standard connectors, while also covering more difficult data sources requiring Jupyter workspace scripting or S3 bucket and API approaches. Examples from projects worked on such as Rest Mode and CSAT.

Target Audience: Analysts and Developers

Prerequisite or Supporting skills: None

### 1200 - 1300 || 🍜 Lunch Break

### 1310 - 1350 || ETL Updates and New Features with David Johnson

* Our focus will be to optimizing ETL processes, including updates to enhance processing speed and new documentation methods using DomoStats reports. It also includes a review and demo of innovative ETL design patterns to improve workflow efficiency.

### 

### 

### 1400 - 1430 || Community presentation with [Taro Takamoto](mailto:taro.takamoto@sony.com)

### 1430 - 1515 || Using Remote Domo Stats and Workflows for Instance Governance by [Anna Favis](mailto:annacarissa.favis@sony.com)

Target Audience: Analysts and Developers

Prerequisite or Supporting skills: Python, Domolibrary

### 1515 - 1530 || ☕ Break

### 1530 - 1700 || Custom Apps 101 with [Antony Rowe](mailto:antony.rowe@sony.com)

* Introduction to custom apps and bricks and when to consider using them (overview of functionality available above regular cards; new vizes, personalisation, data collection, triggering workflows).  
  Custom apps vs bricks with respect to functionality and development process (github / domo cli / pubic assets).  
  Quick demo turning a D3.js example into a custom app card. TBD

Target Audience: Analysts and Developers

Prerequisite or Supporting skills: None