# DP - Why You should Go

**Tab Index:** 23
**Tab ID:** h.jw9vb7ciloot
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.jw9vb7ciloot

---

DP - Why You should Go

DomoPalooza - Domo’s Annual Customer Conference
===============================================

DomoPalooza is Domo’s annual user’s conference designed to bring together industry leaders, data enthusiasts, and Domo users to explore the latest advancements in data visualization, business intelligence, and analytics. It’s an opportunity to network, learn, and gain insights into how businesses leverage Domo to achieve success.

Core Topics and Areas to be Covered:
------------------------------------

1. Keynote Sessions: Hear from Domo executives and industry leaders about the future of data and innovation.
2. Workshops & Trainings: Hands-on sessions tailored to users of all levels to enhance their Domo expertise.
3. Product Announcements: Get first-hand insights into upcoming features and enhancements.
4. Customer Success Stories: Real-world applications showcasing how companies solve challenges with Domo.
5. Networking Opportunities: Build connections with other Domo users, developers, and industry professionals.

More info on DomoPalooza here: [https://www.domo.com/domopalooza#agenda](https://www.google.com/url?q=https://www.domo.com/domopalooza%23agenda&sa=D&source=editors&ust=1767831479500672&usg=AOvVaw1tl0hdj6M5qcvYTd43LSgM) 

❗ Technical Pre-Conference workshops are available at an additional cost, but SIE delegates may receive discount or even waived fees for workshop registration.  Contact us (in [slack](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C06Q4TX3JTV&sa=D&source=editors&ust=1767831479501024&usg=AOvVaw2Y4Q1Aev4_q5O3cwQebIhC)) for details.

![](images/image19.png)

Event Details:
--------------

* Dates: March 25–27, 2025
* Location: Salt Lake City, Utah, USA
* Nearest Airport: Salt Lake City International Airport
* Event Addresses:

* The Grand America Hotel: [555 S Main St, Salt Lake City, UT, 84111](https://www.google.com/url?q=https://www.google.com/search?sca_esv%3D567ab18d067741e3%26rlz%3D1C5GCEM_en%26hotel_occupancy%3D2%26q%3Dgrand%2Bamerica%2Bhotel%2Baddress%26ludocid%3D8047494904645331901%26sa%3DX%26ved%3D2ahUKEwinx5Wzm_6KAxXQIEQIHbBBLX4Q6BN6BAgsEAI&sa=D&source=editors&ust=1767831479501725&usg=AOvVaw1o9q21EXWrhdoM4IisEBV7)
* The Little America Hotel: [500 Main St, Salt Lake City, UT 84101](https://www.google.com/url?q=https://www.google.com/search?sca_esv%3D567ab18d067741e3%26rlz%3D1C5GCEM_en%26q%3Dthe%2Blittle%2Bamerica%2Bhotel%2B-%2Bsalt%2Blake%2Bcity%2Baddress%26ludocid%3D17334992178651661364%26sa%3DX%26ved%3D2ahUKEwiDwtbEmv6KAxV3JkQIHQiFJkcQ6BN6BAhPEAI&sa=D&source=editors&ust=1767831479501971&usg=AOvVaw1-5r3WI7B8jOGU-ELKVNF9)

* Travel Info:

* For US Attendees: Domestic flights and accommodations should be booked as soon as travel is approved.
* For UK and Tokyo Attendees: Plan for an international flight into Salt Lake City (SLC). Visa requirements may apply; check local travel regulations.

### Event and Travel Costs

* A limited number of conference tickets are available via DSAE-DEV (contact us in [Domo Community](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C03PHRXUFKJ&sa=D&source=editors&ust=1767831479502606&usg=AOvVaw000lX0Bv_RHRGJi6-zX9pZ) slack).
* Travel and Expenses must be self-coordinated or covered by your respective cost center / department.

Find us at Dompalooza
---------------------

To better support our SIE community, DSAE-DEV sends a contingent of delegates to Domopalooza to stay on the bleeding edge of developments as well as participate in advisory boards and meet with our customer success team.

We also organize team outings and dinners around the conference.  To find fellow SIE conference delegates, DM Jae Myong Wilson in slack to join the [event-domoplaooza-offtopic](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C06Q4TX3JTV&sa=D&source=editors&ust=1767831479503395&usg=AOvVaw0F9AX5hIN-InZAIIDRXxp7) channel.

Links
-----

### Manual Links

[Self GDoc](https://www.google.com/url?q=https://docs.google.com/document/d/146NmxdkVAV5rdvMdFcz0o_M6N1NBa9qGVaoW-mcLtWs/edit?tab%3Dt.xf06lgcx9jyz%23heading%3Dh.pdr4epdoqrah&sa=D&source=editors&ust=1767831479503745&usg=AOvVaw1WV_PtIimrxUS0ECeKd_EQ)  
[Confluence](https://www.google.com/url?q=https://confluence.sie.sony.com/x/qleen&sa=D&source=editors&ust=1767831479503840&usg=AOvVaw2Qv56Ao1SeWC0xnfQgW7JT)