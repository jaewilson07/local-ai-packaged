# Announcing Palooza 26

**Tab Index:** 2
**Tab ID:** h.nukz3stai92k
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.nukz3stai92k

---

Announcing Palooza 26

![](images/image8.png)

Announcing SIE’s annual analytics, visualization, and platform community conference and training event: AVP-Palooza 2026 (formerly PlayStation Palooza)!

Join us for a hybrid, multi-day experience where community-driven learning, innovation, and collaboration take center stage. AVP-Palooza brings together our global community to share knowledge, celebrate wins, experiment together, and explore the possibilities across our analytics and platform ecosystem.

This year we place special emphasis on hands-on enablement, innovation, and preparing participants for multi-platform certification across Domo, Tableau, and Adobe.

---

🌍 Event Dates & Locations
-------------------------

### 🇬🇧 London Edition — February 2–6, 2026

Location: 10 Great Marlborough St, London W1F 7LP

### 🇺🇸 San Diego Edition — February 9–13, 2026

Location: 16530 Via Esprillo, San Diego, CA 92127

### 🇯🇵 Tokyo Edition — March 2–6, 2026

Location: Sony City, 1 Chome-7-1 Konan, Minato City, Tokyo 108-0075  
 イベントは日本語で開催されます。

---

✏️ Registration Details
-----------------------

[SharePoint Registration Form](https://www.google.com/url?q=https://forms.office.com/r/e8avCHmk5P&sa=D&source=editors&ust=1767831479334887&usg=AOvVaw2c4pIyDvEiSbxBTwt7HAX9)

Please register early, especially if you plan to attend in person.  
Registered participants will receive calendar invites with Teams meeting links.

---

📅 Event Schedule – High-Level Overview
--------------------------------------

Below is the unified structure for all AVP-Palooza 2026 editions.

---

### Day 1 — Café Day & Hackathon

Kick off the week with collaborative exploration and rapid prototyping.  
Team up with colleagues across SIE to experiment, innovate, and create something new.  
This is a low-pressure day designed for creativity, cross-team collaboration, and platform exploration.

---

### Day 2 — SIE Enablement & Certification Prep

A full day of instructor-led training designed for both new and experienced users.  
 This year’s certification prep spans Domo, Tableau, and Adobe, each running dedicated tracks.

#### New for 2026

* Domo and Adobe will provide free onsite certifications in all three locations.
* Tableau will provide certification prep and supported certification exams (in-person and/or hybrid depending on region).

Hands-on enablement sessions will build confidence and prepare participants for certification exams.

---

### Day 3 — Café Day / Bring your own project (BYOP), DPT CAB & Council, Certification Exams

Participants may continue innovation work or advance their own projects.

#### Certification (Multi-platform)

Certification exams will be available across:

* Domo — Free onsite certifications : Professional, Data Specialist, MajorDomo
* Adobe — Free onsite certifications
* Tableau — Certification exams supported by vendor

Final modality (onsite vs remote) will be confirmed by each vendor.

---

### Day 4 — DSAE Community Day & AMA

A deep dive into the data, analytics, and platform community at SIE.  
 Featuring:

* Vendor & platform presentations
* AVP Ask Me Anything (AMA)
* Community-led talks
* Hackathon Showcase featuring projects from Day 1 and Day 3

---

### Day 5 — MicroStrategy Migration Day (Optional)

Solutions Consulting teams will work in pods to help “user-generated content” teams map and migrate workflows to Domo and Tableau.  
Bring your dashboards, workstreams, questions, and blockers — experts will help you build actionable migration plans.

---

🎯 Participation Paths
---------------------

AVP-Palooza supports two complementary ways to engage with the week.  
 Choose the path that aligns with your goals — or mix both as needed.

---

### 1️⃣ Innovate & Learn

For participants who want to explore new tools, experiment, collaborate, and grow their skills.  
 This path emphasizes creativity, curiosity, and learning for its own sake.

#### Recommended Schedule

* Day 1 – Hackathon / Café Day
* Day 2 – Enablement & Certification Prep
* Day 3 – Certification Exams + Innovation Work
* Day 4 – Community Day + AMA + Vendor Tent
* Day 5 (Optional) – MicroStrategy Enablement

---

### 2️⃣ Build & Deliver

For participants bringing real business challenges, backlog items, or migration goals they want to drive forward.  
 This path focuses on practical progress, unblockers, and expert support.

#### Recommended Schedule

* Day 1 – Hackathon (Bring Your Own Project)
* Day 3 – BYOP & Solutions Consulting Pods
* Day 4 – AMA Sessions
* Day 5 (Optional) – MicroStrategy Day

Certification is optional for this path — join only if it accelerates your build.

---

📘 Certification Opportunities
-----------------------------

AVP-Palooza 2026 now includes multi-platform training and certification across:

### Domo

* Day 2 — Training & prep
* Day 3 — Professional, Data Specialist, MajorDomo certifications

### Adobe

* Adobe has committed to providing free onsite certification exams in London, San Diego, and Tokyo.
* Prep sessions integrated into Day 2.

### Tableau

* Training & Certification prep sessions
* Discounted or Free Certification Exams

---

✨ Choosing Your Path
--------------------

Whether your goal is to innovate, learn, deliver, or certify, AVP-Palooza provides hands-on support, community energy, and structured opportunities to develop skills and accelerate real work.

Both Innovate & Learn and Build & Deliver paths are equally encouraged and supported.

For inquiries or to get involved, please contact us on [#domo-data\_community\_and\_support](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C03PHRXUFKJ&sa=D&source=editors&ust=1767831479341997&usg=AOvVaw23gM-JcUuvudQNrEkOu0EA)

Links
-----

Google Docs

Confluence [Link](https://www.google.com/url?q=https://confluence.sie.sony.com/x/e7xObQ&sa=D&source=editors&ust=1767831479342314&usg=AOvVaw1ZusUq3qei1SMMYr4Yj4t5) 