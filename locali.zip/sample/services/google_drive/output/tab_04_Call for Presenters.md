# Call for Presenters

**Tab Index:** 4
**Tab ID:** h.52zj5yg7blcu
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.52zj5yg7blcu

---

Call for Presenters

Call for Presenters for Playstation Palooza 2026!
=================================================

We’re excited to invite members of the community to present and share the great work you’ve been doing across our analytics and platform ecosystem.

AVP-Palooza is a community-driven event, and some of the most valuable sessions come directly from practitioners sharing real solutions, lessons learned, and innovations.

📅 All community presentations will take place on Day 4 (Community Day).  
🗂️ The final agenda will be shared closer to the event.

Register Here

[Sharepoint Form](https://www.google.com/url?q=https://forms.office.com/Pages/ResponsePage.aspx?id%3Dil3GZliRIUWi2GZJY9tI5GgHgk0UogRMgYWaURrUWnBUOTFROU8yV1NJV0NKQ0VQN1JBM0xCT1M4Qy4u&sa=D&source=editors&ust=1767831479364255&usg=AOvVaw3dYqNbkaH-g8TbD-M7o8vg)

🎯 Presentation Formats
----------------------

We offer several presentation formats and are open to new ideas.  
If you’re interested in something different (roundtable, panel, hands-on workshop), let us know in your submission.

### 🧩 Show & Tell (10–15 minutes)

Share a real project or solution you’ve built.

Suggested topics:

* What you built and why
* Walkthrough of the user experience
* Notable features of your data pipeline
* Challenges, successes, and lessons learned during launch and adoption

---

### 🛠️ Technical Talk (15–20 minutes)

Go deeper into implementation details.

Suggested topics:

* The problem you set out to solve
* Walkthrough of the process or pipeline
* Notable architectural or pipeline decisions
* Code samples for automations or integrations
* Solutions considered (and rejected)
* Key challenges and trade-offs

---

### ⚡ Lightning Round (5 minutes)

Short, focused, and high-energy.

Options:

* Live presentation or pre-recorded video
* A quick walkthrough of:

* A cool card, page, app, or workflow
* A powerful pro tip
* A lesson learned the hard way

---

🌐 Online / Pre-Recorded Submissions
-----------------------------------

If you prefer not to present live, online submissions are welcome.

* Pre-recorded sessions and video submissions may be showcased in the Vendor Tent on Day 4
* This is a great option if you want visibility without presenting on stage

---

📝 Submission Process
--------------------

To submit a proposal, please provide:

* A short synopsis (≈ 5 sentences) describing your session
* Links to any relevant dashboards, apps, workflows, or materials

📣 Submit via:

* [SharePoint Form](https://www.google.com/url?q=https://forms.office.com/Pages/ResponsePage.aspx?id%3Dil3GZliRIUWi2GZJY9tI5GgHgk0UogRMgYWaURrUWnBUOTFROU8yV1NJV0NKQ0VQN1JBM0xCT1M4Qy4u&sa=D&source=editors&ust=1767831479367493&usg=AOvVaw1sVN2hP0QIBiKSHGyc8n0e)
* [Google Drive](https://www.google.com/url?q=https://drive.google.com/drive/u/2/folders/1WSNeaWf-2PJPsHD3tiqucH3fV4IKiCBa&sa=D&source=editors&ust=1767831479367635&usg=AOvVaw3XBzPxmX-NBKRlkgeM5A18)
* [Community slack](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C03PHRXUFKJ&sa=D&source=editors&ust=1767831479367751&usg=AOvVaw0FZ69plleujp1sLy4lJA6c)

🗓️ Submission deadline: January 26th, 2026

If your session includes code-heavy content, please include scripts or samples so participants can take them home.

---

🎥 Pre-Recorded Presentation Guidelines
--------------------------------------

If submitting a pre-recorded session:

* Please submit recordings by Jan 26th
* Ensure good audio quality (headset or quality earbuds recommended)
* Use good lighting and camera framing
* Tools like OBS Studio are welcome, but a simple Teams screen recording is perfectly fine

---

😌 Not Comfortable Presenting?
-----------------------------

No problem — we’ve got you covered.

* The AVP team can coach you on content, structure, and delivery
* We can co-present with you
* If needed, an AVP team member can present on your behalf
* Or submit a pre-recorded session instead

This is a supportive, low-pressure environment designed to help you succeed.

---

🌟 Why Present?
--------------

* Share your work and get recognition from the community
* Practice storytelling — a critical skill in analytics and platform work
* Build visibility and confidence in a safe, supportive setting
* Earn unique AVP-Palooza swag
* Add a meaningful contribution to your annual review
* (Optional) Be considered for future external speaking opportunities

[Confluence](https://www.google.com/url?q=https://confluence.sie.sony.com/x/j3RGbQ&sa=D&source=editors&ust=1767831479370203&usg=AOvVaw1SWIpWzGC2_dOqBEKpMkOv)

[GDoc](https://www.google.com/url?q=https://docs.google.com/document/d/1hc1SHyF0huLOsIluAwMZRIHTqDap946seUf7X-AP-vU/edit?usp%3Dsharing&sa=D&source=editors&ust=1767831479370333&usg=AOvVaw37QWx9rmmwXXK480nxRklk)