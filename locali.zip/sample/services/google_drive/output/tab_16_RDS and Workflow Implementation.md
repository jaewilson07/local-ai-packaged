# RDS and Workflow Implementation

**Tab Index:** 16
**Tab ID:** h.45ngrwuyv7y0
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.45ngrwuyv7y0

---

RDS and Workflow Implementation

RDS + Workflows + Code Engine
=============================

What are Domo Workflows?
------------------------

Domo Workflows is a powerful automation tool within the Domo platform that allows users to streamline processes, integrate data, and automate business actions. Workflows help organizations save time, reduce manual effort, and ensure consistency across operations.

Key Features of Domo Workflows
------------------------------

Drag-and-Drop Interface - Easily build workflows using a visual editor.

Automated Data Processing - Process and manipulate data without manual intervention.

Conditional Logic - Set rules and triggers based on specific conditions.

Integrations - Connect with various applications, databases, and APIs.

Notifications & Alerts - Send real-time alerts when certain conditions are met.

Approval Flows - Enable structured approval processes within your organization.

What is Domo Code Engine?
-------------------------

Domo Code Engine is a powerful scripting environment within the Domo platform that allows users to write and execute custom code for advanced data processing, transformations, and automation. It provides flexibility for users who need more control over their data workflows beyond what is available in standard Domo tools.

Key Features of Domo Code Engine
--------------------------------

Support for Multiple Languages - Write scripts in Python, R, and SQL.

Advanced Data Processing - Perform complex transformations and calculations.

Integration with Domo Datasets - Read from and write to datasets within the Domo environment.

Automated Execution - Schedule scripts to run at defined intervals.

Custom API Calls - Connect with external APIs to bring in or push out data.

Error Handling and Logging - Identify and resolve issues efficiently.

Activity Overview
=================

This workshop focuses on leveraging SIE published remote domo stats to create tags on a dataset with workflows and code engine.

Goals
-----

* Overview of remote domo stats available at SIE
* ETL for configuration dataset
* Create code engine package and functions
* Create workflow to update dataset tags
* Discuss other potential use cases

SIE Remote Domo Stats | Observability Metrics
---------------------------------------------

Domo offers a suite of reports/datasets that are available to help with tracking user activity and governance of all of our instances. We (DPT) are currently publishing some of these reports to all of the department instances, and it is up to instance admins to accept the publication if they want to see them in their instance.

* There are some additional processing steps we have to do in order to send data relevant back to the department instances
* DASH vs STACK

* DASH - Dash datasets include data on only the department instance
* STACK - Stack datasets include data on the department instance and the relevant data from the distribution center (playstation.domo.com

* If there is a need to see RDS datasets from other instances, the admins from that instance can materialize the federated dataset using ETL and then publish to the other instance

* Config instance => department instance 1 | ETL | => department instance 2

Activity
--------

### Set up ETL to create configuration dataset

1. Navigate to the [MONIT\_Datasets\_DASH](https://www.google.com/url?q=https://playstation-training-sandbox.domo.com/datasources/673479e5-66a8-461b-b169-25c3f2d8a7ac/details/data/table&sa=D&source=editors&ust=1767831479460513&usg=AOvVaw2T02jHyhHcjgIhpNva-iem) dataset in playstation-training-sandbox.domo.com
2. Filter on the row where name = “DIM\_DT”

For this activity, I want to be able to create a workflow that will update all of my datasets with a tag of the source tables that contribute to the data so I can improve the searchability of the datasets in my instance

3. Open MONIT\_Datasets\_DASH in Magic ETL
4. Filter rows where stream\_config\_tables “IS NOT NULL”
5. Select “id” and “stream\_config\_tables” columns
6. Output configuration dataset complete!

### Workflow Set Up

![](images/image15.png)

1. Add Numbers function

1. Number 1 = 0
2. Number 2 = 0
3. Sum = dataset\_counter

2. Query With SQL

1. Dataset = {config dataset}
2. Sql = SELECT \* FROM dataset
3. Results = dataset\_rows

3. Conditional Logic

1. Yes = dataset\_counter < count(dataset\_rows)
2. No = default

4. getObjectFromList

1. Index = dataset\_counter
2. List = dataset\_rows
3. Object = current\_row

5. Parallel Logic
6. Get Text From Object

1. Obj = current\_row
2. Property = dataset\_id
3. Text = current\_dataset\_id

7. Get Text From Object

1. Obj = current\_row
2. Property = stream\_config\_tables
3. Text = current\_dataset\_tags

JUMP TO CODE ENGINE CREATION

8. \*Text to List - create code engine package + function

1. Delimiter = ,
2. Text = current\_dataset\_tags
3. List = list\_tags

9. Parallel Logic (ensures that all previous steps complete before moving on the workflow)
10. \* Add tags - create code engine package + function

1. Dataset\_id = current\_dataset\_id
2. Tags = list\_tags

11. Add Numbers - increment counter

1. Number 1 = dataset\_counter
2. Number 2 = 1
3. Sum = dataset\_counter

### Code Engine Package Creation

import codeengine

import json

def textToList(text, delimiter): 

  string = text

  list = string.split(f'{delimiter}')

  print(list)

  return list

def add\_tags(tags, dataset\_id):

  current\_tags = get\_current\_tags(dataset\_id)

  tags = tags + current\_tags

  tags = list(dict.fromkeys(tags))

  url = f'/api/data/ui/v3/datasources/{dataset\_id}/tags'

  response = codeengine.send\_request('post', url, body=tags)

  print(response)

def get\_current\_tags(dataset\_id):

  url =  f'/api/data/v3/datasources/{dataset\_id}?includeAllDetails=true'

  response = codeengine.send\_request('get', url)

  return json.loads(response["tags"])



Potential Use Cases
===================

* Emailing data/dashboard out to different platform teams + summary

* The url changes to only show app/dashboard by team

* Pulling data audit board using their API
* Governance of instance, review of old cards, pages, datasets
* User/group management - import from Okta and automation of group management
* PDP automations