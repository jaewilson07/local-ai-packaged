# AVP 26 - Tokyo agenda

**Tab Index:** 7
**Tab ID:** h.f40p2frni26t
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.f40p2frni26t

---

AVP 26 - Tokyo agenda