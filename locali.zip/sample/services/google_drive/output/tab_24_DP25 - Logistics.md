# DP25 - Logistics

**Tab Index:** 24
**Tab ID:** h.kn6vzwlhmz5n
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.kn6vzwlhmz5n

---

DP25 - Logistics

Contact Information
-------------------

Jae Wilson - 808-765-1506 (WhatsApp)

Michael Dixon - 516 630-7182 (Domo Accounts Team Customer Success Manager)

Brook Girma - 714-313-7848

Oleksii Zakrevskyi -  +33611962203  (WhatsApp)

Consider - Nomad for eSim

Precon Session Registration
---------------------------

Session you’d like to attend, your name.

Catherine Choe (Registered)

* Using AI to Analyze Text Data in Domo (Tuesday, March 18)

 

Brook Girma (Registered)

* Intro to No Code AI Tooling in Domo (Tuesday, March 18)
* Using AI to analyze Text Data in Domo (Monday, March 17)

 

Tom Whipple (Registered)

* Data Readiness and Preparation for AI (Monday, March 17)
* Intro to No Code AI Tooling in Domo (Tuesday, March 18)

 

Anna Favis (Registered)

* Intro to Building Custom Apps with Pro-Code Editor (Tuesday, March 18)
* Design Patterns for Data Transformations (Tuesday, March 18)

Additional Activities
---------------------

### Monday

* 1800 - 2000 Developer Meetup (all engineers) [register](https://www.google.com/url?q=https://domo.az1.qualtrics.com/jfe/form/SV_3dYpBp7FWRczLrE&sa=D&source=editors&ust=1767831479505995&usg=AOvVaw3EBJzEr_IA5wFUCrOq_rGW) @ DomoPalooza

Tuesday

* 1800 - 2000 Top Golf

### Wednesday

* 1330 - 1410 - Dan M, OZ, and BG - PlayStation + Domo: Unifying Data Experiences Across Diverse Business Teams

 

* 1700 - 1800 Networking Reception @ DomoPalooza
* 1800 - 2030 - SIE Domo Champions - drinks and snacks @  [Lake Effect](https://www.google.com/url?q=https://www.lakeeffectslc.com/&sa=D&source=editors&ust=1767831479506610&usg=AOvVaw0AaYjP1PAzujChLzz7jGMh)
* 2000 - Concert @ DomoPalooza

### Thursday

* 1730 - 1900 Dinner with Domo Customer Success team
* 2000 - Concert @ Domopalooza

### Friday

* Customer Ski Day transportation organized by Domo

Additional Meetings with Domo
-----------------------------

NOTE: These sessions will probably have to wait till after DP25.

Who you’d like to meet and what you’d like to discuss review / prep materials we can send over

Managing Users in a Multi Instance Environment

* Instance Switcher UI updates – progress, timeline, etc Swensen and Jesse Kreitzman
* User profile syncing across instances
* Credential and Access Token management across instances
* Cycling Service Accounts

 with Dan Brinton, Michael

Requested by Om

Managing Metadata, Data and Governance in a Multi Instance Environment

* On Remote DomoStats wishlist reports
* Updates to Enterprise Toolkit
* Updates to Cloud Amplifier Management
* Improvements to Publish + dataset metadata (certifications, AI Readiness, schema, tagging)

with Matt Payne and Ken

Requested by Om

SA + App Studio with Domo Engineering

* state of Dashboards vs. Apps
* Scheduled reports
* Customizability
* Updates to charts, templates, and color controls

Problems, tribulations, missing features, big wins.

Per recommendation by Jace

[Leah Welch](mailto:leah.welch@sony.com) will want your involvement / input

[Anna Favis](mailto:annacarissa.favis@sony.com) can you pls work with [Leah Welch](mailto:leah.welch@sony.com)to put together a preliminary 5 to 10 minute presentation summarizing how this has been going across teams?

 

[Slack](https://www.google.com/url?q=https://sie.slack.com/archives/C08FWCLE5U0/p1740595667893059&sa=D&source=editors&ust=1767831479509674&usg=AOvVaw2eXPjEjjSbiBN95T4_qDPY)

Additional Activities
---------------------

What day should we do a team dinner? And where should we go?