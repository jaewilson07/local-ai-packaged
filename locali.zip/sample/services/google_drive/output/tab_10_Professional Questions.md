# Professional Questions

**Tab Index:** 10
**Tab ID:** h.dt19d9grcol
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.dt19d9grcol

---

Professional Questions

最適な解答を選択してください。

過去2年分の収益を並べて表示するチャートを作成するのに最適なチャートタイプは？

 

* マリメッコチャート
* 前期比チャート
* 積上げ棒チャート
* 複数折れ線チャート

—-

最適な解答を選択してください。

ストーリーが提供する主な機能のうち、標準のダッシュボードにはないものはどれですか？

 

* 4つのカードサイズから選択し、チャート要素をクリックしてページ全体をフィルタリングし、カードをドラッグアンドドロップして並べ替える機能。
* ページ上のカードをロックし、コレクションを追加して、カードを同じようなグループに整理する機能。
* カードのサイズを動的に変更したり、テンプレートを使用してカードを配置したり、カードレベルで繰り返しを調整したりする機能。
* カードのページを物語の本のように動的にめくる機能。

–

最適な解答を選択してください。

Domoストーリーでは、表示するかどうかに関係なく、特定のグラフ要素を選択することができます。カードの表示設定でカスタマイズできるオプションは、次のうちどれですか？

* タイトル、説明、凡例、カードのオプションボタン
* 上記のすべて
* タイトル、サマリー、カードのオプションボタン
* タイトル、説明、サマリー

![](images/image30.png)

\* # 1 Drill in place found in Card interaction settings

![](images/image10.png)

* # 4 Market Spend by Conversion

![](images/image11.png)

\* #4 Notifying on Dashboard Level updates

![](images/image2.png)

\* # 1 All correct

![](images/image23.png)

\* # 2 True

![](images/image31.png)

* # 1 All Correct

![](images/image17.png)

* #4 - change the y axis to anything other than 0

![](images/image27.png)

* # 1 Edit page from the wrench menu

![](images/image21.png)

* # 2 Company Certifcation (vs. Departmental Certifiation

最適な解答を選択してください。

Appstoreから個人的にデプロイしたAppを、すべて1ヶ所で確認できる場所はどこですか？

Data Centerの［Installed App］タブ

Appstoreの［Asset Library］タブ

Data Centerの［Data Warehouse］タブ

Appstoreの［Installed App］タブ

–

最適な解答を選択してください。

売り上げダッシュボードの表示中に、1ヶ所だけの地域のカードをすべて表示して、カードのパフォーマンスを把握したくなりました。そのためには、何をすればよいですか？

カードの詳細レベルでカードフィルターを適用し、各カードを順にクリックする。

ページフィルターを適用する。

ページクイックフィルターを適用する。

このダッシュボードのコピーを作成し、各カードを地域フィルターとともに保存して、その地域が後で使用できるように常にダッシュボードに反映されるようにする。

–

色のルールを使用できるユースケースは？

* カードにカスタムの色を設定し、条件に応じて一貫性のある色規則を構成する。
* カードに背景色を追加する。
* テキストボックス、ホバーテキスト、軸、ラベル、凡例のフォントの色を設定する。

–

最適な解答を選択してください。

新しいユーザーがフォローするべきアラートを尋ねてきました。どのようなヒントを提供しますか？

* 上司がフォローしているアラートを確認し、自分の業務に対応するアラートを探す。
* Alert Centerにアクセスして社内トレンドを確認する。
* Data Centerに目を通し、自分の業務に関連するデータが含まれている様々なDataSetを見つける。

–

![](images/image6.png)

* # 1

最適な解答を選択してください。

Domoインスタンスを作成し、ページ、ダッシュボード、カード、ドリルダウンを作成する際、オーディエンスが何をできるようにすることを第一目標としますか？

的確な意思決定をする。

業務上の課題を解決する。

彼らの最も重要なビジネスニーズを見極める。

より多くのデータを視覚化する。

![](images/image7.png)

* # 2

–

最適な解答を選択してください。

グラフの完全性の違反と考えられるのは？

* y軸の最小値を0以外の数値に設定する。
* データラベルが長すぎて重なって表示されるため読み難くなる。
* プラスのキャッシュフローを表すために赤い色を使用する。
* 折れ線チャートではなく棒チャートを使ってトレンドデータを表示する。

![](images/image29.png)

* # 1

![](images/image26.png)

#1

![](images/image14.png)

#2