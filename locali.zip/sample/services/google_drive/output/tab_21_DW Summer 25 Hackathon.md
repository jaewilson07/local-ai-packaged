# DW Summer 25 Hackathon

**Tab Index:** 21
**Tab ID:** h.symiiymu4qpm
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.symiiymu4qpm

---

DW Summer 25 Hackathon

🎯Domo Wars: A New Hack || Summer 25
===================================

![](images/image4.png)

ℹ️General Information
---------------------

Challenge yourself to rethink how we use our business intelligence platform. Dashboards are just the beginning. Build solutions that drive innovation, integrate with business processes, and turn data into action. Create custom tools, embed intelligence into workflows, and use AI to surface insights or automate decisions. Don’t just visualize data—make it work.

To give teams time and opportunity to grapple with AI, this hackathon has a strong AI component, and several of the projects will tackle using AI in Domo.

### Event Logistics

Dates: May 12 to 14, 2025

Location: San Diego, CA - Rancho Bernardo Office - F4-Sanctuary and [Teams](https://www.google.com/url?q=https://teams.microsoft.com/l/meetup-join/19%253ameeting_NDIyODMzMzAtMzAxOS00NWVjLTlkMDgtYzMyMTZmNjlmMjU4%2540thread.v2/0?context%3D%257b%2522Tid%2522%253a%252266c65d8a-9158-4521-a2d8-664963db48e4%2522%252c%2522Oid%2522%253a%2522841fa4c6-269c-4a04-a0d8-11c9cd1c2b19%2522%257d&sa=D&source=editors&ust=1767831479488030&usg=AOvVaw0vaPThYUmEJFdEMC-bWIQP)

The hackathon welcomes participation from the entire SIE Domo community whether in person or online via teams. Remote teams can be organized into breakout rooms or meet in their preferred spaces.

To chat with participants join[#event-domo-hackathon](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C08P3NBJ84B&sa=D&source=editors&ust=1767831479488467&usg=AOvVaw0NNMh4IzygvOG1HDvrgGJb)

|  |  |
| --- | --- |
| image.png | ✏️ How do I register? Participants (both live and remote) should register[here](https://www.google.com/url?q=https://sie.enterprise.slack.com/lists/T025FCT8A/F08PU1U11CG&sa=D&source=editors&ust=1767831479489117&usg=AOvVaw2Rcj6wg4Ni5J8grCqk-RLI). |
| image.png | Post your hack on the[Bounty Board](https://www.google.com/url?q=https://sie.enterprise.slack.com/lists/T025FCT8A/F08PU6P9Q9E?view_id%3DView08PU6PBG1W&sa=D&source=editors&ust=1767831479489565&usg=AOvVaw1hRMCl-NRZWXWYXXfWS5eM) or join another team  If you don’t already have a team, find a project on the Bounty Board and contact the team leader. |

🎩What is the Event and Submission Format?
-----------------------------------------

Each team must upload their video submissions to[Google Drive](https://www.google.com/url?q=https://drive.google.com/drive/folders/1dU9lvKLHkKq0-TypNnOTnml_wveXJQl5?usp%3Ddrive_link&sa=D&source=editors&ust=1767831479490173&usg=AOvVaw2X5zowKojGrTDBqO0b4rTx) by Wednesday, May 14th at 1300 PST.

* The video submission should not exceed 4 minutes.
* If desired, include a longer (up to 15 minutes) walkthrough of the technical design.

⚠️In the spirit of accessibility - projects should be implemented in playstation-training-sandbox using non-sensitive data.

🔑 Teams wanting to use OpenAI API Keys, are welcome to use their own, but have the option of using a temporary key for this hackathon - contact [Nate Bear](mailto:nate.bear@sony.com).  Alternatively, consider using DomoGPT - based on Anthropic for your projects

🤠 Domo and DEV Mentors - will participate in the hackathon as support resources.  They will join during Check-ins to identify opportunities where they can lean in and help teams get unblocked.

📅 Daily Schedule
----------------

Please at minimum join the Teams invite during the bolded times.

* Jamie Morrison (UK) and Emme Tuft (US) from Domo will support their respective timezones by joining during the below hours.

* US and UK teams will use the overlapping hours to update each other on progress.

⌚ Use Check-ins to connect with the rest of the hackathon participants and mentors.  Review project progress and ask for support to get unblocked.  

* Project Leads - be prepared to give a quick summary of where you are at and what kind of help you need.
* For periods that overlap with other time zones, we will extend the check-in (via Teams) to connect with the global hackathon effort.

During Lessons Learned sessions plan to review and reflect on the process of innovation and hacking with your team.

* Where did we get blocked?
* What can we do better the next day?
* Hacking IS hard – how can we support our teammates better?  How can we show up prepared?

### Monday and Tuesday

Treat Hackathon Launch a bit like a stand-up.  Present your project concept to the Domo and DEV Mentors so we can align resources to support you.  

Additionally, confirm project teams and hacking schedule.

|  |  |
| --- | --- |
| UK | US |
| 0930 - 1030 – Hackathon Launch | 0130 - 0230 |
| 1300 - 1330 – Check In | 0500 - 0530 |
| 1630 - 1730 – Lessons Learned | 0830 - 0930 – Hackathon Start |
| 2000 - 20230 | 1300 - 1330 – Check In |
| 0000 - 0030 | 1600 - 1630 - Lessons Learned |

### Wednesday

Project Submission - please record a short demo (no more than 4 minutes) of your hackathon project and upload it to [Google Drive](https://www.google.com/url?q=https://drive.google.com/drive/folders/1dU9lvKLHkKq0-TypNnOTnml_wveXJQl5?usp%3Ddrive_link&sa=D&source=editors&ust=1767831479495694&usg=AOvVaw0dU1y0rPRuvQ5bglRDv2QW) and / or drop it in the #[hackathon](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C08P3NBJ84B&sa=D&source=editors&ust=1767831479495846&usg=AOvVaw2tSE3fPxOF4sbO8mDVkwZ_) slack channel

If desired, include a longer (up to 15 minutes) walkthrough of the technical design.

|  |  |
| --- | --- |
| UK | US |
| 0930 - 1030 – Day Start | 0130 - 0230 |
| 1300 - 1430 – Hackathon End | 0500 - 0530 |
| 1630 - 1730 | 0830 - 0930 – Day Start |
| 2000 - 20230 | 1300 - 1330 – Hackathon End |

❓ Other Questions
-----------------

🏆Are there prizes?

The prize for participation is a lifetime of bragging rights (we don’t have a budget for extravagant prizes); however, we will offer pizza and after–hours beverages in San Diego.

Do I have to be on a team?

Yes, you do have to register a bounty / team, but you can be a team of 1.

Is there a limit on team size?

No.

Do all team members have to be in the same time zone or be from the same department?

No. Team composition is at the discretion of bounty owner / team leader.

Can I change teams, or participate in the hackathon after it starts?

Each participant can register for one team; however, we do encourage collaboration across teams.