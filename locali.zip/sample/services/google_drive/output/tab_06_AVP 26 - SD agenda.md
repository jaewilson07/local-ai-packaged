# AVP 26 - SD agenda

**Tab Index:** 6
**Tab ID:** h.ayrfpvtt2mcq
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.ayrfpvtt2mcq

---

AVP 26 - SD agenda