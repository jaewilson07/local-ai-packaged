# Specialist Questions

**Tab Index:** 11
**Tab ID:** h.1hr2372266sz
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.1hr2372266sz

---

Specialist Questions

DataFusion/Blendを作成した後、列に戻って名前を変更できる。

Answer: False

社内にあるデータベースをODBC経由でDomoに接続するには？

Answer: Workbench

Workbench 5.1では、スキーマの変更をいつ許可するかを選択できない

Answer: False

次のアプリケーションの詳細と設定情報はどこにありますか：DomoWorkbench.exe、Workbench.Monitor.exe、Workbench.Service.exe、Workbench.DataCollector.exe

Windowsレジストリ

Windowsタスクマネージャー

Domo Data Center

Answer: Windows Task Manager

DataFusion/Blendを使用してDataSetを結合する際、列の名前を変更できるのは一度のみである。

Answer: Probably False?

DataFusion/Blendを利用するメリットは、次のうちどれですか？

DataFusion/BlendのアクションはAnalyzerから変更できる。DataFusion/Blendでは、SQLコマンドを使用して非常に大きなDataSetを変換できる。DataFusion/Blendは、データのインデックスを作成しないため、大規模なDataSetをより効率的に処理する。DataFusion/Blendでは、文字列を数値列にキャストできる。

Answer: 2?

Workbenchのジョブ失敗のお知らせを同僚に送信したいのですが、通知タブに名前とメールアドレスが表示されません。追加するにはどうすればよいですか？

Workbenchの設定タブで設定する。

Domo Data Centerで設定する。

閲覧ユーザーの権限以上のレベルでDomoに追加する。

Answer: 3

Workbench 5.1のODBCジョブではSQLクエリをどこに入力しますか？

* Workbenchジョブのプレビュー時または実行時
* ［設定］タブの［ソースの編集］
* ［設定］タブの［処理］の［編集］ボタン

Answer: 1

Workbench 5.1では、サーバーやWorkbenchマシンの現地時間に基づいて、Workbenchジョブのトリガーをスケジュール設定できる。

正しい

誤り

Workbench 5.1の一括操作を使用して、複数のジョブで以下の操作を実行できる。:

一括エクスポートジョブを実行する

同じデータベースに接続している複数のジョブの認証情報を更新する

すべて正しい

複数のジョブを実行する

一度に複数のジョブを編集しているときに、編集内容を保存する

Answer: All are correct

Workbench 5.1では、サーバーやWorkbenchマシンの現地時間に基づいて、Workbenchジョブのトリガーをスケジュール設定できる。

正しい

誤り

Answer: True

DataSet間ですべての列とデータが一致すると仮定した場合、データ結合に使用できるDomoの3つのツールは？

Magic ETL、Workbench、Beast Mode

Magic ETL、DataFusion/Blend、MySQL DataFlow

Magic ETL、MySQL DataFlow、Webform

最適な解答を選択してください。

本日これからある会議で３つの地域にわたる１０あるテリトリーからなるデータを見たいのですが、データセットには地域の列がありません。データはオフサイトのデータベースに格納されておりWorkbenchのジョブとしてDomoに移しました。上のシナリオの示すリソースのみを使用した場合、何ができますか？

データベース管理者に、スキーマを変更して「地域」を組み込む必要のある旨を伝える。

ページフィルターを使用して各「地域」に対応する状態を基準として選択する。

Beast ModeまたはETL DataFlowで、新しい「地域」列を作成するCASE文を作成する。

コネクターにクエリを書いて、新しい「地域」の列を作成する。

Answer: Case Statement

最適な解答を選択してください。

コネクターを新規に構成するとき、最初に行うべきことは何ですか？

 認証情報を指定する。  
 適用する必要のあるPDPポリシーを決定する。  
 コネクターを実行するスケジュール時間を選択する。  
 Domoに取り込む必要のあるレポートを選択する。

Answer: String Operations

### Added 2025/3/13

MySQL DataFlowでは、出力する前に、最後の変換でデータをプレビューする必要があります。そのデータをプレビューするための最善の方法はどれですか？

各変換をクリックし、最後の変換に到達するまで［SQLを実行］を選択する。

［プレビューを実行］をクリックする。

各変換のスパナメニューをクリックし、［実行］を選択する。

最後の変換でスパナメニューをクリックし、［実行］を選択する。

Answer: 3

Domoプロフィール（プロフィール写真も含む）を正しく記入することが重要なのはなぜですか？

プロファイル情報は、Domoの2要素認証の一部として使用されるため、記入しておかないとログインできない。

他のユーザーとコンテンツを共有するには、Domoプロフィールのページに入力する必要がある。

コンテンツの所有者をすばやく特定できるため、よりコラボレーションがしやすくなる。

自分のプロファイルが完成するまで、コンテンツを一切作成できない。

Answer: 3

シンプルな再帰的DataFlowを実行するには、どのMagic ETLタイルの組み合わせを使用しますか？

データの結合、重複の削除、列を選択

列の結合、列を選択、データを結合

行の追加、重複の削除、列を選択

列の分割、列を選択、列を結合

Answer: 3

社内のMajorDomoである同僚から、マネージャーが所有している売り上げのカードが表示されないのはなぜか、という質問を受けました。どのように対応しますか？

問題のカードの下部に移動してアクセス権を持っているユーザーを確認し、同僚がそのカード内のデータを閲覧する許可を持っているかを確認する。許可されているならば、同僚とカードを共有する。

Domoで管理者ページに移動し、一括管理ツールを使用して、カードへのアクセス権を同僚に与える。

マネージャーにカードの共有を依頼するよう、同僚に教える。

Answer: 3

Domoの変換ツールは次のうちどれですか？

Blend (Datafusion)、Magic ETL、SQL DataFlow、Beast Mode

SQL DataFlow, Beast Mode、R Plugin、Adrenaline DataFlow

すべて正しい。

Magic ETL、SQL DataFlow、Beast Mode、R Plugin

Answer: 3(All)

Domoの［設定］ページで変更できない設定は、次のうちどれですか？

Domoのユーザー権限を変更する。

ユーザーの多要素認証を有効にする。

Domoインスタンスの言語。

ナビゲート中のBuzzチャットの自動切り替えを無効にする。

Answer: 1

ある列でSUM集計を実行する必要がありますが、そのデータが文字列タイプとしてDomoに取り込まれていることにあなたは気づきます。調べたところ、いくつかの値にピリオド（”.”）が含まれていることが分かりました。この問題を修正して列でSUMを実行するためには、どのETLタイルが使用できますか？

［値マッパー］と［列タイプを設定］

［文字列演算］と［列のタイプを設定］

［列の値を設定］と［列のタイプを設定］

［テキストフォーマット］と［列のタイプを設定］

Answer: 1

以前に実行したWorkbenchジョブのログはどこで見ることができますか？

Domo Data Centerにアップロード後の［DataSet Details History］タブの詳細

［ジョブ設定］タブ。

Workbench 5.1の詳細タブの［ログビューア］。

Answer: 3

ソーシャルメディアでのすべてのキャンペーンを、1つのビジュアルで比較するように求められました。Twitter、Facebook、Instagramのデータセットにはそれぞれ、インプレッション数、クリック数、コンバージョン数が含まれています。いくつかの変換を適用してデータをクリーンアップする必要もあります。これを最も効果的に行うための手順は、以下のうちどれですか？

 

Domoコネクターを使ってデータを取り込む。その後、Beast ModeでCASE文を作成し、インプレッションやクリック、コンバージョンといった各要素が各キャンペーンでどの程度になっているか調べる。

Workbenchを使用して、異なるソーシャルメディアキャンペーンのすべてについて集めた異なるExcelファイルからデータを引き出し、各Excelファイルを毎日実行するようにスケジュールして、更新されたDataSetを提供し、Workbenchでデータを変換して、それぞれがどれだけ生産的であるかを説明する。

Domoコネクターを使ってデータを取り込む。次にMagic ETLを使い、列の名前を変更してDataSet全体を正規化し、変換を適用した後に、データを結合する。

複数のソースからDataFlowを作成し、データを結合する。この場合、最も多い情報を持つソーシャルメディアキャンペーンを確実に左結合（left-joining）する。

Answer: 3

Magic ETLでは、どのタイルで結合を実行することができますか？

列を折りたたむ

重複を削除

データを結合

行を追加

Answer: 3