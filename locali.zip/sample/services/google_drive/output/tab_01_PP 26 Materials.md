# PP 26 Materials

**Tab Index:** 1
**Tab ID:** h.7kwkup9a4gn
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.7kwkup9a4gn

---

PP 26 Materials

Timeline
--------

### 📅 Key Deadlines & Timeline

|  |  |
| --- | --- |
| Date | Milestone |
| Oct 31 | Confirm conference dates, lock agenda tracks |
| Dec 11 | Vendor Tent participants finalized |
| Jan 14 | Community presentations finalized |
| Feb 10 | Final Prep Deadlines (for translation for Tokyo edition) |
| Feb–Mar | Palooza events (London → San Diego → Tokyo) |

### By Dec 4 announce Dec 11

* Confirm or propose amendments for the agenda for Days 1–3 (Due Dec 5)
* Estimate number of participants for certification tracks
* Ensure Day 2 & 3 trainers are in-person
* Registration form for participants

### By Jan 9 announce Jan 14

SWAG

![](images/image9.png)

Asked Regina H → Ref #4343301102

Schedule

* OZ - to finalize local schedule

* OZ - allocate DPT staff for each block (Days 1–4) – POC in case of emergency
* Team building

* Jenn & Matt - pls confirm a list of proposed sessions that we can put into a schedule (name and short description and preferred date / time)

AMA & Community Day

* Confirm which sessions are in-person, remote, or prerecorded
* Finalize Vendor Tent
* Identify presenters for Community Presentations

Audience

* ALL - Estimate audience size & provide regional split
* Jenn & Matt - pls plan to advertise to your audiences

* GDoc – announcement text
* [Confluence page](https://www.google.com/url?q=https://confluence.sie.sony.com/x/e7xObQ&sa=D&source=editors&ust=1767831479311567&usg=AOvVaw3j7Gs4tkOgm5oxzTRFXkRn)
* [Registration Form](https://www.google.com/url?q=https://forms.office.com/Pages/ResponsePage.aspx?id%3Dil3GZliRIUWi2GZJY9tI5GgHgk0UogRMgYWaURrUWnBUODZUSDQzRExUUjNWR1lQS0NIT0U5QldYNS4u&sa=D&source=editors&ust=1767831479311755&usg=AOvVaw3dmjkM_amNv0laqhgTBLDJ)
* Call for Presenters - done

Participant Coms

* OZ - send pre-event email

welcome email, pre-work, track sign-up

Call for presenters

Call for BYOP (Bring Your own Project)

* Project registration
* Finalize BYOP support staff
* How can we handle ‘kick the tires’ sandboxes?

Microstrategy Day

* Are we communicating with this User Generated Content?

* Communicate with folks who took previous trainings (Sean UK, TM US, JPN, Petar?)

* Project teams register for a slot

Logistics

* DPT - Confirm room bookings for all sessions

* Day 1 Hackathon - 1 room
* Day 2 Cert Prep - 4 rooms
* Day 3 Cert - 4 rooms
* Day 4 AMA - 2 rooms
* Day 5 Microstrategy Day - 1 room

Certification

* ALL - Confirm in-person staffing for all 3 locations
* Confirm certification pre-work or prerequisites
* Ensure accounts & licenses / workspaces are provisioned for certification candidates

Japanese Translation

* Confirm who will provide Japanese Translation services
* Prepare hackathon project ideas (cross-platform encouraged)

Hackathon - JW

* Identify staff to support hacker sessions (1100–1200 & 1500–1600)
* Define hackathon judging criteria & rubric
* Create hackathon submission process
* Identify hackathon mentors and assign teams

Vendor Tent

* Sign up for Vendor Tent slots (Due Jan 9)
* Submit recordings (Jan 14)

### By Feb 10 (for JPN)

Team Agenda

* Coordinate catering headcount & dietary needs

Translation

* Prepare translated materials for Tokyo
* Confirm translator scheduling for Tokyo

### Post-Event

* Prepare attendee survey
* Schedule lessons-learned review
* Gather certification completion results
* Upload recorded sessions (if applicable)

Planning
--------

### Official dates and locations

February 2 - 6 2026 - London Edition

10 Great Marlborough St London W1F 7LP

February 9-13 2026 - San Diego Edition

16530 Via Esprillo, San Diego, CA 92127

March 2 - 6 2026 - Tokyo Edition-- イベントは日本語で開催されます

Sony City 1 Chome-7-1 Konan, Minato City, Tokyo 108-0075

### Day 1: Cafe Day & Hackathon

“Kick the tires day” - Provide time for teams to explore your platform.

PP26 staff will be available to support and guide cafe day / hackathon teams (in person or online)

* Prepare ideas for hackathon projects for other teams to latch onto.  Ideally featuring a cross-platform collaboration.
* Identify staff members to be available to support hackers during check-in sessions (1100-1200 and 1500-1600)

### Day 2: SIE Enablement and Certification preparation

* Confirm if there will be staff in person at all 3 locations
* Sessions could be repeated based on the participation demand (i.e. 2 Advanced session)
* Estimated audience size (is it worth running if the audience is particularly small)

* Regional split

|  |  |  |  |
| --- | --- | --- | --- |
|  | Domo | Tableau | Adobe |
| 0900 - 1030 | Data consumption & analysis training | Advanced |  |
| 1045 - 1215 | Data pipeline development | Beginner | Beginner |
| 1330 - 1600 |  |  | Advanced |

### Day 3: Cafe Day / BYOP (bring your own project) and Certification

|  |  |  |  |
| --- | --- | --- | --- |
|  | Non-certification Track | Domo Certification | Other Certifications |
| 0900 - 1230 | Hackathon Innovation work | Domo Professional |  |
| 1230 - 1330 Lunch |  |  |  |
| 1330 - 1700 | Hackathon & Solutions Consulting (BYOP) | Data Specialist & MajorDomo | Adobe CJA Practitioner? |

### Day 4: DSAE Community, Council and AMA

* Sessions can be in-person or remote or prerecorded
* Platform teams can assign for Vendor Tent slots

|  |  |  |  |
| --- | --- | --- | --- |
|  | Non-certification track | Certification track | Vendor Tent (Online) |
| 0800 - 0900 |  | Follow up certification time |  |
| 0900 - 1000 |  | Follow up certification time | Adobe Time |
| 1000 - 1100 |  | Follow up certification time | Domo Presentation |
| 1100 - 1200 |  | Follow up certification time |  |
| 1200 - 1300 | CAB + Lunch |  |  |
| 1300 - 1400 | CAB + Lunch |  |  |
| 1400 - 1500 | Hackathon Showcase + Community Presentations |  | Adobe Time |
| 1500 - 1600 | Hackathon Showcase + Community Presentations |  |  |
| 1600 - 1700 | Hackathon Showcase + Community Presentations |  |  |

Day 5 - Microstrategy Day (optional)
------------------------------------

Project teams should register for a slot

Solutions / Enablement Teams  work in Pods to address issues

🎮 How Platform Teams Can Participate in AVP Palooza
---------------------------------------------------

Platform teams have three primary participation paths, ranging from high-touch (certification/training) to lightweight (community presentations). Teams can choose any combination depending on availability, platform maturity, and interest.

### Certification & Training Track (High Commitment)

This year AVP Palooza is expanding our training and certification track to invite non-Domo platform teams to provide training for developers, administrators and power users.

A dedicated track during:

* Day 2 — Certification Prep
* Day 3 — Certification Exams

#### ✔️ Participation Requirements

* Must commit to being in-person in all 3 countries

* Provide training materials and guidance for your platform’s certification
* Deliver live prep sessions and support learners through the prep and exam process
* Support certification testing logistics on Day 3

#### 👍 Best For Teams Who:

* Already have a mature training or certification program
* Can commit to global travel
* Want deep exposure to engineers and analysts across SIE

### Participate in the “Vendor Tent” (Medium Commitment)

Imagine the exhibitor hall at a standard conference

#### ✔️ Participation Requirements

* Deliver 1–2 breakout session(s)  
   Formats allowed:

* In-person
* Online or Pre-recorded (session) with remote Q&A in all 3 countries

* Provide hands-on access to the platform during hackathon days (Day 1 & 3)

* Guided starter projects or APIs

#### 👍 Best For Teams Who:

* Have great demos or use cases to show
* Want to increase platform adoption
* Can support hands-on innovation without full in-person travel

### Short Community Presentation (Low Commitment)

Teams may present a 20–30 minute session on Day 4’s community segment.

#### ✔️ Participation Requirements

* Must be live or online
* Only required to present in one country, but welcome to present in multiple
* Selection finalized by Jan 19

#### 👍 Best For Teams Who:

* Want to share thought leadership, best practices, or internal wins
* Have limited travel availability
* Prefer a single-session involvement

🧭 Additional Context for Platform Teams
---------------------------------------

* This year’s Palooza is expanding beyond the traditional training-only focus.
* New elements include:

* Hands-on innovation day (hackathon)
* Vendor Tent (platform showcases)
* MicroStrategy migration enablement (parallel track supported by DPT)

* MSTR migration is not the core focus of AVP Palooza but a supplemental activity while traveling.

Links
-----

Last year’s event:[PlayStation Palooza 2025](https://www.google.com/url?q=https://confluence.sie.sony.com/display/DOMO/Jan%2B27-Feb%2B14%252C%2B2025%2B%257C%2BPlayStation%2BPaloooza&sa=D&source=editors&ust=1767831479332819&usg=AOvVaw35y_KAFG2wJoc8FZjkR9aK)