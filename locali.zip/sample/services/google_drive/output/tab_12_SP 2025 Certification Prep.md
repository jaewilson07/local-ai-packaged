# SP 2025 Certification Prep

**Tab Index:** 12
**Tab ID:** h.pvyuf89en58x
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.pvyuf89en58x

---

SP 2025 Certification Prep

Domo-led PlaystationPalooza Certification Prep Training
=======================================================

✅ Register for the Major Domo Certification
-------------------------------------------

Go to learndomo.domo.com and register for the “Major Domo” certification.  This certification requires you to pass the Domo Professional and Domo Data Specialist exams as a prerequisite.

English version  [https://learndomo.domo.com/learn/courses/384/majordomo-certification-v20/lessons](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/384/majordomo-certification-v20/lessons&sa=D&source=editors&ust=1767831479413585&usg=AOvVaw12Kq8ibsVV3VzLbfGhbbGn)

Japanese version

[https://learndomo.domo.com/learn/courses/663/jpmajordomo-exam-v20](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/663/jpmajordomo-exam-v20&sa=D&source=editors&ust=1767831479414029&usg=AOvVaw2ivqc0bi0eb1RlfBNrZK5u)

Domain playstation.domo.com

Use code:  playstationpartners-202310 to waive the exam fees.

The certification registration includes:

* two attempts
* non-graded preparatory content
* A required practical exam
* A required multiple choice knowledge exam

💡 SIE users with elevated privileges must complete Domo Certification exams.
----------------------------------------------------------------------------

Effective March 31, 2025, [Domo certifications](https://www.google.com/url?q=http://learndomo.domo.com&sa=D&source=editors&ust=1767831479414929&usg=AOvVaw0fuSguG4jhPNr3vaDOoySH) will be mandatory for retaining elevated privileges in Domo.  This impacts all roles greater than sie\_priviliged\_user (sie\_instance\_admin, sie\_content\_admin, sie\_data\_admin).

To facilitate achieving certifications before the deadline, the Domo Platform Team (DPT) and Analytics and Visualization Platform Team (AVP) will host certification training and examination sessions as part of the annual [PlaystatationPalooza](https://www.google.com/url?q=https://confluence.sie.sony.com/x/e7xObQ&sa=D&source=editors&ust=1767831479415432&usg=AOvVaw3jF0Xc2wVR_9sBoh2Kt4yC) conference.

✏️ These events can be attended in person or online ([registration link](https://www.google.com/url?q=https://forms.office.com/r/MXMb8h2VQ3&sa=D&source=editors&ust=1767831479415640&usg=AOvVaw1aJHCH-aWj0JeY1T0j9a_Z))

|  |  |
| --- | --- |
| Instance admin role | Certification level |
| sie\_content\_admin | Domo Professional certification |
| sie\_data\_admin | Domo Data Specialist certification |
| sie\_instance\_admin | Above + Major Domo |

### Exam Registration

Exam preparation resources are available at [learndomo.domo.com](https://www.google.com/url?q=http://learndomo.domo.com&sa=D&source=editors&ust=1767831479417102&usg=AOvVaw011csHAYG8Uauyt0hb8W7W).

* Login using ‘playstation’ as the domain.
* Register for exams using voucher code: playstationpartners-202310

For details about responsibilities of instance administrators refer to this [document](https://www.google.com/url?q=https://confluence.sie.sony.com/x/KI3-cg&sa=D&source=editors&ust=1767831479417599&usg=AOvVaw3BC6voaSGvpr3dKNC1VmXt).

Day 1 - Domo Professional
-------------------------

[Practical Exam Instructions](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/382/domo-professional-certification-v20/lessons/1605/domo-professional-practical-test-2h&sa=D&source=editors&ust=1767831479417929&usg=AOvVaw0mPR6lJ_Kc6m45YFcFk7Jb)

[Multiple Choice Link](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/382/domo-professional-certification-v20/lessons/1604/domo-professional-knowledge-test-2h&sa=D&source=editors&ust=1767831479418088&usg=AOvVaw37xU_jwZ0yPHaM1KDRVuoK)

The Domo Professional exam certifies user proficiency in using pre-existing data to build content to answer business questions.

### Topics covered

* Building Cards
* Setting Alerts and Notifications
* Creating Domo Publications
* Using Card Analyzer features
* Establishing governance rules for your instance
* Using Personalized Data Permissions
* Creating Domo Stories
* Using Chart Properties
* Applying data visualization principles
* Building effective dashboards
* Creating Cards to answer business questions

### Facilitated Learning

* Review & discuss the [KB guide](https://www.google.com/url?q=https://domo-support.domo.com/s/article/360042935294?language%3Den_US&sa=D&source=editors&ust=1767831479419312&usg=AOvVaw0WifR3Tofle3F5LwbRBxr8) for choosing the correct chart type. ([JA Version](https://www.google.com/url?q=https://domo-support.domo.com/s/article/360042935294?language%3Dja&sa=D&source=editors&ust=1767831479419451&usg=AOvVaw1dbDPgEJbPcr7BG2TJuDmJ))
* Walk through the example page and review the card building activity while discussing best practices for card building.
* Open discussion on any questions in the exam that users were struggling with.

### Hands-on Activities, Lunch & Exam

* Accessing training environment and resources
* Guided activity – Walk users through creating the first card from the exam practical.
* Solo activity – Users will then be allowed to create the remaining cards that are required for the practical exam.
* Content review with users to see if we meet the requirements.

### What’s next?

* Review other important knowledge base articles they users may need after the training/certification.
* General Q&A
* Course Survey

Day 1 Domo Specialist Exam
--------------------------

[Practical Exam Instructions](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/383/data-specialist-certification-v20/lessons/1607/data-specialist-knowledge-test-2h&sa=D&source=editors&ust=1767831479420681&usg=AOvVaw01Q_79R3JiyseSlWNtlNxe)

[Multiple Choice Link](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/383/data-specialist-certification-v20/lessons/1608/data-specialist-practical-test-2h&sa=D&source=editors&ust=1767831479420834&usg=AOvVaw36mugLRE6vnxYW6hj3jprt)

The Domo Specialist exam targets users that may need to design data pipelines and dashboards that span multiple data sources.

### Topics Covered

* Using the Domo Data Center
* Connection & Transformation Tools
* Domo Transformation Tools Overview
* DataSet Views

### Facilitated Learning

* Review KB guides that contain sample Beast Mode codes.
* Review, demo & discuss the Beast Mode abilities and best practices when using them.
* Review the Magic ETL activity while discussing use cases and when to use magic.
* Open discussion on any questions in the exam that users were struggling with.

### Hands-on Activities, Lunch & Exam

* Accessing training environment and resources
* Guided activity – Walk users through creating their Magic ETL activity.
* Solo Activity – Users will then be allowed to start the exam and complete the remaining activities & test questions.
* Content review with users to see if we meet the requirements.

### What’s next?

* Discuss app studio vs dashboards for advanced cases.
* Provide links to KB articles the users may need after the training/certification.
* General Q&A
* Course Survey

Day 3 - Major Domo
------------------

[Practical Exam Instructions](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/384/majordomo-certification-v20/lessons/2727/majordomo-practical-test-2h&sa=D&source=editors&ust=1767831479423128&usg=AOvVaw2FfehRXKmqqfARqucPxMJs)

[Multiple Choice Link](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/384/majordomo-certification-v20/lessons/1610/majordomo-knowledge-test-2h&sa=D&source=editors&ust=1767831479423296&usg=AOvVaw1zidW1SF0UX02RDXLJWANq)

The Major Domo exam assesses users’ ability to administrate Domo and lead a data program centered around Domo.

### Topics Covered

* Using Activity Logs to create cards and reports on your data
* Setting up Custom Roles in your instance
* Setting up Certified Content pathways in your instance
* Setting up Groups in your instance
* Using Bulk Admin tools

### Facilitated Learning

* Review & Discuss the bulk administrative tools and their primary use cases.
* Walk through the first activity for MajorDomo practical exam.
* Discuss and review the remaining practical activities for the exam.

### Hands-on Activities, Lunch & Exam

* Accessing training environment and resources
* Upload the required datasets for the activity.
* Guided activity – Walk users through the second guided activity.
* Solo activity - Users will then be allowed to create the remaining cards that are required for the practical exam.
* Content review with users to see if we meet the requirements.

 

### What’s next?

* Review other important knowledge base articles they users may need after the training/certification.
* General Q&A
* Course Survey

Links
-----

### Manual Links

[GDoc](#h.yli1hwv2bdyn)

[Confluence](https://www.google.com/url?q=https://confluence.sie.sony.com/x/gW2en&sa=D&source=editors&ust=1767831479425523&usg=AOvVaw08wW_PhQGON1b_iJQw8GJf)