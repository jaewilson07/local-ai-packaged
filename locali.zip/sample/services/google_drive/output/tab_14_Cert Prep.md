# Cert Prep

**Tab Index:** 14
**Tab ID:** h.j33pqfgibtvj
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.j33pqfgibtvj

---

Cert Prep

Wednesday - Certification Prep and Training
-------------------------------------------

Location : Sony City, SC 15-24

### 0900 - 1100 - Prepare Data Specialist Exam

Domo Trainers and DPT staff will be on hand to guide participants through test topics.  

⚠️ It is strongly recommended that participants attempt the exams at once BEFORE the training event, as the certification course assumes a baseline understanding / familiarity with the platform.  This course will not be insufficient for participants with no Domo exposure to pass the exam.

### 🧪 1100 - 1300 || Exam 1 + Lunch

Participants can take any exam they feel prepared for.

### 1300 - 1500 || Prepare Major Domo / Domo Professional Exam

Domo Trainers and DPT staff will be on hand to guide participants through test topics.  

### 🧪 1500 - 1700 || Exam 2

### Notes

Participants can take any exam they feel prepared for.

If NO PDP and I share with OZ.  then OZ sees all rows.

If enable pdp OZ sees NO ROWS unless OZ is data owner or has grant “manage all datasets”

* UNLESS i create a PDP policy to explicitly give access to a subset of data

If you share Card or Dashboard will share dataset.

* (user will see all rows and columns) UNLESS PDP

PDP policy creates a WHERE clause in the SQL query

* PDP creates “row level security”

Sharing a dataset gives access to INFORMATION\_SCHEMA

Case insetnsitive

* USD vs usd

#### How do I share content with users?

Use Publish to publish a “publication” from a departmental instance to a distribution center (playstation.domo.com)

Departmental Instance

playstation-npx-social-systems.domo.com

playstation-d2c.domo.com

playstation-ae.domo.com

Read Only Instance / Distribution Center

playstation.domo.com

Publish Domo KB Article - [https://domo-support.domo.com/s/article/360045120554?language=ja](https://www.google.com/url?q=https://domo-support.domo.com/s/article/360045120554?language%3Dja&sa=D&source=editors&ust=1767831479435500&usg=AOvVaw1eYw1fTHHJjmrejMqDSkkN)

Use Sandbox to version control your data pipeline (and assets)

DO NOT use sandbox for content distribution

Thursday - AMA + Community Presentations
----------------------------------------

Location : Sony City, SC 15-24

Community members are invited to present their work, lessons learned or projects to the SIE Domo community.  These can also be workshop sessions to explore particular or challenging topics.  See [Call For Presenters](https://www.google.com/url?q=https://docs.google.com/document/d/1hc1SHyF0huLOsIluAwMZRIHTqDap946seUf7X-AP-vU/edit?usp%3Dsharing&sa=D&source=editors&ust=1767831479436255&usg=AOvVaw2qoZl7iED-StyGWXBHRMsv)

Domo representatives will present workshops around new tooling, special topics or workflows related to trends in the broader Domo community and user base.

Domo Platform team will present workshops relevant to SIE specific projects and initiatives.

### 0915 - 0930 || AVP Resource Time to Insights

* How do we empower you to create valuable & timely insights

### 0930 - 1030 || Metadata and Domo.AI with David Johnson

* How can i get better answers / more accurate answers from my data

### 1030 - 1130 || Using Remote Domo Stats and Workflows for Instance Governance by [Anna Favis](mailto:annacarissa.favis@sony.com)

Target Audience: Analysts and Developers

Prerequisite or Supporting skills: Python, Domolibrary

### 1130 - 1230 || ETL Updates and New Features with David Johnson

* Our focus will be to optimizing ETL processes, including updates to enhance processing speed and new documentation methods using DomoStats reports. It also includes a review and demo of innovative ETL design patterns to improve workflow efficiency.

### 

### 1230 - 1330 || 🍜 Lunch Break

### 1330 - 1400 || Community presentation with [Taro Takamoto](mailto:taro.takamoto@sony.com)

### 1400 - 1500 || Connecting and joining diverse SIE data sources [Thomas Murphey](mailto:thomas.murphey@sony.com)

* Walkthrough of some of the different data sources available at SIE and how to connect to them. Some will be Domo standard connectors, while also covering more difficult data sources requiring Jupyter workspace scripting or S3 bucket and API approaches. Examples from projects worked on such as Rest Mode and CSAT.

Target Audience: Analysts and Developers

Prerequisite or Supporting skills: None

### 1500 - 1630 || Custom Apps 101 with [Antony Rowe](mailto:antony.rowe@sony.com)

* Introduction to custom apps and bricks and when to consider using them (overview of functionality available above regular cards; new vizes, personalisation, data collection, triggering workflows).  
  Custom apps vs bricks with respect to functionality and development process (github / domo cli / pubic assets).  
  Quick demo turning a D3.js example into a custom app card. TBD

Target Audience: Analysts and Developers

Prerequisite or Supporting skills: None

Friday - Follow up Exam Day
---------------------------

Location : Sony City, SC 15-24

### 0900 - 1100 || Major Domo Cert Prep

Domo Trainers and DPT staff will be on hand to guide participants through test topics.  

### 🧪 1100 - 1300 || Exam 3 & Lunch

Participants can take any exam they feel prepared for.

Participants may retake exams if necessary.