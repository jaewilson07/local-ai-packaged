# PP 2024 Materials

**Tab Index:** 19
**Tab ID:** h.tsfc7hirhg19
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.tsfc7hirhg19

---

PP 2024 Materials

❓ AMA Topics
============

I would like to use the Window function in Beast Mode to identify the latest value for each user during the period selected in Dashboard, and then display the aggregated results for only the latest value. Is it possible to use BeastMode in this way?

No – probably should use ETL or DatasetView to add a row\_number o each version of the row (sort by date desc) then can filter on “row\_version == 1” in analyzer

Connecting Data to DOMO
-----------------------

How might we capture comments about changes to connectors (versioning?)

There is no tooling in base tooling to support that.  The SIE Domo team does have a process for monitoring configuration settings.  Work with us to make sure we are capturing the data you need and we can publish it to your instance, or build your own Stats dataset via API + DomoJupyter.  [YT Video](https://www.google.com/url?q=https://www.youtube.com/watch?v%3DazGrBHpdIv4&sa=D&source=editors&ust=1767831479477733&usg=AOvVaw0eyd297RzWuFja7u0f0wLb)

Dashboards
----------

Can we go further by creating a entry box where the user can enter the discount metric on the fly?

Try using Variables.

Would I use this beast mode variable toggle if I have two metrics on my dataset that I want users to toggle between? That is, I didn't need to create a "discount" metric in beast mode, I just had both revenue and discount already on my data set.

Variables + CASE statement

Analyzer / Cards
----------------

Is there a word wrap for long text columns? // Chart Properties

* Can use HTML in HTML charts to add formatting (force line breaks or impact style)
* There is a 1024 char limit to column width.  That can be lifted on a per dataset / per column basis by request

Is there a way to display no results in a card until a filter is selected

* Wrap your beast mode with CASE WHEN COUNT DISTINCT.

Be advised if you have an aggregate function INSIDE the CASE statement, then all your ‘results’ should also be aggregated.

GOOD

CASE

WHEN COUNT(DISTINCT <filterField>) = 1 then SUM(AMOUNT)

ELSE NONE



BAD

CASE WHEN COUNT(DISTCT <filterField>) = 1 then OrderDate



Is there a way to see the % difference from previous bar on these charts?

* period over period charts / or window functions / or spark lines i believe ishe chart type

How can i rename columns?        

* ETL, DatasetView or Column properties in Analyzer

is there a way to have multiple axes on the same visualization?

* To plot on the secondary axis take a look at “chart properties” to see if you can have two y axes.

Is it possible to set default filter to show data for the single most recent date in the data set?

Yes.

Date range selector and just filer to today

if we don't know when data is coming in, add a “date\_lag” column as row\_number() or rank() column to the dataset in ETL or View with date desc.  Then filter where “date\_lag” = 1

Alerts
------

* Alerts + Slack // using webhooks?
* How do Alerts work with Publish?
* Do alerts exist at a dataset?

* I was thinking of dataset based alert triggering
* Track w/ [DomoStats](https://www.google.com/url?q=https://domo-support.domo.com/s/article/360043433813?language%3Den_US&sa=D&source=editors&ust=1767831479481556&usg=AOvVaw1yQmxQ_3pJ_DgXfLkw4jpL)

Is there a way to automate the export of these visualizations into PowerPoint?

* Office 365 Addon available Domo > Admin > Tools Download

Pipelines
---------

Connector Optimization - How can i optimize SQL in data connectors

This is a SQL DBA question.  Domo issues queries to your database engine, so the real question is “how do you optimize a SQL query in Snowflake”

In Domo, minimize the amount of data transformation you apply in a connector and instead move those transforms either into your database layer OR into Domo ETL (more transparency)

Can we schedule the ETL dataflows based on federated connectors - so we know exactly when the source  table  has been refreshed so it’ll trigger the dataflows

Can you send a trigger from your source system to hit domo’s [Execute Dataflow API](https://www.google.com/url?q=https://documenter.getpostman.com/view/5049119/UyxbppB2%237048bc0c-9455-4096-8a90-de9dd3b3c173&sa=D&source=editors&ust=1767831479482835&usg=AOvVaw0KjDsUycUwfOJ6eOAlF5oH)?

Alternatively federated dataset metadata updates every n minutes (5 to 15 depending on settings)

Governance
----------

Login - Are we using SSO, How do users access multiple instances?

SSO only in Playstation.domo.com.  Rest of instances is managed by username / password authentication.

Use Nested Beast Modes  to reuse beast modes

Publish & Sandbox - How do permissions work when publishing across different instances

* [SIE Publish Framework Confluence](https://www.google.com/url?q=https://confluence.sie.sony.com/x/YxpEbw&sa=D&source=editors&ust=1767831479483706&usg=AOvVaw1dNuIfHkGg29B1abLLtmR7)
* Permissions are tied to Roles (which actions you can take), and Groups + Sharing Content.

* Don’t assume content is automatically shared across instances, because each instance is physically separate.

Columnar PDP - is there a login parameter that allows us to control what users see / have access to (in a column) based on.

        

* No. this feature has not been implemented yet.  It is under active development.

Integration & Scripting
-----------------------

Microsoft Teams! Does domo integrate with other tools like Slack?

Sure.  if you write the script or slack bot.

What kind of allowlisting is required for Domo Code Engine to hit SIE services?

Code Engine cannot hit SIE Services b/c Domo does not sit behind SIE’s firewall.  Exceptions would have to be handled on a case by case basis.  It would probably be easier to implement automation on SIE infrastructure.

🧪Certification Process
======================

Registration Code:  playstationpartners-202310
----------------------------------------------

The exam is OPEN BOOK (you can use the internet and be in the Domo UI).  All the answers should come out of Domo’s training materials, and consulting methodology (also covered in their training materials).  You can retake the test as often as necessary to pass.

🔗 Links to Resources
====================

Jace & Riley Links

* [Training Sandbox Links](https://www.google.com/url?q=https://playstation-training-sandbox.domo.com/page/688943735&sa=D&source=editors&ust=1767831479486151&usg=AOvVaw0JUDaHcB8l0tgcwXKcb_9W)
* [Embedded Links](https://www.google.com/url?q=https://ba922ed0-7b51-4b4f-a9c2-fe796390c6cf.domoapps.prod9.domo.com/public-assets/index.html&sa=D&source=editors&ust=1767831479486326&usg=AOvVaw29qyP6MvFgnO3y0MppPfix)

API/Webhooks integrations

* [https://domotech.blog/posts/dataset\_alerts\_slack\_webhooks/](https://www.google.com/url?q=https://urldefense.com/v3/__https:/domotech.blog/posts/dataset_alerts_slack_webhooks/__;!!JkQWbQ!U8fTLSpAZO_U963FLT4nY6TzcIRBOcKoZcZZexXFamNVa8spKHDrC0PeSeyYrZbW4vAvbCDWuBpXNWHdGqk$&sa=D&source=editors&ust=1767831479486645&usg=AOvVaw0yGp1edufYg_n0feFven59)