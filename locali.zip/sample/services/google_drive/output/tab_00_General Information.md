# General Information

**Tab Index:** 0
**Tab ID:** h.5zukm1r4r7i1
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.5zukm1r4r7i1

---

General Information

SIE Playstation Domo Resources
==============================

Domo Platform Team Confluence Space
-----------------------------------

[Confluence](https://www.google.com/url?q=https://confluence.sie.sony.com/x/DmSlRg&sa=D&source=editors&ust=1767831479300232&usg=AOvVaw1vsI_bXF-J7_FOxyC_TwgL)

Teams meeting
-------------

Day 1 - TBD

Day 2 - TBD

Day 3 - TBD

Office Hours
------------

Ask [Domo Data Community Slack](https://www.google.com/url?q=https://sie.slack.com/archives/C03PHRXUFKJ&sa=D&source=editors&ust=1767831479301173&usg=AOvVaw1YeoZ9nq82tIbC6nm8WMdm) for an invite to the weekly Domo Office Hours session.

Team Office Hours - [GDoc](https://www.google.com/url?q=https://docs.google.com/document/d/1DIlOa18Ma_Efk1OBmoRoHRILbw5u-kK5EqWPx5Fo1CU/edit&sa=D&source=editors&ust=1767831479301654&usg=AOvVaw0QO-zF-svdgFoJtN-RV1-X), [Confluence](https://www.google.com/url?q=https://confluence.sie.sony.com/x/ZXRGbQ&sa=D&source=editors&ust=1767831479301809&usg=AOvVaw1Cr2wC6AA3au25VxASEHnp)

Slack Channels
--------------

Each Domo instance should have a slack channel which the Domo Data Enablement team will set up and administer for collaborating with team members.

🧵 [Domo Training Slack](https://www.google.com/url?q=https://sie.slack.com/archives/C03QE172D33&sa=D&source=editors&ust=1767831479302522&usg=AOvVaw2grW72peLYAq8ptCBxMW-9)

For questions during training sessions and for information about getting and setting up training

🧵 [Domo Data Community Slack](https://www.google.com/url?q=https://sie.slack.com/archives/C03PHRXUFKJ&sa=D&source=editors&ust=1767831479302814&usg=AOvVaw2BkWUt4QAdtMbiAl4NNIOG)

For general enablement questions

Domo Rollout Guide
------------------

The DDE team has a [Google Drive](https://www.google.com/url?q=https://drive.google.com/drive/folders/1m0BN3B0A27GbGXwm3f9LxVJCjd_ufLrY?usp%3Dsharing&sa=D&source=editors&ust=1767831479303137&usg=AOvVaw35wqQf_b1qoZNcEhLuMAJj) full of best practices and resources related to Domo implementation.

Start with the [Rollout Guide](https://www.google.com/url?q=https://docs.google.com/document/d/14y3dL9hB2zKBHd6lQVmCkzprWh8ugo9q_K0VYVvd52U/edit?usp%3Dsharing&sa=D&source=editors&ust=1767831479303388&usg=AOvVaw0DBsRpZQv4P87Lk2g73oY0)

Training Content
----------------

### Domo Immersion Recording

View the English language July / August 2022 Domo Immersion training here.

📹 [Domo Immersion - Session 1](https://www.google.com/url?q=https://drive.google.com/drive/folders/1VXXfe2LM--q9MZ6N5EAvpZjVX_CrpDX3?usp%3Dsharing&sa=D&source=editors&ust=1767831479303915&usg=AOvVaw3Ayu_K2I_BSG38ZTqb19b6)

📹 [Domo Immersion - Session 2](https://www.google.com/url?q=https://drive.google.com/drive/folders/1tAE_qTLaBu4IJRPkMYQGmDsMFBizqSoB?usp%3Dsharing&sa=D&source=editors&ust=1767831479304110&usg=AOvVaw3DHfSexA03Iat_i-JlioC2)

### Domo Certification

DSO-AE has certification vouchers available for SIE staff to pursue [Domo Certification](https://www.google.com/url?q=https://learndomo.domo.com/pages/16/get-certified&sa=D&source=editors&ust=1767831479304554&usg=AOvVaw2HUXRBbNWJhJdumJbBdRbz) and [Certification in Japanese](https://www.google.com/url?q=https://learndomo.domo.com/learn/courses/663/jpmajordomo-exam-v20&sa=D&source=editors&ust=1767831479304664&usg=AOvVaw2kF2G0zVeBhknvlYOny55K).

The commitment is approximately 11 hours of online learning modules per certification track with a capstone project at the highest certification tier.

As preparation for certification, team members should review the [self-directed learning](https://www.google.com/url?q=https://learndomo.domo.com/learn/catalog/view/55&sa=D&source=editors&ust=1767831479305091&usg=AOvVaw2cxqRq6b27WWLuGcCXd6wz) resources based on their role (front-end dashboards vs. data pipeline developer, etc.)

Domo Resources
--------------

### Knowledge Base

Domo feature and some implementation-related questions can be addressed in the [Knowledge Base](https://www.google.com/url?q=https://domohelp.domo.com/hc/en-us&sa=D&source=editors&ust=1767831479305539&usg=AOvVaw3c7gKZwQ6rvHCLrVBUHINr).

Pro tip - Domo’s internal search engine is a little weak, recommend searching directly from Google.

### Domo Video Library

Check out and follow Domo’s [YouTube channel](https://www.google.com/url?q=https://www.youtube.com/channel/UCLhtrgF6h4PP44nVRfSIovA&sa=D&source=editors&ust=1767831479305983&usg=AOvVaw2bc-RKeSJonwQKzFVvoZwr) for new content.

### Domo Community Forums

Develop your implementation skills by joining and following threads in the Domo [Forums](https://www.google.com/url?q=https://community-forums.domo.com/main&sa=D&source=editors&ust=1767831479306272&usg=AOvVaw0cJCaOjmMwXngWse_kLts0).  

Pro tip - check the leaderboard to see which users have the most points (credibility) when answering questions.

General Business Intelligence Knowledge
---------------------------------------

Ralph Kimball - [Data Warehouse Toolkit](https://www.google.com/url?q=https://www.amazon.com/Data-Warehouse-Toolkit-Definitive-Dimensional/dp/1118530802/ref%3Dasc_df_1118530802/?tag%3Dhyprod-20%26linkCode%3Ddf0%26hvadid%3D312128454859%26hvpos%3D%26hvnetw%3Dg%26hvrand%3D7142531974293178787%26hvpone%3D%26hvptwo%3D%26hvqmt%3D%26hvdev%3Dc%26hvdvcmdl%3D%26hvlocint%3D%26hvlocphy%3D9057119%26hvtargid%3Dpla-396828635481%26psc%3D1&sa=D&source=editors&ust=1767831479306777&usg=AOvVaw2LPFinu6S3jBwG3XqImD-d)

Links
-----

### Manual Links

[Self GDoc](https://www.google.com/url?q=https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp%3Dsharing&sa=D&source=editors&ust=1767831479307063&usg=AOvVaw3Ic2f1_7Z7l44faBU-1iDo)