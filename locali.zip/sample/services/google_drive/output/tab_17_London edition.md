# London edition

**Tab Index:** 17
**Tab ID:** h.i2uy0sdq5ulz
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.i2uy0sdq5ulz

---

London edition

Wednesday - AMA + Community Presentations
-----------------------------------------

Community members are invited to present their work, lessons learned or projects to the SIE Domo community.  These can also be workshop sessions to explore particular or challenging topics.  See [Call For Presenters](https://www.google.com/url?q=https://docs.google.com/document/d/1hc1SHyF0huLOsIluAwMZRIHTqDap946seUf7X-AP-vU/edit?usp%3Dsharing&sa=D&source=editors&ust=1767831479467934&usg=AOvVaw3bNlDIBwoZb4X3o4ZZgoPb)

Domo representatives will present workshops around new tooling, special topics or workflows related to trends in the broader Domo community and user base.

Domo Platform team will present workshops relevant to SIE specific projects and initiatives.

### 0915 - 0930  || How we use Alation at SIE

Data Literacy - [Alation](https://www.google.com/url?q=https://siealation.dash.playstation.net/article/1453/sie-data-literacy&sa=D&source=editors&ust=1767831479468627&usg=AOvVaw2E8T-nEqK4nvozA7K2YRXg) 

Tools and Learning Paths - [Alation](https://www.google.com/url?q=https://siealation.dash.playstation.net/article/3477/tools-training-recommended-learning-paths&sa=D&source=editors&ust=1767831479468816&usg=AOvVaw0RJmbjD27dx5NVAg7V_bOk)

CONTACT:

* Alation team:[https://sie.enterprise.slack.com/archives/CDTEQ9SGH](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/CDTEQ9SGH&sa=D&source=editors&ust=1767831479469061&usg=AOvVaw2HzxA7s1G6SjZaEoQWAQk-)
* [SIE-Alation@sony.com](mailto:SIE-Alation@sony.com)

❓

* Is Alation helpful / relevant to your work?

* Theres’s no metadata
* Use cases
* Metrics - / dimensions
* Unable to find owner information

* Used snowflake metadata
* Technical
* non technical

* Executives - page description?

* Topic // High level metrics
* Update cadence
* Is there a taxonomy of topics

* [Arvid Kristiansson](mailto:arvid.kristiansson@sony.com) - topic
* Who are the insights guys - Rob Devaney - how do they do discovery?

* Microstrategyh as a go to for deeper ad-hoc analysis

* What do you want to see in Alation?
* What can we do to improve the discoverability of your work?
* Do we need Domo to be in Alation?

* Is Domo used differently between “self service” vs. “curated experience”

![](images/image16.png)

![](images/image12.png)

![](images/image22.png)

### 0930 - 1030 ||  Metadata and Domo AI with Jamie Morrison and Jed Peterson

* How can i get better answers / more accurate answers from my data

![](images/image1.png)

* Aggregate the news… and validate against metrics in our dataset

* Commentary - summarize

* Domo > Teams notifications on dataset

* Text summarization
* (alerting) with extract of the dashboard

* (not related to AI) Governance report for unutilised pages, users, groups

### 1030 - 1100 || Variable variations with [Jordan Atkins](mailto:jordan.atkins@sony.com)

Dynamic Variables

### 1100 - 1130 || “Ask me anything” (AMA) session

### 1130 - 1230 || ETL Updates and New features in the New Year with Jamie Morrison and Jed Peterson

* Our focus will be to optimizing ETL processes, including updates to enhance processing speed and new documentation methods using DomoStats reports. It also includes a review and demo of innovative ETL design patterns to improve workflow efficiency.

### 1230 - 1330 || 🍜 Lunch Break

### 1330 - 1415 Data Visualization Guidelines with [Leah Welch](mailto:leah.welch@sony.com)

* Comprehensive and tool-agnostic guidelines for designing with your data. This will include an overview of chart types and use cases to demystify the chart selection process as well as a deep-dive into aspects of chart design including color, typography, call-outs, and aspect ratios. The conclusion will cover ways to level up your visualization practice, specifically by improving the data-ink ratio (data density).

Target Audience: Analysts, BI Developers, and anyone else who makes charts

Prerequisite or Supporting skills: None - these principles should be relevant to any toolset

### 1415 - 1430 Break

### 1430 -1515 Templatizing Content Delivery with [Leah Welch](mailto:leah.welch@sony.com)

* Learn how to take a dashboard from basic to beautiful using App Studio theming. We will cover the creation of a visual design language and the implementation of that style system as a scalable template in App Studio. Includes do’s and don’t’s of using design templates as well as an AMA section.

❓Can we link an Accessibiliy reader [Leah Welch](mailto:leah.welch@sony.com) 

* ColorBlindly Chrome add-on to see how users experience page - [Antony Rowe](mailto:antony.rowe@sony.com)

### 1515 - 1700 || Break Out Sessions

#### Custom Apps 101 with [Antony Rowe](mailto:antony.rowe@sony.com)

* Introduction to custom apps and bricks and when to consider using them (overview of functionality available above regular cards; new vizes, personalisation, data collection, triggering workflows).  
  Custom apps vs bricks with respect to functionality and development process (github / domo cli / pubic assets).  
  Quick demo turning a D3.js example into a custom app card. TBD

Target Audience: Analysts and Developers

Prerequisite or Supporting skills: None

#### [Office Hours] UX Critique & Viz Workshops with [Leah Welch](mailto:leah.welch@sony.com)

* Participants book 15-minute sessions and bring visualization problems or WIP dashboards and apps for feedback and support.
* Register interest via [slack](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C03QE172D33&sa=D&source=editors&ust=1767831479476077&usg=AOvVaw1hA97fus0WOvEAqlQVGOeR)