# PP 25 Materials

**Tab Index:** 8
**Tab ID:** h.64rtokkunr1
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.64rtokkunr1

---

PP 25 Materials

PlaystationPalooza 25 Materials
===============================

### Registration Link

✏️ Pls sign in[PlayStationPalooza Attendance](https://www.google.com/url?q=https://docs.google.com/spreadsheets/d/1iQk7OH4bHUIGFuCQdhPXhY4E_ksFeUz10LtRBIckFmo/edit?usp%3Dsharing&sa=D&source=editors&ust=1767831479387035&usg=AOvVaw33HerDGtiDBSDl2Es6zP-Q)

Training Site - [Playstation-training-sandbox.domo.com](https://www.google.com/url?q=http://playstation-training-sandbox.domo.com&sa=D&source=editors&ust=1767831479387283&usg=AOvVaw3FaRDE2Z9DlBQuG4CqxFhM)

Training Slack - [https://sie.enterprise.slack.com/archives/C03QE172D33](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C03QE172D33&sa=D&source=editors&ust=1767831479387468&usg=AOvVaw2IiTi_vtsY-DJIGkAW-NEr)

Visualization design checklist [document](https://www.google.com/url?q=https://docs.google.com/document/d/1sHW04_HCnXjmFnEJKcqGBhRIOHoAB139Y3MkOHGIynw/edit?tab%3Dt.0%23heading%3Dh.79pz9ibrthxo&sa=D&source=editors&ust=1767831479387673&usg=AOvVaw0qNXDYNvwhI_EdFmCXey6m)

 