# Domo Professional Practical

**Tab Index:** 9
**Tab ID:** h.kr3s2nq3z3qn
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.kr3s2nq3z3qn

---

Domo Professional Practical

### JP\_Domo Professional Practical Test (2h)

#### Instructions

#### Domo プロフェッショナル実技試験

#### 評価: 提出後、実技試験は1〜3週間で評価されます。

#### この試験を完了するには、採点用に9つのスクリーンショットを送信する必要があります。提出したスクリーンショットを特定できるよう、コレクション1カード1、コレクション1カード2、コレクション1カード3などの名前を付けて各スクリーンショットを保存してください。「ファイル9」、「ファイル4」など、ランダムに名前を付けないでください。また、すべてのスクリーンショットをZipファイルに格納してください。提出物は以下のとおりです:

#### 1) Analyzerから作成されたカードごとのスクリーンショット。正しいカード構成を判断します。各カードは、以下に示す特定のビジネス上の質問に答える必要があります。

#### 2) コレクション内のカードを使用して作成したダッシュボード全体のスクリーンショット。

#### 

#### カードが正しく評価されるには、次のことを正確に行う必要があります:

#### 1) 以下のビジネス上の質問に答える。

#### 2) 適切なタイトルと説明を用意する。

#### 3) 適切に構成されたまとめ数字を作成する。

#### 4) カード作成時のすべてのベストプラクティスを使用して、適切なチャートの種類、データや軸のラベル、視覚化の原則を選択する。

#### 

#### 完了したら、以下のドラッグアンドドロップオプションを使用して、zipに格納されたスクリーンショットを提出します:

#### Upload

#### 実用的なダッシュボードの作成

#### あなたは全国規模の販売会社の小売製品部門で働いています。このダッシュボードを利用する対象者は、この部門のエグゼクティブレベルの関係者です。あなたの目的は、小売の売上高を改善する際に関係者が意思決定を行うための実用的なデータを提供するカードを作成することです。

#### 

#### ページとコレクションを以下の通り作成します:

#### 1. ファイルリポジトリ領域でこの課題のサンプルデータファイルにアクセスし、サンプルデータを使用してインスタンスに新しいデータセットを作成します。

#### 2. インスタンスに新しいページを追加します。

#### 3. 新しいページに2つのコレクションを作成し、適切なタイトルを付けます。

#### 4. ビジネスに関する質問ごとに1枚のカードを作成します。

#### 

#### コレクション 1:

#### カード番号1

#### ビジネスに関する質問:  今年、全国で売り上げが集中している地域はありますか？

#### 

#### カード番号2

#### ビジネスに関する質問:  今年の在庫カテゴリー別の売り上げは月ごとにどのように推移していますか？

#### 

#### カード番号3

#### ビジネスに関する質問:  今年は、売り上げが最も高いのはどの曜日ですか？

#### 

#### カード番号4

#### ビジネスに関する質問:  今月の売上予測を満たしていますか？

#### 

#### 

#### コレクション2:

#### カード番号1:

#### ビジネスに関する質問:  販売実績で上位5つの製品は何ですか？

#### 

#### カード番号2:

#### ビジネスに関する質問:  今年のユニット、ドル、マージンには、どのような傾向がありますか？

#### 

#### カード番号3:

#### ビジネスに関する質問:  過去90日間の平均コンバージョン率が最も高い製品はどれですか？

#### 

#### カード番号4:

#### ビジネスに関する質問:  今年と比較して、昨年の平均コンバージョン率はどのように推移していますか？

#### 

#### Instructions

Domo Professional Practical Test

Evaluation: Once submitted, the Practical Test will be evaluated in 1-3 weeks.

To complete this activity, you’ll need to submit 9 screenshots for grading. Please save each screenshot with labels such as Collection 1 Card 1, Collection 1 Card 2, Collection 1 Card 3, etc. instead of random ‘file 9,’ ‘file 4’ etc. so it’s specific to what you’re submitting and save them all in a Zip file. You will need to submit the following:

1) A screenshot per Card created from Analyzer to determine correct card configuration. Each Card will need to answer a specific business question provided below.

2) A screenshot of the entire Dashboard that you’ve created with the cards in collections.

 

For a Card to be marked correct, it must accurately do the following:

1) Answer the business question provided below.

2) Have a suitable Title and Description.

3) Have a properly configured Summary Number.

4) Use all Card Building best practices around choosing the right chart type, data/axis labels, and visualization principles.

 

 Once completed, use the Drag and Drop option below to submit your zipped screenshots:

![Upload](images/image3.png)

Dashboard Build Practical

You work for a national sales company in their retail products division. The audience for this dashboard is executive-level stakeholders over this division. Your focus is creating cards that will provide actionable data for stakeholders to make decisions about improving retail sales.

 

Page and Collections build:

1. Access the sample data file for this activity in the File Repository Area and use it to create a new DataSet in your instance.

2. Add a new page in your instance.

3. Create two collections on your new page and title them appropriately.

5. Build one card for each business question.

 

Collection 1:

Card #1

BUSINESS QUESTION:  Is there a part of the country where we have a concentration of sales this year?

 

Card #2

BUSINESS QUESTION:  How are sales for each inventory category trending by month this year?

 

Card #3

BUSINESS QUESTION:  Which days of the week have the best sales this year?

 

Card #4

BUSINESS QUESTION:  Are we meeting our sales forecast for this month?

 

 

Collection 2:

Card #1:

BUSINESS QUESTION:  What are the top 5 products in sales performance?

 

Card #2:

BUSINESS QUESTION:  How are Units, Dollars and Margin trending this year?

 

Card #3:

BUSINESS QUESTION:  What products have the top average conversion rates for the last 90 days?

 

Card #4:

BUSINESS QUESTION:  How is the average conversion rate trending from one year to the next?