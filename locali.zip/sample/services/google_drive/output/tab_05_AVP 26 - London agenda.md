# AVP 26 - London agenda

**Tab Index:** 5
**Tab ID:** h.jo66jjqzb0b
**URL:** https://docs.google.com/document/d/1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY/edit?usp=drivesdk#h.jo66jjqzb0b

---

AVP 26 - London agenda

AVP-Palooza 2026 — London Edition
=================================

📍 Location: 10 Great Marlborough St, London W1F 7LP  
 📅 Dates: February 2–6, 2026

---

Day 1 — Café Day & Hackathon
----------------------------

📍 Main Room A - TBD

Theme: Explore • Collaborate • Experiment

### 0800 - 0900 || Coffee, Registration

### 0905 - 0930 || Welcome, week orientation

* Welcome to AVP-Palooza London
* Overview of the week and participation paths
* Hackathon themes, expectations, and logistics
* How to get help, find mentors, and collaborate

### 0930 - 1100 || Hackathon & Café Day (Open Working Sessions)

Please sign up for Hackathon project in [#avp\_palooza\_hackathon](https://www.google.com/url?q=https://sie.enterprise.slack.com/archives/C0A7DALFSJG&sa=D&source=editors&ust=1767831479372081&usg=AOvVaw3W8athQotmHZZlZkifbfAx) channel

* Team formation
* Ideation, problem framing, prototyping
* Platform exploration (Domo, Tableau, Adobe)

### 1100 - 1200 || Hackathon Check-in

* Informal progress updates
* Questions, blockers, and scope adjustments
* Mentor support available

### 1200-1300  || Lunch and Networking (10 GMS cafeteria)

### 1300 - 1500 || Hackathon & Café Day (Open Working Sessions)

* Continued building and experimentation
* BYOP (Bring Your Own Project) encouraged
* AVP team available for ad-hoc support

### 1530 - 1630 || Hackathon Check-in

* Progress sharing
* Blockers and support requests
* Optional prep for later-week showcase

### 1630 - 1700 || Q&A, next steps

* Open Q&A
* Recap of the day
* Informal progress sharing
* Preview of Day 2 enablement and certifications

Day 2 — Enablement & Certification Prep
---------------------------------------

Theme: Learn • Practice • Prepare

### 0800 - 0845 || Arrival and coffee

📍 Main Room A - TBD

### 0845 - 0900 || Day 2 Kick off

📍 Main Room A - TBD

* Enablement goals for the day
* Certification tracks and logistics

### 0900 - 1030 || Enablement tracks (parallel sessions)

#### 📍 DOMO track  - Room A TBD

* Data consumption & analysis training
* Core platform concepts
* Certification prep exercises

#### 📍 Tableau track  - Room B TBD

* Tableau training for advanced users
* Advanced use cases and best practices
* Certification prep

#### 📍 Adobe track  - Room C TBD

* Adobe CJA training
* Platform overview and workflows
* Certification prep

#### 📍 Non certification track  - Room D TBD

* Continued building and experimentation
* BYOP (Bring Your Own Project) encouraged

### 1030 - 1045 || coffee break

### 1045 - 1215 || Enablement tracks (parallel sessions)

#### 📍 DOMO track  - Room A TBD

* Data pipeline development
* ETL pipeline concepts and implementation
* Certification prep exercises

#### 📍 Tableau track  - Room B TBD

* Tableau training for beginner users
* Foundational concepts
* Certification prep

#### 📍 Adobe track  - Room C TBD

* Adobe CJA training
* Platform overview and workflows
* Certification prep

#### 📍 Non certification track  - Room D TBD

* Continued building and experimentation
* BYOP (Bring Your Own Project) encouraged

### 1215-1330  || Lunch and Networking (10 GMS cafeteria)

### 1330 - 1600 || Enablement tracks (parallel sessions)

#### 📍 DOMO track  - Room A TBD

* Content, user, and instance administration
* Governance and best practices
* Certification prep exercises

#### 📍 Tableau track  - Room B TBD

* Tableau training for advanced users
* Advanced topics and performance considerations
* Certification prep

#### 📍 Adobe track  - Room C TBD

* Adobe training for advanced users
* Advanced workflows and use cases
* Certification prep

#### 📍 Non certification track  - Room D TBD

* Continued building and experimentation
* BYOP (Bring Your Own Project) encouraged

### 1630 - 1700 || Q&A, next steps

📍 Main Room - TBD

* Open Q&A
* Recap of the day
* Exam logistics
* Preview of Day 3 enablement and certifications

Day 3 — BYOP, Certification Exams & Innovation
----------------------------------------------

Theme: Apply • Validate • Build

### 0800 - 0845 || Arrival and coffee

📍 Main Room - TBD

### 0845 - 0900 || Day 3 Kick off

📍 Main Room - TBD

* Enablement goals for the day
* Certification tracks and logistics

### 0900 - 1230 || Certification tracks (parallel sessions)

#### 📍 DOMO track  - Room A TBD

* Domo Professional Certification Exam

#### 📍 Tableau track  - Room B TBD

* Tableau certification Exam - TBD

#### 📍 Adobe track  - Room C TBD

* Adobe CJA Business Practitioner Certification Exam

#### 📍 Non certification track  - Room D TBD

* Continued building and experimentation
* BYOP (Bring Your Own Project) encouraged

### 1230-1330  || Lunch and Networking (10 GMS cafeteria)

### 1330 - 1645 || Certification tracks (parallel sessions)

#### 📍 DOMO track  - Room A TBD

* Domo Specialist and Major Domo  Certification Exams

#### 📍 Tableau track  - Room B TBD

* Tableau certification Exam - TBD

#### 📍 Adobe track  - Room C TBD

* Adobe CJA Business Practitioner Certification Exam

#### 📍 Non certification track  - Room D TBD

* Continued building and experimentation
* BYOP (Bring Your Own Project) encouraged

### 1645 - 1700 || Q&A, next steps

📍 Main Room - TBD

* Open Q&A
* Recap of the day
* Preview of Day 4 Community day

Day 4 — Community Day, AMA & Vendor Tent
----------------------------------------

Theme: Share • Connect • Celebrate

### 0800 - 0845 || Arrival and coffee

📍 Main Room - TBD

### 0845 - 0900 || Community Day 4 Kick off

📍 Main Room - TBD

* Agenda overview
* How sessions, Vendor Tent, and AMA work

0900 - 1200 || Certification tracks and Vendor tent (online (parallel sessions)

#### 📍 Non-certification track  - Room A TBD

* Continued building and experimentation
* BYOP (Bring Your Own Project) encouraged

#### 📍 Certification track  - Room B TBD

* Follow up certification time

#### 📍 Vendor tent  - Online

* 0900 - 1000 Adobe Presentation - TBD
* 1000 - 1100 Domo Presentation - TBD
* 1100 - 1200 Tableau Presentation - TBD

1200 - 1400 || Client Advisory Board (CAB) + Lunch

1400 - 1700 || Community tracks and Vendor tent (online (parallel sessions)

#### 📍 Non-certification track  - Room A TBD

* Hackathon Showcase
* Community Presentations

#### 📍 Certification track  - Room B TBD

* 1400 - 1500 AMA sessions with Tableau experts
* 1500 - 1600 AMA sessions with Domo experts
* 1500 - 1600 AMA sessions with Adobe experts

#### 📍 Vendor tent  - Online

* 1400 - 1500 - TBD
* 1500 - 1600 - TBD
* 1600 - 1700 - TBD

### 

### 1700 - 1730 || Q&A, next steps

📍 Main Room A - TBD

* Key takeaways
* Recap of the day

### 1830 - 2100 || Networking Dinner (optional)

Day 5 — MicroStrategy Migration Day (Optional)
----------------------------------------------

📍 Main Room A - TBD

Theme: Migrate • Plan • Execute

### 0800 - 0900 || Arrival and coffee

📍 Main Room A- TBD

### 0900 - 0930 || Day 5 Kick off

📍 Main Room A- TBD

* Day 5 objectives
* Pod assignments

### 0930 - 1230 || Solutions Consulting Pods

📍 Main Room - TBD

* Review existing MicroStrategy dashboards
* Map migration paths to Domo and Tableau
* Identify blockers and dependencies

### 1230 - 1330  || Lunch and Networking (10 GMS cafeteria)

### 1330 - 1600 || Microstrategy migration AMA, BYOP

📍 Main Room - TBD

* AMA sessions
* BYOP consulting
* Architecture and governance guidance

### 1600 - 1630 || Day 5 wrap-up

📍 Main Room A - TBD

* Key takeaways
* Recap of the day