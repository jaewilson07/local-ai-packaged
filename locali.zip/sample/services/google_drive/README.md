# Google Drive Service Samples

This directory contains sample scripts demonstrating how to use the Google Drive service.

## Prerequisites

1. **Google Cloud Project**: Set up a Google Cloud project with Drive API enabled
2. **OAuth Credentials**: Download OAuth client credentials from Google Cloud Console
3. **Environment Variables**: Set up `.env` file with credentials:

```bash
GDOC_CLIENT='{"installed": {"client_id": "...", "client_secret": "...", ...}}'
GDOC_TOKEN='{"access_token": "...", "refresh_token": "...", ...}'
```

## Samples

### export_doc_by_tabs.py

Retrieves a specific Google Doc and saves each tab as a separate markdown file.

**Usage:**
```bash
uv run python sample/services/google_drive/export_doc_by_tabs.py
```

**Features:**
- Connects to Google Drive using credentials from .env
- Retrieves document ID: `1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY`
- Exports each tab with metadata (title, ID, parent ID, deep link)
- Saves files to `sample/services/google_drive/output/`
- Filename format: `tab_<index>_<title>.md`
- Uses `upsert_folder` utility to ensure output directory exists

**Output:**
Each tab is saved with:
- Tab title as main heading
- Metadata section (index, ID, parent ID, URL)
- Full markdown content from the tab

## Output Directory

The `output/` directory contains the exported markdown files. Files are named:
- `tab_00_<first_tab_title>.md`
- `tab_01_<second_tab_title>.md`
- etc.

Each file includes:
- Tab metadata
- Deep link to the specific tab in Google Docs
- Full markdown content

## Notes

- The document ID can be changed in the script
- Invalid characters in tab titles are replaced with underscores
- Tabs are numbered starting from 0
- Empty or missing tab metadata is handled gracefully
- Parent directories are created automatically using `upsert_folder`
