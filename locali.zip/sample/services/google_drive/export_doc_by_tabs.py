"""
Sample script to retrieve a Google Doc and save it as separate markdown files by tab.

This script demonstrates:
1. Connecting to Google Drive with credentials from .env
2. Retrieving a specific Google Doc by ID
3. Exporting each tab as a separate markdown file

Requires GDOC_CLIENT and GDOC_TOKEN in .env file.
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

# Add project root to path
ROOT_DIR = Path(__file__).resolve().parents[3]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from src.services.google_drive import GoogleDriveService
from src.utils import upsert_folder

console = Console()


def sanitize_filename(filename: str) -> str:
    """Sanitize filename by removing invalid characters."""
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, "_")
    return filename.strip()


def main():
    # Load environment variables
    load_dotenv()

    # Verify credentials
    if not os.getenv("GDOC_CLIENT") or not os.getenv("GDOC_TOKEN"):
        console.print(
            "[red]❌ Error: GDOC_CLIENT and GDOC_TOKEN not found in .env file[/red]"
        )
        console.print(
            "[yellow]Please set up Google Drive credentials in your .env file[/yellow]"
        )
        return 1

    # Document ID to retrieve
    document_id = "1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY"
    
    console.print(f"[cyan]Retrieving Google Doc: {document_id}[/cyan]")

    # Initialize Google Drive service
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Initializing Google Drive service...", total=None)
        
        try:
            service = GoogleDriveService()
            progress.update(task, description="✓ Connected to Google Drive")
        except Exception as e:
            console.print(f"[red]❌ Failed to connect to Google Drive: {e}[/red]")
            return 1

        progress.stop()

    # Export tabs
    console.print("\n[cyan]Exporting document tabs...[/cyan]")
    
    try:
        tabs = service.export_tabs(document_id=document_id)
        
        if not tabs:
            console.print("[yellow]⚠ No tabs found in document[/yellow]")
            return 0
        
        console.print(f"[green]✓ Found {len(tabs)} tab(s)[/green]\n")
        
        # Create output directory using upsert_folder
        output_dir = upsert_folder(Path(__file__).parent / "output")
        
        # Save each tab as a separate markdown file
        for tab in tabs:
            # Create filename from tab title and index
            safe_title = sanitize_filename(tab.title)
            filename = f"tab_{tab.index:02d}_{safe_title}.md"
            filepath = output_dir / filename
            
            # Build markdown content with header
            content_lines = [
                f"# {tab.title}",
                "",
                f"**Tab Index:** {tab.index}",
                f"**Tab ID:** {tab.tab_id}",
            ]
            
            if tab.parent_tab_id:
                content_lines.append(f"**Parent Tab ID:** {tab.parent_tab_id}")
            
            if tab.tab_url:
                content_lines.append(f"**URL:** {tab.tab_url}")
            
            content_lines.extend(["", "---", "", tab.markdown_content])
            
            content = "\n".join(content_lines)
            
            # Write to file
            filepath.write_text(content, encoding="utf-8")
            
            console.print(
                f"[green]✓[/green] Saved tab {tab.index}: "
                f"[bold]{tab.title}[/bold] → [cyan]{filepath.name}[/cyan]"
            )
            console.print(f"  Content length: {len(tab.markdown_content)} characters")
            if tab.tab_url:
                console.print(f"  Deep link: {tab.tab_url}")
            console.print()
        
        console.print(
            f"\n[green]✅ Successfully exported {len(tabs)} tabs to {output_dir}[/green]"
        )
        
        return 0
        
    except Exception as e:
        console.print(f"[red]❌ Error exporting document: {e}[/red]")
        import traceback
        console.print(f"[red]{traceback.format_exc()}[/red]")
        return 1


if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"\n[red]Unexpected error: {e}[/red]")
        import traceback
        console.print(f"[red]{traceback.format_exc()}[/red]")
        sys.exit(1)
