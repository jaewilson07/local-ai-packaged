"""Ingestion package for processing documents into vector DB and knowledge graph."""

__version__ = "0.1.0"