---
Package: `examples/`
---

## Package identity
- Runnable examples for the MongoDB RAG agent: CLI, tools, ingestion pipeline, and Docling basics.
- Primary tech: Python, Pydantic AI, Motor (async MongoDB), Docling, UV.

## Setup & run

```powershell
uv venv
.venv\Scripts\activate
uv pip install -e .

# Ingest documents
uv run python -m examples.ingestion.ingest -d ./documents --chunk-size 1000

# Run the conversational CLI
uv run python -m examples.cli
```

## Patterns & conventions
- File organization:
  - Agent and CLI: `examples/agent.py`, `examples/cli.py`
  - Tools (semantic/hybrid search): `examples/tools.py`
  - Ingestion pipeline: `examples/ingestion/ingest.py`
  - Docling basics samples: `examples/docling_basics/*`
- Naming:
  - Functions as verbs, typed args/returns; Pydantic models for structured data
  - Async I/O for MongoDB and API calls; prefer batching for embeddings- Import patterns:
  - ✅ DO: Use absolute `from src.` imports in examples (external to src package):
    ```python
    # examples/*.py
    from src.settings import load_settings
    from src.workflows.rag.agent import create_agent
    ```
  - ❌ DON'T: Use relative imports in examples - they're outside the src package- Preferred patterns:
  - ✅ DO: Use Google-style docstrings, e.g., see `examples/tools.py` functions.
  - ✅ DO: Preserve type safety (e.g., `list[float]` for embeddings) — see `examples/ingestion/embedder.py`.
  - ✅ DO: Join chunk results with document metadata using `$lookup` — see `examples/tools.py`.
  - ❌ DON’T: Create Atlas vector indexes via Motor — configure in Atlas UI/API.
  - ❌ DON’T: Pass raw text to HybridChunker — use DoclingDocument from converter (see `examples/docling_basics/04_hybrid_chunking.py`).

## Touch points / key files
- CLI driver: `examples/cli.py`
- Agent: `examples/agent.py`
- Tools: `examples/tools.py`
- Ingestion: `examples/ingestion/ingest.py`
- Chunking: `examples/ingestion/chunker.py`
- Embedding: `examples/ingestion/embedder.py`
- Settings: `examples/settings.py`
- Prompts: `examples/prompts.py`
- Providers: `examples/providers.py`

## JIT index hints
```bash
rg -n "def (semantic_search|hybrid_search)" examples/tools.py
rg -n "class .*Chunker|DoclingHybridChunker" examples/ingestion/chunker.py examples/docling_basics
rg -n "ingest" examples/ingestion
rg -n "async def" examples | rg -n "await"
```

## Common gotchas
- Ensure `.env` is present with MongoDB/LLM/Embedding keys; use Pydantic Settings.
- Validate Atlas indexes exist before searching (handle `OperationFailure` code 291).
- Batch embeddings; avoid per-chunk synchronous calls.

## Pre-PR checks
```powershell
uv run pytest test_scripts -v
uv run python -m examples.ingestion.ingest -d ./documents --chunk-size 500
uv run python -m examples.cli
```
