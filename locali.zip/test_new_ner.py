"""Test script for the new Transformers-based NER extractor."""

import asyncio
from src.workflows.ingest.graph.ner import NERExtractor


async def main():
    """Test the NER extractor with sample text."""
    print("🧪 Testing Transformers-based NER Extractor")
    print("=" * 60)
    
    # Initialize the extractor
    print("\n1. Initializing NER extractor...")
    extractor = NERExtractor(model_name="Jean-Baptiste/roberta-large-ner-english")
    
    # Test text with various entity types
    test_text = """
    Apple Inc. was founded by Steve Jobs in Cupertino, California. 
    The company released the iPhone in 2007 and revolutionized mobile technology.
    Tim Cook became CEO in 2011 and led the company to record revenues.
    Microsoft, headquartered in Redmond, Washington, is a major competitor.
    """
    
    print(f"\n2. Test text:\n{test_text}")
    print("\n3. Extracting entities...")
    
    # Extract entities
    result = await extractor.extract(test_text)
    
    print(f"\n✅ Extraction completed in {result.extraction_time_ms:.2f}ms")
    print(f"📊 Found {len(result.entities)} entities:")
    print("\n" + "-" * 60)
    
    # Display results
    for entity in result.entities:
        print(f"  • {entity.name:25} | {entity.type.value:15} | confidence: {entity.confidence:.2f}")
    
    print("\n" + "=" * 60)
    print("✨ Test completed successfully!")
    print(f"🔧 Extractor type: {result.extractor_type}")
    print(f"🎯 Supported types: {[t.value for t in extractor.get_supported_types()]}")


if __name__ == "__main__":
    asyncio.run(main())
