# Local AI

A local development environment for AI projects using MongoDB 8.0 and Neo4j 2025 with Docker Compose, optimized for WSL and easy deployment to Linux.

## Prerequisites

- Docker Desktop with WSL 2 backend (or Docker Engine on Linux)
- WSL integration enabled in Docker Desktop (Resources → WSL Integration)
- Access to `dhi.io` registry
- Python 3.13+ (for the env generation script)

## Quick Start

**Automated Setup (Recommended):**
```bash
uv run python setup.py
```
This runs all setup tasks in sequence: environment generation, then Docker authentication.

**Manual Setup:**

1. **Generate environment file with secure passwords:**
   ```bash
   uv run python setup/generate_env.py
   ```
   When prompted, provide your DHI registry credentials:
   - `DOCKERHUB_USERNAME`: Your DHI registry username
   - `DOCKERHUB_PAT`: Your DHI Personal Access Token (PAT)

2. **Authenticate Docker with the registry:**
   ```bash
   uv run python setup/docker_login.py
   ```
   This logs Docker in using the credentials from `.env`.

3. **Start all services:**
   ```bash
   docker compose up -d
   ```

4. **Check status:**
   ```bash
   docker compose ps
   docker compose logs -f
   ```

5. **Access the services:**
   
   **MongoDB:**
   ```bash
   # Admin user
   docker exec -it mongodb mongosh -u admin -p <your-password> --authenticationDatabase admin
   
   # App user (created by init script on first run)
   docker exec -it mongodb mongosh -u appuser -p <your-password> --authenticationDatabase app
   ```
   
   **Neo4j Browser:**
   - Open http://localhost:7474
   - Username: `neo4j`
   - Password: (from your .env file)
   
   **Connection URIs for your app:**
   - MongoDB: `mongodb://appuser:<password>@mongodb:27017/app`
   - Neo4j Bolt: `bolt://neo4j:7687`

## Data Persistence

All data is stored in Docker named volumes, ensuring persistence across container restarts:
- `mongo-data` - MongoDB database files
- `neo4j-data` - Neo4j graph database
- `neo4j-logs` - Neo4j logs

**Data persists when running:** `docker compose down`

**Data is removed only with:** `docker compose down -v`

### Backup

**MongoDB:**
```bash
# Logical backup
docker exec -t mongodb mongodump --username admin --password <password> --authenticationDatabase admin --out /backup
docker cp mongodb:/backup ./mongo-backup

# Restore
docker cp ./mongo-backup mongodb:/restore
docker exec -t mongodb mongorestore --drop /restore
```

**Neo4j:**
```bash
# Backup via volume
docker run --rm -v local-ai_neo4j-data:/data -v $(pwd):/backup ubuntu tar czf /backup/neo4j-backup.tar.gz /data

# Restore
docker run --rm -v local-ai_neo4j-data:/data -v $(pwd):/backup ubuntu tar xzf /backup/neo4j-backup.tar.gz -C /
```

## Deploying to Linux

1. Copy `docker-compose.yml`, `.env`, and `docker/` folder to your server
2. Create `.env` with production credentials
3. For security, consider binding MongoDB to localhost only:
   ```yaml
   ports:
     - "127.0.0.1:${MONGO_PORT:-27017}:27017"
   ```
   Or remove `ports:` entirely if only Docker containers need access.
4. Start the stack:
   ```bash
   docker login dhi.io
   docker compose up -d
   ```

## Configuration

All settings are controlled via `.env`:

**MongoDB:**
- `MONGO_INITDB_ROOT_USERNAME` / `MONGO_INITDB_ROOT_PASSWORD` - Admin credentials
- `MONGO_APP_DATABASE` / `MONGO_APP_USERNAME` / `MONGO_APP_PASSWORD` - App DB/user
- `MONGO_PORT` - Host port mapping (default 27017)

**Neo4j:**
- `NEO4J_AUTH` - Authentication in format `username/password` (default: `neo4j/...`)
- `NEO4J_HTTP_PORT` - HTTP/Browser port (default 7474)
- `NEO4J_BOLT_PORT` - Bolt protocol port (default 7687)
- `NEO4J_PAGECACHE_SIZE`, `NEO4J_HEAP_INITIAL`, `NEO4J_HEAP_MAX` - Memory settings

## Optional Features

### Enable Replica Set (for change streams/transactions)
Uncomment in `docker-compose.yml`:
```yaml
command: ["--replSet","rs0","--bind_ip_all"]
```

Then initialize:
```bash
docker exec -it mongodb mongosh -u admin -p change-me --authenticationDatabase admin --eval "rs.initiate()"
```

## Useful Commands

```bash
# Stop and remove containers (keeps data)
docker compose down

# Stop and remove everything including volumes/data
docker compose down -v

# View logs
docker compose logs -f              # All services
docker compose logs -f mongodb      # MongoDB only
docker compose logs -f neo4j        # Neo4j only

# Restart services
docker compose restart mongodb
docker compose restart neo4j

# Check versions
docker exec -it mongodb mongosh --eval "db.version()"
docker exec -it neo4j cypher-shell -u neo4j -p <password> "CALL dbms.components() YIELD name, versions"

# List volumes
docker volume ls | grep local-ai

# Inspect volume location
docker volume inspect local-ai_mongo-data
docker volume inspect local-ai_neo4j-data
```

## Troubleshooting

**Docker command not found in WSL:**
1. Ensure Docker Desktop is running on Windows
2. Enable WSL integration: Docker Desktop → Settings → Resources → WSL Integration
3. Enable your specific distro
4. Restart WSL: `wsl --shutdown` (from PowerShell), then reopen

**Port conflicts:**
- MongoDB: Change `MONGO_PORT` in .env (default 27017)
- Neo4j HTTP: Change `NEO4J_HTTP_PORT` in .env (default 7474)
- Neo4j Bolt: Change `NEO4J_BOLT_PORT` in .env (default 7687)

**Services not healthy:**
```bash
docker compose ps        # Check health status
docker compose logs -f   # View startup logs
```
