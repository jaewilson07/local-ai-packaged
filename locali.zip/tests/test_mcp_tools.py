"""Unit and integration tests for MCP tools with dynamic discovery."""

import pytest
import json
import os
import sys
import inspect
from pathlib import Path
from typing import List, Callable
from unittest.mock import AsyncMock, MagicMock, patch

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

import src.mcp.server as mcp_server


def discover_mcp_tools() -> List[tuple[str, Callable]]:
    """Dynamically discover all MCP tool functions from the server module.
    
    Returns:
        List of (function_name, function) tuples for all mcp_* functions
    """
    tools = []
    for name, obj in inspect.getmembers(mcp_server):
        if (
            name.startswith('mcp_') 
            and inspect.iscoroutinefunction(obj)
            and name in mcp_server.__all__
        ):
            tools.append((name, obj))
    return tools


@pytest.fixture
def discovered_tools():
    """Fixture providing all discovered MCP tools."""
    return discover_mcp_tools()


def test_tool_discovery(discovered_tools):
    """Test that tool discovery finds expected MCP tools."""
    tool_names = [name for name, _ in discovered_tools]
    
    # Verify we found tools
    assert len(tool_names) > 0, "Should discover at least one MCP tool"
    
    # Verify expected tools are present
    expected_tools = [
        'mcp_search_knowledge_base',
        'mcp_ingest_documents',
        'mcp_refresh_documents',
        'mcp_convert_document',
        'mcp_preview_chunks',
        'mcp_transcribe_audio',
        'mcp_search_entities'
    ]
    
    for expected in expected_tools:
        assert expected in tool_names, f"Expected tool {expected} not found"
    
    print(f"✓ Discovered {len(tool_names)} MCP tools: {tool_names}")


def test_all_tools_are_async(discovered_tools):
    """Verify all discovered tools are async functions."""
    for name, func in discovered_tools:
        assert inspect.iscoroutinefunction(func), f"{name} should be an async function"


def test_all_tools_have_docstrings(discovered_tools):
    """Verify all discovered tools have docstrings."""
    for name, func in discovered_tools:
        assert func.__doc__, f"{name} should have a docstring"
        assert len(func.__doc__.strip()) > 10, f"{name} docstring should be descriptive"


# ==================== Individual Tool Tests ====================

@pytest.mark.unit
async def test_mcp_search_success():
    """Test MCP search tool with successful results."""
    with patch('src.mcp.server.search_knowledge_base', new_callable=AsyncMock) as mock_search:
        mock_search.return_value = "Found 3 relevant documents:\n\n--- Document 1: Test ---\nTest content"
        
        result = await mcp_server.mcp_search_knowledge_base(
            query="test query",
            match_count=5,
            search_type="hybrid"
        )
        
        assert "Found 3 relevant documents" in result
        assert "Test content" in result
        mock_search.assert_called_once()


@pytest.mark.unit
async def test_mcp_search_error_handling():
    """Test MCP search tool error handling."""
    with patch('src.mcp.server.search_knowledge_base', new_callable=AsyncMock) as mock_search:
        mock_search.side_effect = Exception("Database connection failed")
        
        # Should not raise, but handle gracefully
        try:
            result = await mcp_server.mcp_search_knowledge_base(query="test")
            # If it returns an error message instead of raising
            assert isinstance(result, str)
        except Exception:
            # If it does raise, that's also acceptable behavior
            pass


@pytest.mark.unit
async def test_mcp_convert_document_success(tmp_path):
    """Test MCP document conversion with valid file."""
    # Create a test file
    test_file = tmp_path / "test.txt"
    test_file.write_text("# Test Document\n\nThis is test content.")
    
    result = await mcp_server.mcp_convert_document(str(test_file))
    
    # Parse JSON result
    data = json.loads(result)
    
    assert "markdown" in data
    assert "title" in data
    assert "file_type" in data
    assert data["file_type"] == "txt"
    assert "Test Document" in data["markdown"]


@pytest.mark.unit
async def test_mcp_convert_document_not_found():
    """Test MCP document conversion with missing file."""
    result = await mcp_server.mcp_convert_document("/nonexistent/file.txt")
    
    # Parse JSON result
    data = json.loads(result)
    
    assert "error" in data


@pytest.mark.unit
async def test_mcp_convert_document_returns_json():
    """Test that convert_document always returns valid JSON."""
    # Test with invalid path
    result = await mcp_server.mcp_convert_document("/invalid/path")
    
    # Should return valid JSON even on error
    try:
        data = json.loads(result)
        assert isinstance(data, dict)
    except json.JSONDecodeError:
        pytest.fail("convert_document should always return valid JSON")


@pytest.mark.unit
async def test_mcp_preview_chunks_success(tmp_path):
    """Test MCP chunk preview with valid file."""
    # Create a test file with enough content to chunk
    test_file = tmp_path / "test.md"
    content = "# Test Document\n\n" + "This is a paragraph. " * 200
    test_file.write_text(content)
    
    result = await mcp_server.mcp_preview_chunks(
        str(test_file),
        chunk_size=500,
        chunk_overlap=100,
        max_tokens=256
    )
    
    # Parse JSON result
    data = json.loads(result)
    
    assert "chunks" in data
    assert "total_chunks" in data
    assert "avg_tokens" in data
    assert "title" in data
    assert data["total_chunks"] > 0
    assert len(data["chunks"]) > 0
    assert all("index" in chunk for chunk in data["chunks"])
    assert all("token_count" in chunk for chunk in data["chunks"])


@pytest.mark.unit
async def test_mcp_preview_chunks_not_found():
    """Test MCP chunk preview with missing file."""
    result = await mcp_server.mcp_preview_chunks("/nonexistent/file.txt")
    
    # Parse JSON result
    data = json.loads(result)
    
    assert "error" in data


@pytest.mark.unit
async def test_mcp_preview_chunks_parameters():
    """Test chunk preview respects different parameters."""
    # This is a parametric test concept - can be expanded
    assert hasattr(mcp_server.mcp_preview_chunks, '__code__')
    sig = inspect.signature(mcp_server.mcp_preview_chunks)
    
    # Verify expected parameters exist
    params = list(sig.parameters.keys())
    assert 'file_path' in params
    assert 'chunk_size' in params
    assert 'chunk_overlap' in params
    assert 'max_tokens' in params


@pytest.mark.unit
async def test_mcp_search_entities_success():
    """Test MCP entity search with mock data."""
    mock_result = json.dumps({
        "entities": [
            {"name": "Test Entity", "type": "PERSON", "properties": {}}
        ],
        "relationships": [
            {"from": "A", "to": "B", "type": "RELATED"}
        ]
    })
    
    with patch('src.mcp.server.search_related_entities', new_callable=AsyncMock) as mock_search:
        mock_search.return_value = mock_result
        
        result = await mcp_server.mcp_search_entities(name="Test Entity", depth=2)
        
        assert "Test Entity" in result
        mock_search.assert_called_once()


@pytest.mark.unit
async def test_mcp_search_entities_error_handling():
    """Test MCP entity search handles errors gracefully."""
    with patch('src.mcp.server.search_related_entities', new_callable=AsyncMock) as mock_search:
        mock_search.side_effect = Exception("Neo4j connection failed")
        
        result = await mcp_server.mcp_search_entities(name="Test")
        
        # Should return valid JSON with error
        data = json.loads(result)
        assert "error" in data


@pytest.mark.unit
async def test_mcp_ingest_documents_success():
    """Test MCP document ingestion."""
    with patch('src.mcp.server.DocumentIngestionPipeline') as mock_pipeline_class:
        mock_pipeline = AsyncMock()
        mock_pipeline.initialize = AsyncMock()
        mock_pipeline.ingest_documents = AsyncMock(return_value=[
            MagicMock(chunks_created=5, errors=[]),
            MagicMock(chunks_created=3, errors=[])
        ])
        mock_pipeline.close = AsyncMock()
        mock_pipeline_class.return_value = mock_pipeline
        
        result = await mcp_server.mcp_ingest_documents(
            documents_path="test_docs",
            clean_before_ingest=False
        )
        
        assert "Ingested 2 documents" in result
        mock_pipeline.initialize.assert_called_once()
        mock_pipeline.ingest_documents.assert_called_once()
        mock_pipeline.close.assert_called_once()


@pytest.mark.unit
async def test_mcp_refresh_documents_success():
    """Test MCP document refresh."""
    with patch('src.mcp.server.DocumentIngestionPipeline') as mock_pipeline_class:
        with patch('src.mcp.server.refresh_outdated_documents', new_callable=AsyncMock) as mock_refresh:
            mock_pipeline = AsyncMock()
            mock_pipeline.initialize = AsyncMock()
            mock_pipeline.db = {"documents": MagicMock()}
            mock_pipeline.close = AsyncMock()
            mock_pipeline_class.return_value = mock_pipeline
            
            mock_refresh.return_value = [MagicMock(), MagicMock(), MagicMock()]
            
            result = await mcp_server.mcp_refresh_documents(documents_path="test_docs")
            
            assert "Refreshed 3 documents" in result
            mock_pipeline.initialize.assert_called_once()
            mock_refresh.assert_called_once()
            mock_pipeline.close.assert_called_once()


# ==================== Integration Tests ====================

@pytest.mark.integration
@pytest.mark.skipif(
    not os.getenv("MONGODB_URI"),
    reason="MongoDB connection required for integration tests"
)
async def test_mcp_search_integration():
    """Integration test for MCP search with real MongoDB."""
    result = await mcp_server.mcp_search_knowledge_base(
        query="test",
        match_count=3,
        search_type="semantic"
    )
    
    # Should return a string (even if no results)
    assert isinstance(result, str)
    assert len(result) > 0


@pytest.mark.integration
@pytest.mark.skipif(
    not os.getenv("MONGODB_URI"),
    reason="MongoDB connection required for integration tests"
)
async def test_mcp_convert_integration(tmp_path):
    """Integration test for document conversion."""
    # Create a real test file
    test_file = tmp_path / "integration_test.md"
    test_file.write_text("# Integration Test\n\nThis tests real conversion.")
    
    result = await mcp_server.mcp_convert_document(str(test_file))
    data = json.loads(result)
    
    assert "markdown" in data
    assert "Integration Test" in data["markdown"]
    assert data["file_type"] == "md"


@pytest.mark.skip(reason="Requires Whisper model and audio file")
async def test_mcp_transcribe_audio_integration():
    """Integration test for audio transcription (requires setup)."""
    # This test requires:
    # 1. FFmpeg installed
    # 2. Whisper model downloaded
    # 3. A test audio file
    pass


# ==================== Parametric Tests ====================

@pytest.mark.parametrize("tool_name,expected_params", [
    ("mcp_search_knowledge_base", ["query", "match_count", "search_type"]),
    ("mcp_convert_document", ["file_path"]),
    ("mcp_preview_chunks", ["file_path", "chunk_size", "chunk_overlap", "max_tokens"]),
    ("mcp_transcribe_audio", ["file_path"]),
    ("mcp_search_entities", ["name", "depth"]),
])
def test_tool_signatures(tool_name, expected_params):
    """Test that tools have expected function signatures."""
    func = getattr(mcp_server, tool_name, None)
    assert func is not None, f"Tool {tool_name} not found"
    
    sig = inspect.signature(func)
    param_names = list(sig.parameters.keys())
    
    for expected in expected_params:
        assert expected in param_names, f"Parameter {expected} not in {tool_name} signature"


@pytest.mark.parametrize("search_type", ["semantic", "text", "hybrid"])
@pytest.mark.unit
async def test_search_types(search_type):
    """Test search with different search types."""
    with patch('src.mcp.server.search_knowledge_base', new_callable=AsyncMock) as mock_search:
        mock_search.return_value = "Results found"
        
        result = await mcp_server.mcp_search_knowledge_base(
            query="test",
            search_type=search_type
        )
        
        assert isinstance(result, str)
        # Verify search_type was passed through
        call_kwargs = mock_search.call_args[1]
        assert call_kwargs['search_type'] == search_type


# ==================== Test Utilities ====================

def test_module_exports():
    """Test that __all__ exports all mcp_ functions."""
    exported = set(mcp_server.__all__)
    
    # Get all mcp_ functions
    mcp_funcs = {
        name for name, obj in inspect.getmembers(mcp_server)
        if name.startswith('mcp_') and inspect.iscoroutinefunction(obj)
    }
    
    # All mcp_ functions should be exported
    for func in mcp_funcs:
        assert func in exported, f"{func} should be in __all__"
    
    # run_server should also be exported
    assert 'run_server' in exported


def test_run_server_exists():
    """Test that run_server function exists and is async."""
    assert hasattr(mcp_server, 'run_server')
    assert inspect.iscoroutinefunction(mcp_server.run_server)


if __name__ == "__main__":
    # Run with: pytest tests/test_mcp_tools.py -v
    pytest.main([__file__, "-v", "--tb=short"])
