"""Integration tests for Google Drive search operations.

This suite tests searching files in Google Drive and validates the results.
It will be skipped automatically if the required `GDOC_CLIENT` and `GDOC_TOKEN`
environment variables are not configured.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[3]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from src.services.google_drive import GoogleDriveService


@pytest.fixture
def gdrive_service():
    """Create a GoogleDriveService instance if credentials are available."""
    load_dotenv()
    
    if not os.getenv("GDOC_CLIENT") or not os.getenv("GDOC_TOKEN"):
        pytest.skip("GDOC_CLIENT or GDOC_TOKEN not set; skipping Google Drive integration test")
    
    return GoogleDriveService()


@pytest.mark.integration
def test_search_files(gdrive_service):
    """Test searching for files in Google Drive."""
    # Search for documents
    results = gdrive_service.search_files(
        query="test",
        top_n=5
    )
    
    assert results is not None, "Search results should not be None"
    assert results.query == "test", "Query should match input"
    assert isinstance(results.files, list), "Files should be a list"
    assert results.total_results >= 0, "Total results should be non-negative"


@pytest.mark.integration
def test_search_document_ids(gdrive_service):
    """Test searching for document IDs."""
    doc_ids = gdrive_service.search_document_ids(
        query="document",
        top_n=3
    )
    
    assert isinstance(doc_ids, list), "Result should be a list"
    assert all(isinstance(doc_id, str) for doc_id in doc_ids), "All IDs should be strings"


@pytest.mark.integration
def test_search_with_folder_id(gdrive_service):
    """Test searching within a specific folder."""
    # Use the default folder ID
    from src.services.google_drive.classes.drive_searcher import DEFAULT_FOLDER_ID
    
    results = gdrive_service.search_files(
        query="test",
        folder_id=DEFAULT_FOLDER_ID,
        top_n=5
    )
    
    assert results is not None, "Search results should not be None"
    assert results.folder_id == DEFAULT_FOLDER_ID, "Folder ID should match"


@pytest.mark.integration
def test_search_documents(gdrive_service):
    """Test searching for full document metadata."""
    docs = gdrive_service.search_documents(
        query="meeting",
        top_n=2
    )
    
    assert isinstance(docs, list), "Result should be a list"
    
    if docs:  # If any results found
        doc = docs[0]
        assert hasattr(doc, "id"), "Document should have an ID"
        assert hasattr(doc, "name"), "Document should have a name"
        assert hasattr(doc, "mime_type"), "Document should have a MIME type"
        assert hasattr(doc, "web_view_link"), "Document should have a web view link"
