"""Integration tests for Google Drive document export operations.

This suite tests exporting documents from Google Drive as markdown.
It will be skipped automatically if the required credentials are not configured.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from tempfile import NamedTemporaryFile

import pytest
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[3]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from src.services.google_drive import GoogleDriveService


@pytest.fixture
def gdrive_service():
    """Create a GoogleDriveService instance if credentials are available."""
    load_dotenv()
    
    if not os.getenv("GDOC_CLIENT") or not os.getenv("GDOC_TOKEN"):
        pytest.skip("GDOC_CLIENT or GDOC_TOKEN not set; skipping Google Drive integration test")
    
    return GoogleDriveService()


@pytest.fixture
def test_document_id():
    """Return a test document ID (update this with a valid document in your Drive)."""
    # This is a placeholder - replace with an actual document ID for testing
    doc_id = os.getenv("TEST_GDOC_ID", "1Buupso47ryzXeQvdcG9hUNUyqNE9HwjUJDFrIOjBiyY")
    return doc_id


@pytest.mark.integration
def test_export_as_markdown_with_metadata(gdrive_service, test_document_id):
    """Test exporting a document as markdown with metadata."""
    markdown = gdrive_service.export_as_markdown(
        document_id=test_document_id,
        include_metadata=True
    )
    
    assert markdown is not None, "Markdown content should not be None"
    assert isinstance(markdown, str), "Markdown should be a string"
    assert len(markdown) > 0, "Markdown should not be empty"
    
    # Check for YAML frontmatter
    assert markdown.startswith("---"), "Should start with YAML frontmatter"
    assert "title:" in markdown, "Should include title in frontmatter"
    assert "document_id:" in markdown, "Should include document_id in frontmatter"


@pytest.mark.integration
def test_export_as_markdown_without_metadata(gdrive_service, test_document_id):
    """Test exporting a document as markdown without metadata."""
    markdown = gdrive_service.export_as_markdown(
        document_id=test_document_id,
        include_metadata=False
    )
    
    assert markdown is not None, "Markdown content should not be None"
    assert isinstance(markdown, str), "Markdown should be a string"
    assert not markdown.startswith("---"), "Should not start with YAML frontmatter"


@pytest.mark.integration
def test_export_to_file(gdrive_service, test_document_id):
    """Test exporting a document to a file."""
    with NamedTemporaryFile(mode="w", suffix=".md", delete=False) as tmp:
        output_path = Path(tmp.name)
    
    try:
        markdown = gdrive_service.export_as_markdown(
            document_id=test_document_id,
            include_metadata=True,
            output_path=output_path
        )
        
        assert output_path.exists(), "Output file should exist"
        
        content = output_path.read_text(encoding="utf-8")
        assert content == markdown, "File content should match returned markdown"
        assert len(content) > 0, "File should not be empty"
    finally:
        if output_path.exists():
            output_path.unlink()


@pytest.mark.integration
def test_export_tabs(gdrive_service, test_document_id):
    """Test exporting a document with tabs."""
    tabs = gdrive_service.export_tabs(document_id=test_document_id)
    
    assert tabs is not None, "Tabs should not be None"
    assert isinstance(tabs, list), "Tabs should be a list"
    
    if tabs:  # If document has tabs
        tab = tabs[0]
        assert hasattr(tab, "tab_id"), "Tab should have an ID"
        assert hasattr(tab, "title"), "Tab should have a title"
        assert hasattr(tab, "index"), "Tab should have an index"
        assert hasattr(tab, "markdown_content"), "Tab should have markdown content"
        assert isinstance(tab.markdown_content, str), "Markdown content should be a string"
        assert len(tab.markdown_content) > 0, "Markdown content should not be empty"


@pytest.mark.integration
def test_export_invalid_document(gdrive_service):
    """Test exporting an invalid document ID."""
    with pytest.raises(ValueError, match="Failed to export document"):
        gdrive_service.export_as_markdown(
            document_id="invalid_document_id_12345",
            include_metadata=True
        )
