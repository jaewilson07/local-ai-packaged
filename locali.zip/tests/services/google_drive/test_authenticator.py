"""Unit tests for GoogleAuth.

Tests credential loading, refresh, and error handling.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

ROOT_DIR = Path(__file__).resolve().parents[3]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from src.services.google_drive.classes import GoogleAuth


def test_authenticator_missing_credentials():
    """Test that missing credentials raise ValueError."""
    with patch.dict(os.environ, {}, clear=True):
        with pytest.raises(ValueError, match="Missing Google Drive credentials"):
            GoogleAuth()


def test_authenticator_missing_token():
    """Test that missing token raises ValueError."""
    with patch.dict(
        os.environ,
        {"GDOC_CLIENT": '{"installed": {"client_id": "test"}}'},
        clear=True,
    ):
        with pytest.raises(ValueError, match="Missing Google Drive credentials"):
            GoogleAuth()


@patch("src.services.google_drive.classes.google_drive_authenticator.Credentials")
@patch("src.services.google_drive.classes.google_drive_authenticator.Request")
def test_authenticator_loads_credentials(mock_request, mock_credentials):
    """Test successful credential loading."""
    mock_creds = MagicMock()
    mock_creds.expired = False
    mock_credentials.return_value = mock_creds

    token_data = {
        "access_token": "test_access",
        "refresh_token": "test_refresh",
        "token_uri": "https://oauth2.googleapis.com/token",
        "client_id": "test_client",
        "client_secret": "test_secret",
        "scopes": ["https://www.googleapis.com/auth/drive.readonly"],
    }

    with patch.dict(
        os.environ,
        {
            "GDOC_CLIENT": '{"installed": {"client_id": "test"}}',
            "GDOC_TOKEN": json.dumps(token_data),
        },
    ):
        authenticator = GoogleAuth()
        assert authenticator.creds is not None


@patch("src.services.google_drive.classes.google_drive_authenticator.Credentials")
@patch("src.services.google_drive.classes.google_drive_authenticator.Request")
def test_authenticator_refreshes_expired_credentials(mock_request, mock_credentials):
    """Test that expired credentials are refreshed."""
    mock_creds = MagicMock()
    mock_creds.expired = True
    mock_creds.refresh_token = "test_refresh"
    mock_credentials.return_value = mock_creds

    token_data = {
        "access_token": "test_access",
        "refresh_token": "test_refresh",
        "token_uri": "https://oauth2.googleapis.com/token",
        "client_id": "test_client",
        "client_secret": "test_secret",
        "scopes": ["https://www.googleapis.com/auth/drive.readonly"],
    }

    with patch.dict(
        os.environ,
        {
            "GDOC_CLIENT": '{"installed": {"client_id": "test"}}',
            "GDOC_TOKEN": json.dumps(token_data),
        },
    ):
        authenticator = GoogleAuth()
        mock_creds.refresh.assert_called_once()


@patch("src.services.google_drive.classes.google_drive_authenticator.Credentials")
@patch("src.services.google_drive.classes.google_drive_authenticator.Request")
def test_authenticator_refresh_if_needed(mock_request, mock_credentials):
    """Test manual refresh when needed."""
    mock_creds = MagicMock()
    mock_creds.expired = False
    mock_credentials.return_value = mock_creds

    token_data = {
        "access_token": "test_access",
        "refresh_token": "test_refresh",
        "token_uri": "https://oauth2.googleapis.com/token",
        "client_id": "test_client",
        "client_secret": "test_secret",
    }

    with patch.dict(
        os.environ,
        {
            "GDOC_CLIENT": '{"installed": {"client_id": "test"}}',
            "GDOC_TOKEN": json.dumps(token_data),
        },
    ):
        authenticator = GoogleAuth()
        
        # Simulate expiration
        mock_creds.expired = True
        authenticator.refresh_if_needed()
        
        mock_creds.refresh.assert_called()
