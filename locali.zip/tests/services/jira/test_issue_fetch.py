"""Integration tests for Jira issue retrieval.

This suite fetches a known ticket and validates that issue links and
comments are present. It will be skipped automatically if the required
`JIRA_TOKEN` environment variable is not configured.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Iterable, List

import pytest
from dotenv import load_dotenv


ROOT_DIR = Path(__file__).resolve().parents[3]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from src.services.jira.classes import JiraAuth


def _collect_linked_issue_keys(links: Iterable[object]) -> List[str]:
    """Extract linked issue keys from Jira link objects."""

    linked_keys: List[str] = []
    for link in links:
        outward = getattr(link, "outwardIssue", None)
        inward = getattr(link, "inwardIssue", None)

        if outward and getattr(outward, "key", None):
            linked_keys.append(outward.key)
        if inward and getattr(inward, "key", None):
            linked_keys.append(inward.key)

    return linked_keys


@pytest.mark.integration
def test_fetch_issue_includes_links_and_comments() -> None:
    """Fetch an issue and verify it contains links and comments."""

    load_dotenv()
    if not os.getenv("JIRA_TOKEN"):
        pytest.skip("JIRA_TOKEN not set; skipping Jira integration test")

    client = JiraAuth()
    issue_key = "DSOAE-11623"

    issue = client.get_ticket(issue_key)
    assert issue is not None, f"Issue {issue_key} should exist"

    fields = getattr(issue, "fields", None)
    assert fields is not None, "Issue fields should be present"

    # Validate issue links
    links = getattr(fields, "issuelinks", None)
    assert links is not None, "issuelinks should be present on the issue"
    linked_keys = _collect_linked_issue_keys(links)
    assert linked_keys, "Expected at least one linked issue"

    # Validate comments
    comment_block = getattr(fields, "comment", None)
    assert comment_block is not None, "comment block should be present"

    comments = getattr(comment_block, "comments", None) or []
    assert comments, "Expected at least one comment on the issue"

    bodies = [getattr(comment, "body", "").strip() for comment in comments]
    assert any(bodies), "Comment bodies should not be empty"
