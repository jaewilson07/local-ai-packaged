---
Package: `test_scripts/`
---

## Package identity
- Test suite for agent and RAG pipeline: E2E, integration, and functional tests.
- Primary tech: Pytest.

## Setup & run

```powershell
uv venv
.venv\Scripts\activate
uv pip install -e .

# Run all tests
uv run pytest test_scripts -v

# Run focused tests
uv run pytest test_scripts/test_agent_e2e.py -v
uv run pytest test_scripts/test_rag_pipeline.py -v
```

## Patterns & conventions
- Co-locate tests by scenario rather than unit-only; prefer realistic data flows.
- Use markers (`@pytest.mark.integration`, `@pytest.mark.e2e`) to separate scopes.
- Mock external APIs selectively; prefer running against real Atlas where safe.
- **Import Pattern**: Use absolute imports in tests (external to src package):
  ```python
  # tests/test_agent_e2e.py
  from src.workflows.rag.agent import create_agent
  from src.workflows.rag.dependencies import AgentDependencies
  from src.settings import load_settings
  
  # tests/services/jira/test_issue_fetch.py
  from src.services.jira.service import JiraService
  from src.services.jira.models import JiraIssue
  ```

## Touch points / key files
- E2E agent: `test_scripts/test_agent_e2e.py`
- RAG pipeline: `test_scripts/test_rag_pipeline.py`
- Search: `test_scripts/test_search.py`
- Cluster/index checks: `test_scripts/check_cluster_info.py`, `test_scripts/check_indexes.py`

## JIT index hints
```bash
rg -n "@pytest" test_scripts
rg -n "mongodb|vectorSearch|rankFusion" test_scripts
rg -n "Agent|tools|ingestion" test_scripts
```

## Common gotchas
- Ensure `.env` values exist; leverage `src/test_config.py` for validation.
- Seed minimal documents in Atlas before running search tests.
- Respect async test patterns; avoid blocking calls.

## Pre-PR checks
```powershell
uv run pytest test_scripts -v
```
