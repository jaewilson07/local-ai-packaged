"""Unit and integration tests for API endpoints with dynamic discovery."""

import pytest
import json
import os
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi.testclient import TestClient
from fastapi import FastAPI

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.api.main import app
from src.api import models


def discover_api_endpoints() -> dict:
    """Dynamically discover all API endpoints from the FastAPI app.
    
    Returns:
        Dictionary mapping endpoint paths to their route info
    """
    endpoints = {}
    for route in app.routes:
        if hasattr(route, 'path') and hasattr(route, 'methods'):
            # Skip internal FastAPI routes
            if not route.path.startswith('/openapi') and not route.path.startswith('/docs'):
                endpoints[route.path] = {
                    'path': route.path,
                    'methods': route.methods,
                    'name': route.name
                }
    return endpoints


@pytest.fixture
def client():
    """Fixture providing FastAPI test client."""
    return TestClient(app)


@pytest.fixture
def discovered_endpoints():
    """Fixture providing all discovered API endpoints."""
    return discover_api_endpoints()


def test_endpoint_discovery(discovered_endpoints):
    """Test that endpoint discovery finds expected routes."""
    paths = list(discovered_endpoints.keys())
    
    # Verify we found endpoints
    assert len(paths) > 0, "Should discover at least one endpoint"
    
    # Verify expected endpoints are present
    expected_endpoints = [
        '/health',
        '/search',
        '/ingest',
        '/refresh',
        '/documents',
        '/convert',
        '/chunk',
        '/transcribe',
        '/entities/{name}',
        '/chat'
    ]
    
    for expected in expected_endpoints:
        assert expected in paths, f"Expected endpoint {expected} not found"
    
    print(f"✓ Discovered {len(paths)} API endpoints: {paths}")


def test_all_endpoints_have_methods(discovered_endpoints):
    """Verify all discovered endpoints have HTTP methods defined."""
    for path, info in discovered_endpoints.items():
        assert 'methods' in info, f"{path} should have methods defined"
        assert len(info['methods']) > 0, f"{path} should have at least one HTTP method"


@pytest.mark.parametrize("endpoint,expected_method", [
    ('/health', 'GET'),
    ('/search', 'POST'),
    ('/ingest', 'POST'),
    ('/refresh', 'POST'),
    ('/documents', 'GET'),
    ('/convert', 'POST'),
    ('/chunk', 'POST'),
    ('/transcribe', 'POST'),
    ('/chat', 'POST'),
])
def test_endpoint_methods(client, endpoint, expected_method):
    """Test that endpoints support expected HTTP methods."""
    endpoints = discover_api_endpoints()
    
    if endpoint in endpoints:
        methods = endpoints[endpoint]['methods']
        assert expected_method in methods, f"{endpoint} should support {expected_method}"


# ==================== Health Endpoint Tests ====================

@pytest.mark.unit
def test_health_endpoint(client):
    """Test health check endpoint."""
    response = client.get("/health")
    
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert data["status"] == "ok"


# ==================== Search Endpoint Tests ====================

@pytest.mark.unit
def test_search_endpoint_structure(client):
    """Test search endpoint request/response structure."""
    with patch('src.api.main.semantic_search', new_callable=AsyncMock) as mock_search:
        mock_search.return_value = []
        
        response = client.post("/search", json={
            "query": "test query",
            "match_count": 5,
            "search_type": "semantic"
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "results" in data
        assert isinstance(data["results"], list)


@pytest.mark.unit
@pytest.mark.parametrize("search_type", ["semantic", "text", "hybrid"])
def test_search_types(client, search_type):
    """Test search endpoint with different search types."""
    with patch('src.api.main.semantic_search', new_callable=AsyncMock) as mock_semantic:
        with patch('src.api.main.text_search', new_callable=AsyncMock) as mock_text:
            with patch('src.api.main.hybrid_search', new_callable=AsyncMock) as mock_hybrid:
                # Set all mocks to return empty results
                mock_semantic.return_value = []
                mock_text.return_value = []
                mock_hybrid.return_value = []
                
                response = client.post("/search", json={
                    "query": "test",
                    "search_type": search_type
                })
                
                assert response.status_code == 200


# ==================== Document Processing Endpoint Tests ====================

@pytest.mark.unit
def test_convert_endpoint_missing_file(client):
    """Test convert endpoint with missing file."""
    response = client.post("/convert", json={
        "file_path": "/nonexistent/file.txt"
    })
    
    assert response.status_code in [404, 500]


@pytest.mark.unit
def test_convert_endpoint_structure(client, tmp_path):
    """Test convert endpoint response structure."""
    # Create a test file
    test_file = tmp_path / "test.txt"
    test_file.write_text("# Test Document\n\nTest content.")
    
    response = client.post("/convert", json={
        "file_path": str(test_file)
    })
    
    assert response.status_code == 200
    data = response.json()
    assert "markdown" in data
    assert "title" in data
    assert "file_type" in data


@pytest.mark.unit
def test_chunk_endpoint_missing_file(client):
    """Test chunk preview endpoint with missing file."""
    response = client.post("/chunk", json={
        "file_path": "/nonexistent/file.txt"
    })
    
    assert response.status_code in [404, 500]


@pytest.mark.unit
def test_chunk_endpoint_structure(client, tmp_path):
    """Test chunk preview endpoint response structure."""
    # Create a test file with enough content
    test_file = tmp_path / "test.md"
    test_file.write_text("# Test\n\n" + "Content. " * 100)
    
    response = client.post("/chunk", json={
        "file_path": str(test_file),
        "chunk_size": 500,
        "chunk_overlap": 100,
        "max_tokens": 256
    })
    
    assert response.status_code == 200
    data = response.json()
    assert "chunks" in data
    assert "total_chunks" in data
    assert "avg_tokens" in data
    assert "title" in data
    assert isinstance(data["chunks"], list)


@pytest.mark.unit
def test_transcribe_endpoint_missing_file(client):
    """Test transcribe endpoint with missing file."""
    response = client.post("/transcribe", json={
        "file_path": "/nonexistent/audio.mp3"
    })
    
    assert response.status_code in [404, 500]


# ==================== Entity Search Endpoint Tests ====================

@pytest.mark.unit
def test_entities_endpoint_structure(client):
    """Test entities endpoint response structure."""
    with patch('src.api.main.search_related_entities', new_callable=AsyncMock) as mock_search:
        mock_result = json.dumps({
            "entities": [],
            "relationships": []
        })
        mock_search.return_value = mock_result
        
        response = client.get("/entities/TestEntity?depth=2")
        
        assert response.status_code == 200
        data = response.json()
        assert "entities" in data
        assert "relationships" in data
        assert "depth" in data


@pytest.mark.unit
def test_entities_endpoint_error_handling(client):
    """Test entities endpoint handles errors gracefully."""
    with patch('src.api.main.search_related_entities', new_callable=AsyncMock) as mock_search:
        mock_search.side_effect = Exception("Neo4j connection failed")
        
        response = client.get("/entities/TestEntity")
        
        # Should return error status
        assert response.status_code == 500


# ==================== Chat Endpoint Tests ====================

@pytest.mark.unit
def test_chat_endpoint_non_streaming(client):
    """Test chat endpoint with non-streaming mode."""
    with patch('src.api.main.rag_agent') as mock_agent:
        mock_result = MagicMock()
        mock_result.output = "This is a test response"
        mock_agent.run = AsyncMock(return_value=mock_result)
        
        response = client.post("/chat", json={
            "message": "test question",
            "stream": False
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "response" in data
        assert "tool_calls" in data


@pytest.mark.unit
def test_chat_endpoint_streaming_response_type(client):
    """Test chat endpoint streaming returns correct content type."""
    response = client.post("/chat", json={
        "message": "test",
        "stream": True
    })
    
    # Should return streaming response (might fail without full setup)
    # Just verify the endpoint exists and accepts the request
    assert response.status_code in [200, 500]  # 500 is ok if dependencies not mocked


# ==================== Ingest & Refresh Endpoint Tests ====================

@pytest.mark.unit
def test_ingest_endpoint_structure(client):
    """Test ingest endpoint request structure."""
    with patch('src.api.main.DocumentIngestionPipeline') as mock_pipeline_class:
        mock_pipeline = AsyncMock()
        mock_pipeline.initialize = AsyncMock()
        mock_pipeline.ingest_documents = AsyncMock(return_value=[])
        mock_pipeline.close = AsyncMock()
        mock_pipeline_class.return_value = mock_pipeline
        
        response = client.post("/ingest", json={
            "documents_path": "test_docs",
            "clean_before_ingest": False,
            "chunk_size": 1000,
            "chunk_overlap": 200,
            "max_tokens": 512
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "documents_processed" in data
        assert "total_chunks" in data
        assert "errors" in data


@pytest.mark.unit
def test_refresh_endpoint_structure(client):
    """Test refresh endpoint request structure."""
    with patch('src.api.main.DocumentIngestionPipeline') as mock_pipeline_class:
        with patch('src.api.main.refresh_outdated_documents', new_callable=AsyncMock) as mock_refresh:
            mock_pipeline = AsyncMock()
            mock_pipeline.initialize = AsyncMock()
            mock_pipeline.db = {"documents": MagicMock()}
            mock_pipeline.close = AsyncMock()
            mock_pipeline_class.return_value = mock_pipeline
            mock_refresh.return_value = []
            
            response = client.post("/refresh", json={
                "documents_path": "test_docs"
            })
            
            assert response.status_code == 200
            data = response.json()
            assert "refreshed" in data


# ==================== Documents Endpoint Tests ====================

@pytest.mark.unit
def test_documents_endpoint(client):
    """Test documents listing endpoint."""
    with patch('src.api.main.AgentDependencies') as mock_deps_class:
        mock_deps = AsyncMock()
        mock_deps.initialize = AsyncMock()
        mock_deps.cleanup = AsyncMock()
        mock_deps.settings = MagicMock()
        mock_deps.db = {
            "documents": MagicMock(
                find=lambda: MagicMock(
                    limit=lambda x: MagicMock(
                        to_list=AsyncMock(return_value=[])
                    )
                )
            )
        }
        mock_deps_class.return_value = mock_deps
        
        response = client.get("/documents?limit=10")
        
        assert response.status_code == 200
        data = response.json()
        assert "documents" in data
        assert isinstance(data["documents"], list)


# ==================== API Models Tests ====================

def test_all_request_models_exist():
    """Test that all request models are defined."""
    expected_models = [
        'SearchRequest',
        'IngestRequest',
        'RefreshRequest',
        'ConvertRequest',
        'ChunkPreviewRequest',
        'TranscribeRequest',
        'EntitySearchRequest',
        'ChatRequest',
    ]
    
    for model_name in expected_models:
        assert hasattr(models, model_name), f"Model {model_name} should exist"


def test_all_response_models_exist():
    """Test that all response models are defined."""
    expected_models = [
        'HealthResponse',
        'SearchResponse',
        'IngestResponse',
        'RefreshResponse',
        'DocumentsResponse',
        'ConvertResponse',
        'ChunkPreviewResponse',
        'TranscribeResponse',
        'EntitySearchResponse',
        'ChatResponse',
    ]
    
    for model_name in expected_models:
        assert hasattr(models, model_name), f"Model {model_name} should exist"


@pytest.mark.parametrize("model_class", [
    models.SearchRequest,
    models.ConvertRequest,
    models.ChunkPreviewRequest,
    models.ChatRequest,
])
def test_request_models_validate(model_class):
    """Test that request models have proper validation."""
    # Check that model has schema
    schema = model_class.model_json_schema()
    assert 'properties' in schema
    assert len(schema['properties']) > 0


# ==================== Integration Tests ====================

@pytest.mark.integration
@pytest.mark.skipif(
    not os.getenv("MONGODB_URI"),
    reason="MongoDB connection required for integration tests"
)
def test_health_integration(client):
    """Integration test for health endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


@pytest.mark.integration
@pytest.mark.skipif(
    not os.getenv("MONGODB_URI"),
    reason="MongoDB connection required for integration tests"
)
def test_documents_integration(client):
    """Integration test for documents listing."""
    response = client.get("/documents?limit=5")
    assert response.status_code == 200
    data = response.json()
    assert "documents" in data


@pytest.mark.integration
def test_convert_integration(client, tmp_path):
    """Integration test for document conversion."""
    test_file = tmp_path / "integration.md"
    test_file.write_text("# Integration Test\n\nReal conversion test.")
    
    response = client.post("/convert", json={
        "file_path": str(test_file)
    })
    
    assert response.status_code == 200
    data = response.json()
    assert "Integration Test" in data["markdown"]


# ==================== Error Handling Tests ====================

def test_invalid_json_handling(client):
    """Test API handles invalid JSON gracefully."""
    response = client.post(
        "/search",
        data="invalid json{",
        headers={"Content-Type": "application/json"}
    )
    
    assert response.status_code == 422  # Unprocessable Entity


def test_missing_required_fields(client):
    """Test API validates required fields."""
    response = client.post("/search", json={
        "match_count": 5
        # Missing required 'query' field
    })
    
    assert response.status_code == 422


# ==================== OpenAPI Schema Tests ====================

def test_openapi_schema_generation():
    """Test that OpenAPI schema is properly generated."""
    response = TestClient(app).get("/openapi.json")
    assert response.status_code == 200
    schema = response.json()
    assert "openapi" in schema
    assert "paths" in schema
    assert len(schema["paths"]) > 0


def test_api_documentation_accessible():
    """Test that API documentation is accessible."""
    response = TestClient(app).get("/docs")
    assert response.status_code == 200


if __name__ == "__main__":
    # Run with: pytest tests/test_api_endpoints.py -v
    pytest.main([__file__, "-v", "--tb=short"])
