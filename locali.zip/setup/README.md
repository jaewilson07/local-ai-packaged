# Setup Scripts

Consolidated tools for managing Local AI environment configuration and Docker authentication.

## Overview

| Script | Purpose |
|--------|---------|
| **sync_env.py** | 1Password sync + Docker auth (consolidated) |
| **generate_env.py** | Initial .env generation with secure passphrases |
| **neo4j_connect.py** | Quick Neo4j Browser connection helper |

---

## sync_env.py

Unified script for managing environment variables with 1Password and Docker authentication.

### Features

- **1Password Sync**: Bidirectional sync with 1Password Connect API
- **Docker Registry Auth**: Login/logout to Docker registries
- **Interactive Setup**: Smart setup with 1Password prefill and prompts for missing values
- **Automatic Backup**: Creates `.env.bak` before updating
- **Smart Field Types**: Automatically marks sensitive fields (passwords, tokens) as concealed

### Prerequisites

- Python 3.7+
- `requests` library (installed via `pyproject.toml`)
- 1Password Connect credentials (optional, for 1Password features)

### Usage

#### Bidirectional Sync (Default)

```bash
python setup/sync_env.py
# or explicitly:
python setup/sync_env.py sync
```

Pulls from 1Password then pushes back to ensure both are in sync. Creates `.env.bak` backup before updating.

#### Interactive Setup

```bash
python setup/sync_env.py setup
```

Smart interactive setup that:
1. Loads existing 1Password values (if configured)
2. Prompts for any missing or updated values
3. Writes complete .env file with backup
4. Auto-syncs to 1Password if values changed

Best for first-time setup or credential updates.

#### 1Password Operations

```bash
# Backup .env to 1Password
python setup/sync_env.py push

# Restore .env from 1Password (creates .env.bak)
python setup/sync_env.py pull

# Check sync status
python setup/sync_env.py status
```

#### Docker Authentication

```bash
# Login to Docker registry
python setup/sync_env.py docker-login

# Logout from Docker registry
python setup/sync_env.py docker-logout

# Specify custom registry (default: dhi.io)
python setup/sync_env.py docker-login --registry docker.io
```

Uses `DOCKERHUB_USERNAME` and `DOCKERHUB_PAT` from .env.

### 1Password Configuration

For full sync capabilities, configure these in your .env:

```bash
OP_ITEM_NAME='jw_local_ai_env'
OP_CONNECT_TOKEN='your_token_here'
OP_CONNECT_HOST='https://your-connect-host'
OP_VAULT_ID='your_vault_id'
OP_VAULT_NAME='Domo_Global'  # Optional
```

---

## generate_env.py

Generates initial `.env` file with secure XKCD-style passphrases.

### Features

- **Secure Generation**: Uses `xkcdpass` (falls back to bundled wordlist)
- **Smart Generation**: Only generates missing values, preserves existing ones
- **Interactive Prompts**: Asks for manual values marked `<set_manually>`
- **Customizable**: Adjust passphrase length and word count

### Usage

```bash
# Generate .env with defaults
python setup/generate_env.py

# Custom passphrase lengths
python setup/generate_env.py --root-words 6 --app-words 5

# Regenerate all passwords (use with caution)
python setup/generate_env.py --force

# Use different word delimiter
python setup/generate_env.py --delimiter "_"
```

### Options

- `--root-words N` - Words for root/admin passwords (default: 5)
- `--app-words N` - Words for app passwords (default: 4)
- `--neo4j-words N` - Words for Neo4j password (default: 4)
- `--delimiter STR` - Word separator (default: "-")
- `--force` - Regenerate all values even if already set

---

## neo4j_connect.py

Quick helper to open Neo4j Browser with auto-filled credentials.

### Usage

```bash
python setup/neo4j_connect.py
```

Reads credentials from .env and:
- Generates connection URL
- Prints connection details
- Attempts to open browser automatically

### Environment Variables Used

- `NEO4J_USER` - Neo4j username
- `NEO4J_PASSWORD` - Neo4j password
- `NEO4J_HOST` - Neo4j host (default: localhost)
- `NEO4J_HTTP_PORT` - HTTP port (default: 7474)

---

## Workflow Examples

### First-Time Setup

```bash
# 1. Generate initial .env with secure passphrases
python setup/generate_env.py

# 2. Interactive setup with 1Password (if available)
python setup/sync_env.py setup

# 3. Start services
docker compose up -d

# 4. Connect to Neo4j
python setup/neo4j_connect.py
```

### Daily Sync

```bash
# Keep local and 1Password in sync
python setup/sync_env.py
```

### Share Credentials Securely

```bash
# Push to 1Password for team access
python setup/sync_env.py push

# Or pull from team's 1Password
python setup/sync_env.py pull
```

### Docker Registry Login

```bash
# Login with credentials from .env
python setup/sync_env.py docker-login

# Custom registry
python setup/sync_env.py docker-login --registry custom.registry.io
```

---

## File Cleanup

The following redundant files have been consolidated:
- ~~`docker_login.py`~~ → Merged into `sync_env.py` (docker-login/logout commands)
- ~~`env_to_json.py`~~ → Removed (JSON field handling built into sync_env)

---

## Troubleshooting

### 1Password Sync Not Working

- Verify 1Password credentials in `.env`
- Check connectivity to `OP_CONNECT_HOST`
- Ensure vault ID exists and is accessible
- Run `python setup/sync_env.py status` to diagnose

### Docker Login Fails

- Verify `DOCKERHUB_USERNAME` and `DOCKERHUB_PAT` are set
- Ensure Docker daemon is running
- Try manual login: `docker login -u USERNAME dhi.io`

### Missing Passphrases

- Run: `python setup/generate_env.py` to generate missing values
- Use `setup` action to interactively set missing values
