
"""
Generate a .env file from .env.example using XKCD-style passphrases.

The script prefers the xkcdpass package (https://github.com/redacted/XKCD-password-generator)
but will fall back to a local, bundled word list if the package is not installed.

Only generates values that are empty or None. Values marked <set_manually> require user input.
"""

from __future__ import annotations

import argparse
import secrets
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

from xkcdpass import xkcd_password as xp  


ROOT = Path(__file__).resolve().parent.parent
ENV_EXAMPLE = ROOT / ".env.example"
ENV_FILE = ROOT / ".env"

FALLBACK_WORDS = [
    "anchor",
    "aurora",
    "canyon",
    "cipher",
    "cobalt",
    "comet",
    "copper",
    "cricket",
    "ember",
    "falcon",
    "galaxy",
    "glacier",
    "harbor",
    "harvest",
    "horizon",
    "lantern",
    "lumen",
    "maple",
    "meadow",
    "nebula",
    "orbit",
    "paragon",
    "pebble",
    "pioneer",
    "plasma",
    "prairie",
    "quartz",
    "rocket",
    "signal",
    "sonic",
    "summit",
    "tundra",
    "velvet",
    "verge",
    "violet",
]

MANUAL_INPUT_MARKER = "<set_manually>"


@dataclass
class GeneratorConfig:
    """Configuration for password generation."""
    root_words: int = 5
    app_words: int = 4
    neo4j_words: int = 4
    delimiter: str = "-"
    force: bool = False


class PassphraseGenerator:
    """Generate secure passphrases using xkcdpass or fallback wordlist."""
    
    def __init__(self, delimiter: str = "-"):
        self.delimiter = delimiter
        self._wordlist = self._load_wordlist()
    
    def _load_wordlist(self):
        """Load xkcdpass wordlist or return None for fallback."""
        if xp:
            try:
                wordfile = xp.locate_wordfile()
                return xp.generate_wordlist(wordfile=wordfile, min_length=4, max_length=8)
            except Exception:
                pass
        return None
    
    def generate(self, num_words: int) -> str:
        """Generate a passphrase with the specified number of words."""
        if self._wordlist and xp:
            return xp.generate_xkcdpassword(
                self._wordlist, 
                numwords=num_words, 
                delimiter=self.delimiter
            )
        return self.delimiter.join(secrets.choice(FALLBACK_WORDS) for _ in range(num_words))


class EnvFile:
    """Represents and manages an environment file."""
    
    def __init__(self, path: Path):
        self.path = path
        self._entries: Dict[str, str] = {}
        self._comments: list[str] = []
        
        if path.exists():
            self._parse()
    
    def _parse(self):
        """Parse existing .env file into entries."""
        content = self.path.read_text(encoding="utf-8")
        for line in content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            key, sep, value = line.partition("=")
            if sep:
                self._entries[key.strip()] = value.strip()
    
    def get(self, key: str, default: str = "") -> str:
        """Get value for a key."""
        return self._entries.get(key, default)
    
    def set(self, key: str, value: str):
        """Set value for a key."""
        self._entries[key] = value
    
    def needs_generation(self, example_value: str) -> bool:
        """Check if a value needs password generation (empty in example)."""
        return not example_value or example_value == ""
    
    def needs_manual_input(self) -> List[tuple[str, str]]:
        """Return list of (key, value) pairs that need manual input."""
        return [(k, v) for k, v in self._entries.items() if v == MANUAL_INPUT_MARKER]
    
    def exists(self) -> bool:
        """Check if the file exists."""
        return self.path.exists()


class EnvGenerator:
    """Main generator for .env files."""
    
    def __init__(self, config: GeneratorConfig):
        self.config = config
        self.generator = PassphraseGenerator(config.delimiter)
        self.example = EnvFile(ENV_EXAMPLE)
        self.target = EnvFile(ENV_FILE)
    
    def _get_password_config(self, key: str) -> int:
        """Get number of words for a given key based on naming conventions."""
        if "ROOT" in key:
            return self.config.root_words
        elif "NEO4J" in key:
            return self.config.neo4j_words
        else:
            return self.config.app_words
    
    def _generate_value(self, key: str, example_value: str) -> str:
        """Generate a new value for a key."""
        num_words = self._get_password_config(key)
        return self.generator.generate(num_words)
    
    def generate_missing(self) -> Dict[str, str]:
        """Generate only missing or placeholder values."""
        if not self.example.exists():
            raise FileNotFoundError(f"Missing template file: {ENV_EXAMPLE}")
        
        if self.target.exists() and not self.config.force:
            # Update mode: only generate missing values
            return self._generate_updates()
        else:
            # Create mode: generate all placeholders
            return self._generate_all()
    
    def _generate_updates(self) -> Dict[str, str]:
        """Generate values only for keys that need updating (empty in example)."""
        generated = {}
        example_lines = ENV_EXAMPLE.read_text(encoding="utf-8").splitlines()
        
        for line in example_lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            key, sep, value = line.partition("=")
            if not sep:
                continue
            
            key = key.strip()
            example_value = value.strip()
            
            # Skip if already set to a non-placeholder value
            current_value = self.target.get(key)
            if current_value and current_value not in (MANUAL_INPUT_MARKER, ""):
                continue
            
            # Generate password if example value is empty
            if self.target.needs_generation(example_value):
                new_value = self._generate_value(key, example_value)
                self.target.set(key, new_value)
                generated[key] = new_value
        
        return generated
    
    def _generate_all(self) -> Dict[str, str]:
        """Generate all empty password values from example."""
        generated = {}
        example_lines = ENV_EXAMPLE.read_text(encoding="utf-8").splitlines()
        
        for line in example_lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            key, sep, value = line.partition("=")
            if not sep:
                continue
            
            key = key.strip()
            example_value = value.strip()
            
            # Generate for empty values (passwords)
            if self.target.needs_generation(example_value):
                new_value = self._generate_value(key, example_value)
                self.target.set(key, new_value)
                generated[key] = new_value
            else:
                # Preserve the example value as-is (ports, settings, <set_manually>, etc.)
                # This ensures all keys are set, even if they're <set_manually>
                self.target.set(key, example_value)
        
        return generated
    
    def validate_and_prompt(self) -> bool:
        """Validate .env and prompt only for missing manual input values. Returns True if all set."""
        # Get ALL manual input requirements from the example file
        example_lines = ENV_EXAMPLE.read_text(encoding="utf-8").splitlines()
        manual_keys = []
        
        for line in example_lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            key, sep, value = line.partition("=")
            if sep and value.strip() == MANUAL_INPUT_MARKER:
                key = key.strip()
                current_value = self.target.get(key, "")  # Default to empty string if not found
                
                # Only prompt if the value is missing or still has the marker
                if not current_value or current_value == MANUAL_INPUT_MARKER:
                    manual_keys.append(key)
        
        if not manual_keys:
            return True
        
        print(f"\n⚠️  The following values require manual input:")
        for key in manual_keys:
            current = self.target.get(key)
            if current and current != MANUAL_INPUT_MARKER:
                print(f"  - {key} (current: {current})")
            else:
                print(f"  - {key}")
        
        print("\nPlease provide values (press Enter to keep existing):")
        for key in manual_keys:
            while True:
                current = self.target.get(key)
                prompt = f"{key}"
                if current and current != MANUAL_INPUT_MARKER:
                    prompt += f" [{current}]"
                prompt += ": "
                
                user_input = input(prompt).strip()
                
                if user_input:
                    self.target.set(key, user_input)
                    break
                elif current and current != MANUAL_INPUT_MARKER:
                    # Keep existing value if user presses Enter
                    break
                else:
                    print("  Value cannot be empty. Please provide a value.")
        
        return True
    
    def write(self):
        """Write the .env file preserving structure from example."""
        example_lines = ENV_EXAMPLE.read_text(encoding="utf-8").splitlines(keepends=True)
        output_lines = []
        
        for line in example_lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                output_lines.append(line)
                continue
            
            key, sep, _ = line.partition("=")
            if sep:
                key = key.strip()
                value = self.target.get(key, "")
                output_lines.append(f"{key}={value}\n")
            else:
                output_lines.append(line)
        
        ENV_FILE.write_text("".join(output_lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate .env using XKCD-style passphrases. Only generates missing values.",
    )
    parser.add_argument(
        "--root-words",
        type=int,
        default=5,
        help="Number of words for root/admin passwords (default: 5)",
    )
    parser.add_argument(
        "--app-words",
        type=int,
        default=4,
        help="Number of words for app passwords (default: 4)",
    )
    parser.add_argument(
        "--neo4j-words",
        type=int,
        default=4,
        help="Number of words for Neo4j password (default: 4)",
    )
    parser.add_argument(
        "--delimiter",
        default="-",
        help="Delimiter between words (default: -)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Regenerate all placeholder values even if .env exists",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = GeneratorConfig(
        root_words=args.root_words,
        app_words=args.app_words,
        neo4j_words=args.neo4j_words,
        delimiter=args.delimiter,
        force=args.force,
    )
    
    generator = EnvGenerator(config)
    generated = generator.generate_missing()
    
    # Validate and prompt for manual inputs
    generator.validate_and_prompt()
    
    # Write the final .env file
    generator.write()
    
    if generated:
        print(f"\n✓ {'Updated' if ENV_FILE.exists() else 'Created'} {ENV_FILE}")
        print("\nGenerated passwords:")
        for key, value in generated.items():
            print(f"  {key}={value}")
    else:
        print(f"\n✓ {ENV_FILE} is up to date. All password values already set.")
        if not args.force:
            print("Use --force to regenerate password values.")
    
    if not generator.generator._wordlist:
        print("\nNote: xkcdpass not installed; used bundled fallback wordlist.")
        print("Install with `uv pip install xkcdpass` for full wordlists.")


if __name__ == "__main__":
    main()