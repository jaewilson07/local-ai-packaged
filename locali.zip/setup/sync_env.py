#!/usr/bin/env python3
"""
Consolidated environment and Docker authentication management.

Features:
  - Sync .env file with 1Password using Connect API
  - Docker registry authentication
  - Interactive environment setup with 1Password integration
"""

import json
import os
import sys
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Set
import requests
from datetime import datetime
import getpass


class DockerAuth:
    """Handle Docker registry authentication."""
    
    REGISTRY = "dhi.io"  # DHI registry
    
    def __init__(self, env_file: Path):
        self.env_file = env_file
        self.env_vars = self._load_env()
    
    def _load_env(self) -> Dict[str, str]:
        """Load .env file and return dict of key-value pairs."""
        env_vars = {}
        
        if not self.env_file.exists():
            raise FileNotFoundError(f"{self.env_file} not found.")
        
        content = self.env_file.read_text(encoding="utf-8")
        for line in content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            key, sep, value = line.partition("=")
            if sep:
                env_vars[key.strip()] = value.strip().strip("'\"")
        
        return env_vars
    
    def login(self, registry: str = REGISTRY) -> bool:
        """Login to Docker registry using DOCKERHUB_PAT."""
        username = self.env_vars.get("DOCKERHUB_USERNAME")
        pat = self.env_vars.get("DOCKERHUB_PAT")
        
        if not pat or pat == "<set_manually>":
            print("✗ DOCKERHUB_PAT not set in .env")
            print("  Run 'python setup/sync_env.py setup' to configure credentials.")
            return False
        
        if not username:
            username = "jwilson1"
        
        try:
            cmd = [
                "docker",
                "login",
                "-u", username,
                "--password-stdin",
                registry,
            ]
            
            result = subprocess.run(
                cmd,
                input=pat.encode(),
                capture_output=True,
                timeout=30,
            )
            
            if result.returncode == 0:
                print(f"✓ Successfully logged in to {registry} as {username}")
                return True
            else:
                error = result.stderr.decode().strip()
                print(f"✗ Failed to login to {registry}")
                print(f"  Error: {error}")
                return False
        
        except subprocess.TimeoutExpired:
            print("✗ Docker login timed out")
            return False
        except FileNotFoundError:
            print("✗ Docker command not found. Is Docker installed?")
            return False
    
    def logout(self, registry: str = REGISTRY) -> bool:
        """Logout from Docker registry."""
        try:
            result = subprocess.run(
                ["docker", "logout", registry],
                capture_output=True,
                timeout=10,
            )
            
            if result.returncode == 0:
                print(f"✓ Successfully logged out from {registry}")
                return True
            else:
                error = result.stderr.decode().strip()
                print(f"✗ Failed to logout from {registry}")
                print(f"  Error: {error}")
                return False
        
        except subprocess.TimeoutExpired:
            print("✗ Docker logout timed out")
            return False
        except FileNotFoundError:
            print("✗ Docker command not found")
            return False


class OnePasswordSync:
    """Handle syncing environment variables with 1Password Connect."""
    
    def __init__(self, env_file: Path):
        self.env_file = env_file
        self.project_root = env_file.parent
        
        # Load 1Password config from .env
        self.op_config = self._load_op_config()
        
        self.connect_host = self.op_config['OP_CONNECT_HOST']
        self.connect_token = self.op_config['OP_CONNECT_TOKEN']
        self.vault_id = self.op_config['OP_VAULT_ID']
        self.item_name = self.op_config['OP_ITEM_NAME']
        
        self.headers = {
            'Authorization': f'Bearer {self.connect_token}',
            'Content-Type': 'application/json'
        }
    
    def _load_op_config(self) -> Dict[str, str]:
        """Load 1Password configuration from .env file."""
        config = {}
        required_keys = ['OP_CONNECT_HOST', 'OP_CONNECT_TOKEN', 'OP_VAULT_ID', 'OP_ITEM_NAME']
        
        if not self.env_file.exists():
            raise FileNotFoundError(f".env file not found at {self.env_file}")
        
        with open(self.env_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip().strip("'\"")  # Remove quotes
                    
                    if key in required_keys:
                        config[key] = value
        
        missing = [k for k in required_keys if k not in config]
        if missing:
            raise ValueError(f"Missing required 1Password config: {', '.join(missing)}")
        
        return config
    
    def _parse_env_file(self) -> Dict[str, str]:
        """Parse .env file and return non-OP variables."""
        env_vars = {}
        
        with open(self.env_file, 'r') as f:
            for line in f:
                line = line.strip()
                
                # Skip empty lines, comments, and OP config
                if not line or line.startswith('#'):
                    continue
                
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip().strip("'\"")
                    
                    # Skip OP configuration variables
                    if not key.startswith('OP_'):
                        env_vars[key] = value
        
        return env_vars
    
    def _get_item_by_name(self) -> Optional[Dict]:
        """Find item by name in the vault."""
        url = f"{self.connect_host}/v1/vaults/{self.vault_id}/items"
        
        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            
            items = response.json()
            for item in items:
                if item['title'] == self.item_name:
                    # Get full item details
                    item_url = f"{self.connect_host}/v1/vaults/{self.vault_id}/items/{item['id']}"
                    item_response = requests.get(item_url, headers=self.headers)
                    item_response.raise_for_status()
                    return item_response.json()
            
            return None
        except requests.exceptions.RequestException as e:
            print(f"Error fetching item: {e}")
            sys.exit(1)
    
    def _create_field(self, key: str, value: str, index: int) -> Dict:
        """Create a field object for 1Password."""
        # Determine if field should be concealed
        is_sensitive = any(keyword in key.lower() 
                          for keyword in ['password', 'pat', 'token', 'secret', 'key', 'auth'])
        
        field = {
            "id": f"{key.lower().replace('_', '')}_{index}",
            "label": key,
            "value": value,
            "type": "concealed" if is_sensitive else "string"
        }
        
        # Don't set purpose for concealed fields - just use type
        return field
    
    def push(self) -> None:
        """Push .env variables to 1Password."""
        print(f"📤 Pushing to 1Password: {self.item_name}")
        
        env_vars = self._parse_env_file()
        
        # Check if item exists
        existing_item = self._get_item_by_name()
        
        # Prepare fields with indices
        fields = [self._create_field(k, v, i) for i, (k, v) in enumerate(env_vars.items())]
        
        if existing_item:
            # Update existing item - need to provide complete structure
            item_id = existing_item['id']
            vault_id = existing_item['vault']['id']
            url = f"{self.connect_host}/v1/vaults/{vault_id}/items/{item_id}"
            
            # Start with existing item structure and update fields
            payload = {
                "id": item_id,
                "title": existing_item.get('title', self.item_name),
                "category": existing_item.get('category', 'SECURE_NOTE'),
                "vault": {"id": vault_id},
                "fields": fields
            }
            
            # Include optional fields if they exist
            if 'tags' in existing_item:
                payload['tags'] = existing_item['tags']
            if 'urls' in existing_item:
                payload['urls'] = existing_item['urls']
            
            try:
                response = requests.put(url, headers=self.headers, json=payload)
                response.raise_for_status()
                print(f"✓ Updated item '{self.item_name}' with {len(env_vars)} variables")
            except requests.exceptions.RequestException as e:
                print(f"✗ Error updating item: {e}")
                if hasattr(e, 'response') and hasattr(e.response, 'text'):
                    print(f"  Response: {e.response.text}")
                sys.exit(1)
        else:
            # Create new item
            url = f"{self.connect_host}/v1/vaults/{self.vault_id}/items"
            
            payload = {
                "title": self.item_name,
                "category": "SECURE_NOTE",
                "vault": {"id": self.vault_id},
                "fields": fields,
                "tags": ["docker", "environment", "local-ai", "synced"]
            }
            
            try:
                response = requests.post(url, headers=self.headers, json=payload)
                response.raise_for_status()
                print(f"✓ Created item '{self.item_name}' with {len(env_vars)} variables")
            except requests.exceptions.RequestException as e:
                print(f"✗ Error creating item: {e}")
                if hasattr(e.response, 'text'):
                    print(f"  Response: {e.response.text}")
                sys.exit(1)
    
    def pull(self, output_file: Optional[Path] = None) -> None:
        """Pull variables from 1Password and write to .env file."""
        print(f"📥 Pulling from 1Password: {self.item_name}")
        
        item = self._get_item_by_name()
        
        if not item:
            print(f"✗ Item '{self.item_name}' not found in vault")
            sys.exit(1)
        
        # Extract fields
        fields = item.get('fields', [])
        env_vars = {}
        
        for field in fields:
            if 'label' in field and 'value' in field:
                env_vars[field['label']] = field['value']
        
        if not env_vars:
            print(f"✗ No fields found in item '{self.item_name}'")
            sys.exit(1)
        
        # Determine output file
        if output_file is None:
            # Create backup
            backup_file = self.env_file.parent / ".env.bak"
            if self.env_file.exists():
                with open(self.env_file, 'r') as src:
                    with open(backup_file, 'w') as dst:
                        dst.write(src.read())
                print(f"✓ Backed up existing .env to {backup_file.name}")
            
            output_file = self.env_file
        
        # Write new .env file
        with open(output_file, 'w') as f:
            f.write("# Generated from 1Password\n")
            f.write(f"# Item: {self.item_name}\n")
            f.write(f"# Synced: {datetime.now().isoformat()}\n\n")
            
            # Write non-OP variables
            for key, value in sorted(env_vars.items()):
                f.write(f"{key}={value}\n")
            
            # Append OP config
            f.write("\n# 1Password Connect Configuration\n")
            f.write(f"OP_ITEM_NAME='{self.op_config['OP_ITEM_NAME']}'\n")
            f.write(f"OP_CONNECT_TOKEN='{self.op_config['OP_CONNECT_TOKEN']}'\n")
            f.write(f"OP_CONNECT_HOST='{self.op_config['OP_CONNECT_HOST']}'\n")
            f.write(f"OP_VAULT_NAME='{self.op_config.get('OP_VAULT_NAME', '')}'\n")
            f.write(f"OP_VAULT_ID='{self.op_config['OP_VAULT_ID']}'\n")
        
        print(f"✓ Pulled {len(env_vars)} variables to {output_file}")
    
    def status(self) -> None:
        """Show sync status between local and 1Password."""
        print(f"📊 Sync Status")
        print(f"   Item: {self.item_name}")
        print(f"   Vault: {self.vault_id}")
        
        # Get local vars
        local_vars = self._parse_env_file()
        print(f"\n   Local .env: {len(local_vars)} variables")
        
        # Get remote vars
        item = self._get_item_by_name()
        if item:
            remote_vars = {f['label']: f['value'] for f in item.get('fields', []) 
                          if 'label' in f and 'value' in f}
            print(f"   1Password:  {len(remote_vars)} variables")
            
            # Compare
            local_keys = set(local_vars.keys())
            remote_keys = set(remote_vars.keys())
            
            only_local = local_keys - remote_keys
            only_remote = remote_keys - local_keys
            common = local_keys & remote_keys
            
            # Check for value differences
            different_values = []
            for key in common:
                if local_vars[key] != remote_vars[key]:
                    different_values.append(key)
            
            print(f"\n   In sync: {len(common) - len(different_values)} variables")
            
            if only_local:
                print(f"\n   ⚠ Only in local ({len(only_local)}):")
                for key in sorted(only_local):
                    print(f"     - {key}")
            
            if only_remote:
                print(f"\n   ⚠ Only in 1Password ({len(only_remote)}):")
                for key in sorted(only_remote):
                    print(f"     - {key}")
            
            if different_values:
                print(f"\n   ⚠ Different values ({len(different_values)}):")
                for key in sorted(different_values):
                    print(f"     - {key}")
        else:
            print(f"   1Password:  Item not found")


class InteractiveEnvSetup:
    """Interactive environment setup with 1Password integration."""
    
    # Define expected environment variables with descriptions
    ENV_SCHEMA = {
        'MONGO_INITDB_ROOT_USERNAME': {
            'description': 'MongoDB root username',
            'default': 'admin',
            'sensitive': False
        },
        'MONGO_INITDB_ROOT_PASSWORD': {
            'description': 'MongoDB root password',
            'default': None,
            'sensitive': True
        },
        'MONGO_APP_DATABASE': {
            'description': 'MongoDB application database name',
            'default': 'dockling',
            'sensitive': False
        },
        'MONGO_APP_USERNAME': {
            'description': 'MongoDB application username',
            'default': 'dockling',
            'sensitive': False
        },
        'MONGO_APP_PASSWORD': {
            'description': 'MongoDB application password',
            'default': None,
            'sensitive': True
        },
        'MONGO_PORT': {
            'description': 'MongoDB host port',
            'default': '27017',
            'sensitive': False
        },
        'NEO4J_USER': {
            'description': 'Neo4j username',
            'default': 'neo4j',
            'sensitive': False
        },
        'NEO4J_PASSWORD': {
            'description': 'Neo4j password',
            'default': None,
            'sensitive': True
        },
        'NEO4J_HTTP_PORT': {
            'description': 'Neo4j HTTP port',
            'default': '7474',
            'sensitive': False
        },
        'NEO4J_BOLT_PORT': {
            'description': 'Neo4j Bolt port',
            'default': '7687',
            'sensitive': False
        },
        'NEO4J_PAGECACHE_SIZE': {
            'description': 'Neo4j page cache size',
            'default': '512M',
            'sensitive': False
        },
        'NEO4J_HEAP_INITIAL': {
            'description': 'Neo4j initial heap size',
            'default': '512M',
            'sensitive': False
        },
        'NEO4J_HEAP_MAX': {
            'description': 'Neo4j max heap size',
            'default': '1G',
            'sensitive': False
        },
        'DOCKERHUB_USERNAME': {
            'description': 'Docker Hub username',
            'default': None,
            'sensitive': False
        },
        'DOCKERHUB_PAT': {
            'description': 'Docker Hub personal access token',
            'default': None,
            'sensitive': True
        }
    }
    
    # 1Password configuration variables
    OP_CONFIG_VARS = {
        'OP_ITEM_NAME': {
            'description': '1Password item name',
            'default': 'jw_local_ai_env'
        },
        'OP_CONNECT_TOKEN': {
            'description': '1Password Connect API token',
            'default': None
        },
        'OP_CONNECT_HOST': {
            'description': '1Password Connect host URL',
            'default': None
        },
        'OP_VAULT_NAME': {
            'description': '1Password vault name',
            'default': 'Domo_Global'
        },
        'OP_VAULT_ID': {
            'description': '1Password vault ID',
            'default': None
        }
    }
    
    def __init__(self, env_file: Path):
        self.env_file = env_file
        self.env_values: Dict[str, str] = {}
        self.op_config: Dict[str, str] = {}
        self.values_changed = False
        self.sync_available = False
    
    def _prompt_value(self, key: str, description: str, default: Optional[str], sensitive: bool) -> str:
        """Prompt user for a value."""
        if default:
            prompt = f"{description} [{key}] (default: {default}): "
        else:
            prompt = f"{description} [{key}]: "
        
        if sensitive:
            value = getpass.getpass(prompt)
        else:
            value = input(prompt)
        
        return value.strip() or default or ''
    
    def _try_load_from_onepassword(self) -> Dict[str, str]:
        """Try to load values from 1Password if configured."""
        print("\n🔐 Checking for 1Password credentials...")
        
        # First, try to load OP config from existing .env
        if self.env_file.exists():
            print(f"   Found existing .env file")
            with open(self.env_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    if '=' in line:
                        key, value = line.split('=', 1)
                        key = key.strip()
                        value = value.strip().strip("'\"")
                        
                        if key.startswith('OP_'):
                            self.op_config[key] = value
        
        # Check if we have enough config to connect
        required_keys = ['OP_CONNECT_HOST', 'OP_CONNECT_TOKEN', 'OP_VAULT_ID', 'OP_ITEM_NAME']
        if all(k in self.op_config for k in required_keys):
            print(f"   ✓ Found 1Password configuration")
            
            try:
                sync = OnePasswordSync(self.env_file)
                item = sync._get_item_by_name()
                
                if item:
                    fields = item.get('fields', [])
                    remote_vars = {f['label']: f['value'] for f in fields 
                                  if 'label' in f and 'value' in f}
                    
                    print(f"   ✓ Retrieved {len(remote_vars)} variables from 1Password")
                    self.sync_available = True
                    return remote_vars
                else:
                    print(f"   ⚠ Item '{self.op_config['OP_ITEM_NAME']}' not found in 1Password")
            except Exception as e:
                print(f"   ⚠ Could not connect to 1Password: {e}")
        else:
            print(f"   ⚠ 1Password not fully configured")
        
        return {}
    
    def setup_interactive(self) -> None:
        """Run interactive setup."""
        print("=" * 70)
        print("  Local AI Environment Setup")
        print("=" * 70)
        
        # Try to load from 1Password first
        remote_values = self._try_load_from_onepassword()
        
        # Load existing local values
        existing_values = {}
        if self.env_file.exists():
            with open(self.env_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    if '=' in line:
                        key, value = line.split('=', 1)
                        key = key.strip()
                        value = value.strip().strip("'\"")
                        
                        if not key.startswith('OP_'):
                            existing_values[key] = value
        
        # Combine: remote > existing > prompt
        print("\n📝 Environment Variables Configuration")
        print("-" * 70)
        
        for key, config in self.ENV_SCHEMA.items():
            # Determine current value
            if key in remote_values:
                current = remote_values[key]
                source = "1Password"
            elif key in existing_values:
                current = existing_values[key]
                source = "existing .env"
            elif config['default']:
                current = config['default']
                source = "default"
            else:
                current = None
                source = None
            
            # Prompt or confirm
            if current:
                if config['sensitive']:
                    display = "***" if current else "not set"
                else:
                    display = current
                
                print(f"\n{config['description']} [{key}]")
                print(f"   Current: {display} (from {source})")
                
                if source == "1Password":
                    # Auto-use 1Password value
                    self.env_values[key] = current
                    print(f"   ✓ Using value from 1Password")
                else:
                    # Confirm or change
                    response = input(f"   Keep this value? [Y/n]: ").strip().lower()
                    if response in ['', 'y', 'yes']:
                        self.env_values[key] = current
                    else:
                        new_value = self._prompt_value(key, config['description'], 
                                                       current, config['sensitive'])
                        self.env_values[key] = new_value
                        self.values_changed = True
            else:
                # No value, must prompt
                print(f"\n{config['description']} [{key}]")
                value = self._prompt_value(key, config['description'], 
                                          config['default'], config['sensitive'])
                self.env_values[key] = value
                self.values_changed = True
        
        # Handle 1Password configuration
        print("\n" + "=" * 70)
        print("  1Password Connect Configuration (Optional)")
        print("=" * 70)
        print("For automatic backup/sync of credentials to 1Password")
        
        for key, config in self.OP_CONFIG_VARS.items():
            current = self.op_config.get(key)
            
            if current:
                display = "***" if 'TOKEN' in key else current
                print(f"\n{config['description']} [{key}]: {display}")
                response = input(f"   Keep this value? [Y/n]: ").strip().lower()
                if response not in ['', 'y', 'yes']:
                    new_value = input(f"   New value (leave empty to skip): ").strip()
                    if new_value:
                        self.op_config[key] = new_value
            else:
                default_display = f" (default: {config['default']})" if config['default'] else ""
                value = input(f"\n{config['description']} [{key}]{default_display}: ").strip()
                if value:
                    self.op_config[key] = value
                elif config['default']:
                    self.op_config[key] = config['default']
    
    def write_env_file(self) -> None:
        """Write the environment file."""
        print("\n" + "=" * 70)
        print(f"  Writing configuration to {self.env_file}")
        print("=" * 70)
        
        # Create backup if file exists
        if self.env_file.exists():
            backup_file = self.env_file.parent / ".env.bak"
            with open(self.env_file, 'r') as src:
                with open(backup_file, 'w') as dst:
                    dst.write(src.read())
            print(f"✓ Backed up existing .env to {backup_file.name}")
        
        # Write new file
        with open(self.env_file, 'w') as f:
            f.write("# Local AI Environment Configuration\n")
            f.write(f"# Generated: {datetime.now().isoformat()}\n\n")
            
            # Group by service
            f.write("# MongoDB - Admin/root credentials\n")
            for key in ['MONGO_INITDB_ROOT_USERNAME', 'MONGO_INITDB_ROOT_PASSWORD']:
                if key in self.env_values:
                    f.write(f"{key}={self.env_values[key]}\n")
            
            f.write("\n# MongoDB - App database/user (created by init script)\n")
            for key in ['MONGO_APP_DATABASE', 'MONGO_APP_USERNAME', 'MONGO_APP_PASSWORD']:
                if key in self.env_values:
                    f.write(f"{key}={self.env_values[key]}\n")
            
            f.write("\n# MongoDB - Host port mapping\n")
            if 'MONGO_PORT' in self.env_values:
                f.write(f"MONGO_PORT={self.env_values['MONGO_PORT']}\n")
            
            f.write("\n# Neo4j - Authentication (format: username/password)\n")
            f.write("# NEO4J_AUTH=neo4j/change-me\n\n")
            for key in ['NEO4J_USER', 'NEO4J_PASSWORD']:
                if key in self.env_values:
                    f.write(f"{key}={self.env_values[key]}\n")
            
            f.write("\n# Neo4j - Host port mappings\n")
            for key in ['NEO4J_HTTP_PORT', 'NEO4J_BOLT_PORT']:
                if key in self.env_values:
                    f.write(f"{key}={self.env_values[key]}\n")
            
            f.write("\n# Neo4j - Memory settings\n")
            for key in ['NEO4J_PAGECACHE_SIZE', 'NEO4J_HEAP_INITIAL', 'NEO4J_HEAP_MAX']:
                if key in self.env_values:
                    f.write(f"{key}={self.env_values[key]}\n")
            
            f.write("\n# Docker Hub / DHI Registry credentials\n")
            for key in ['DOCKERHUB_USERNAME', 'DOCKERHUB_PAT']:
                if key in self.env_values:
                    f.write(f"{key}={self.env_values[key]}\n")
            
            # Write OP config if present
            if self.op_config:
                f.write("\n# OP Creds\n")
                for key, value in self.op_config.items():
                    f.write(f"{key} = '{value}'\n")
        
        print(f"✓ Wrote {len(self.env_values)} environment variables")
    
    def sync_to_onepassword(self) -> None:
        """Sync to 1Password if available and values changed."""
        if not self.sync_available:
            print("\n⚠ Skipping 1Password sync (not configured)")
            return
        
        if not self.values_changed:
            print("\n✓ No changes detected, skipping 1Password sync")
            return
        
        print("\n" + "=" * 70)
        print("  Syncing to 1Password")
        print("=" * 70)
        
        try:
            sync = OnePasswordSync(self.env_file)
            sync.push()
            print("✓ Successfully synced to 1Password")
        except Exception as e:
            print(f"⚠ Could not sync to 1Password: {e}")
    
    def run(self) -> None:
        """Run the full interactive setup."""
        self.setup_interactive()
        self.write_env_file()
        self.sync_to_onepassword()
        
        print("\n" + "=" * 70)
        print("  Setup Complete!")
        print("=" * 70)
        print("\nNext steps:")
        print("  1. Review your .env file")
        print("  2. Start services: docker compose up -d")
        print("  3. Sync anytime with: python setup/sync_env.py push")
        print()


def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Manage environment and Docker authentication',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment Sync:
  python sync_env.py              Bidirectional sync (pull → push)
  python sync_env.py sync         Same as above
  python sync_env.py setup        Interactive setup with 1Password
  python sync_env.py push         Backup to 1Password only
  python sync_env.py pull         Restore from 1Password only
  python sync_env.py status       Check sync status

Docker Authentication:
  python sync_env.py docker-login   Login to Docker registry
  python sync_env.py docker-logout  Logout from Docker registry
        """
    )
    
    parser.add_argument(
        'action',
        nargs='?',
        default='sync',
        choices=['sync', 'setup', 'push', 'pull', 'status', 'docker-login', 'docker-logout'],
        help='Action to perform'
    )
    
    parser.add_argument(
        '--env-file',
        type=Path,
        help='Path to .env file (default: ../.env)'
    )
    
    parser.add_argument(
        '--registry',
        default='dhi.io',
        help='Docker registry (default: dhi.io)'
    )
    
    args = parser.parse_args()
    
    # Determine .env file path
    if args.env_file:
        env_file = args.env_file
    else:
        script_dir = Path(__file__).parent
        env_file = script_dir.parent / '.env'
    
    # Execute action
    try:
        if args.action == 'setup':
            # Run interactive setup
            setup = InteractiveEnvSetup(env_file)
            setup.run()
        
        elif args.action == 'docker-login':
            # Docker authentication
            docker = DockerAuth(env_file)
            success = docker.login(args.registry)
            sys.exit(0 if success else 1)
        
        elif args.action == 'docker-logout':
            # Docker logout
            docker = DockerAuth(env_file)
            success = docker.logout(args.registry)
            sys.exit(0 if success else 1)
        
        elif args.action == 'sync':
            # Full bidirectional sync: pull then push
            sync = OnePasswordSync(env_file)
            print("🔄 Running full sync (pull → push)")
            print("=" * 70)
            sync.pull()
            print()
            sync.push()
            print("\n✓ Full sync complete")
        
        else:
            # Standard sync operations (push, pull, status)
            sync = OnePasswordSync(env_file)
            
            if args.action == 'push':
                sync.push()
            elif args.action == 'pull':
                sync.pull()
            elif args.action == 'status':
                sync.status()
            
    except Exception as e:
        print(f"✗ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
