#!/usr/bin/env python3
"""
Auto-connect to Neo4j Browser with credentials from .env
"""
import os
from pathlib import Path
from dotenv import load_dotenv
import webbrowser

# Load .env
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(env_path)

# Get credentials
neo4j_user = os.getenv("NEO4J_USER", "neo4j")
neo4j_password = os.getenv("NEO4J_PASSWORD", "")
neo4j_host = os.getenv("NEO4J_HOST", "localhost")
neo4j_http_port = os.getenv("NEO4J_HTTP_PORT", "7474")

# Build connection URL
# Format: neo4j://user:password@host:port
bolt_url = f"neo4j://{neo4j_user}:{neo4j_password}@{neo4j_host}:7687"

# Browser URL with connection string as query param
# This opens Neo4j Browser and pre-fills the connection
browser_url = f"http://{neo4j_host}:{neo4j_http_port}/browser/?connectionURL={bolt_url}"

print(f"\n✓ Neo4j Browser Connection URL:")
print(f"  {browser_url}\n")
print(f"Copy and paste this URL into your browser to connect automatically.")
print(f"Username: {neo4j_user}")
print(f"Bolt Connection: bolt://{neo4j_host}:7687\n")

# Try to open in browser, but don't fail if headless
try:
    webbrowser.open(browser_url)
    print("Opening browser...")
except Exception as e:
    print(f"Could not auto-open browser: {e}")
