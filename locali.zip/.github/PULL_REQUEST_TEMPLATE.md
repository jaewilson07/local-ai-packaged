## PR summary

- Related issue(s): <!-- e.g., #123 -->
- PRD link: <!-- e.g., /docs/product/PRD.md -->

## What changed

- 

## Why

- 

## Validation

- [ ] Unit tests updated/added
- [ ] Integration tests passing
- [ ] Type annotations complete (no `Any` without justification)
- [ ] Async I/O and error handling patterns followed
- [ ] Docs updated (README/docs/issue templates)

## Notes

- 
