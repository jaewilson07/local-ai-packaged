---
name: <Concise Skill Name>
description: <What this skill does and why>
triggers:
  - "<phrases users might say to invoke this skill>"
inputs:
  - id: <input_id>
    description: "<what to pass>"
    required: true
outputs:
  - id: <output_id>
    description: "<what the skill should produce>"
---

Steps:
1) <clear step>
2) <clear step>
3) <clear step>

Expected outputs:
- <bullet list of artifacts with file links when applicable>

Completion criteria:
- <conditions to consider the skill complete>