#!/usr/bin/env python3
"""
Main setup orchestrator script.
Runs all setup tasks in the proper sequence.

Usage:
    uv run setup          # Run all setup tasks
    uv run setup --help   # Show available options
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SETUP_DIR = ROOT / "setup"


class SetupTask:
    """Represents a setup task to be executed."""
    
    def __init__(self, name: str, script: str, description: str, required: bool = False):
        self.name = name
        self.script = script
        self.description = description
        self.required = required
        self.path = SETUP_DIR / script
    
    def run(self) -> bool:
        """Execute the setup task. Returns True if successful."""
        print(f"\n{'='*60}")
        print(f"🔧 {self.name}")
        print(f"   {self.description}")
        print(f"{'='*60}")
        
        if not self.path.exists():
            print(f"✗ Script not found: {self.path}")
            return False
        
        try:
            result = subprocess.run(
                [sys.executable, str(self.path)],
                cwd=ROOT,
            )
            
            if result.returncode == 0:
                print(f"✓ {self.name} completed successfully\n")
                return True
            else:
                print(f"✗ {self.name} failed with exit code {result.returncode}\n")
                return False
        
        except KeyboardInterrupt:
            print(f"\n⚠️  {self.name} interrupted by user\n")
            return False
        except Exception as e:
            print(f"✗ Error running {self.name}: {e}\n")
            return False


# Define all setup tasks in order
SETUP_TASKS = [
    SetupTask(
        name="Environment Configuration",
        script="generate_env.py",
        description="Generate .env file with secure passwords and user inputs",
        required=True,
    ),
    SetupTask(
        name="Docker Authentication",
        script="docker_login.py",
        description="Authenticate Docker with registry credentials from .env",
        required=False,
    ),
]


def run_all_tasks(verbose: bool = False) -> bool:
    """Run all setup tasks in sequence. Returns True if all required tasks succeed."""
    print("\n" + "="*60)
    print("🚀 Local AI Setup")
    print("="*60)
    
    results = {}
    for task in SETUP_TASKS:
        success = task.run()
        results[task.name] = success
        
        if not success and task.required:
            print(f"\n❌ Setup failed: {task.name} is required")
            return False
    
    # Summary
    print("\n" + "="*60)
    print("📋 Setup Summary")
    print("="*60)
    
    for task in SETUP_TASKS:
        status = "✓" if results[task.name] else "✗"
        required = "(required)" if task.required else "(optional)"
        print(f"{status} {task.name} {required}")
    
    all_required_succeeded = all(
        results[task.name] for task in SETUP_TASKS if task.required
    )
    
    if all_required_succeeded:
        print("\n✅ Setup complete! You're ready to start services:")
        print("   docker compose up -d")
        return True
    else:
        print("\n❌ Setup incomplete. Fix errors and try again.")
        return False


def list_tasks() -> None:
    """List all available setup tasks."""
    print("\nAvailable setup tasks:\n")
    for task in SETUP_TASKS:
        required = "(required)" if task.required else "(optional)"
        print(f"  {task.name} {required}")
        print(f"    {task.description}")
        print(f"    Script: {task.script}\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Setup orchestrator for local-ai project",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  uv run setup              # Run all setup tasks
  uv run setup --list       # List available tasks
  uv run setup --help       # Show this help message
        """,
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List all available setup tasks",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    
    if args.list:
        list_tasks()
        return
    
    success = run_all_tasks(verbose=args.verbose)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
