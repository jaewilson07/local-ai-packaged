# Copilot skills

Place one manifest per skill in this folder. See `../../COPILOT_SKILLS.md` for examples and links to the official schema.

Suggested initial skills:

- rag.ingest — wraps `examples/ingestion/ingest.py`
- rag.search — wraps `examples/cli.py` for interactive searches
- rag.agent.debug — runs the agent end-to-end with a provided prompt
