def main():
    print("Hello from local-ai!")


if __name__ == "__main__":
    main()
